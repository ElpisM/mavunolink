package ke.ac.jkuat.mavunolink;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

/**
 * Lab 2 event flow (one Submit):
 *
 *   btnSubmit click -> onSubmitClicked()
 *     -> RecordValidator.validateForm(...)          pure check, changes nothing
 *        invalid  -> setError on every bad field, focus the first, NO dialog, NO commit
 *        valid    -> showConfirmDialog(record)      a question, still NO commit
 *                     Confirm -> commit(record)     the ONLY place records.add() is called;
 *                                                   then (and only then) the draft is cleared
 *                     Edit    -> dismiss; draft untouched, records unchanged
 *                     Back/outside tap -> onCancel; same as Edit
 *
 * Ownership: the draft lives in this Activity's EditTexts / RadioGroup and is copied
 * into the saved-state Bundle on rotation. It may be cleared only after a successful
 * commit. Every step is written to Logcat (MavunoForm) and to the on-screen trace with
 * the current record count, which is the evidence that Edit/Cancel committed nothing.
 *
 * Lab 3 options menu (res/menu/main_menu.xml), attached in onCreateOptionsMenu():
 *   action_new_record   -> onNewRecord()     clears the form; asks first if input would be lost
 *   action_view_records -> openRecords()     starts RecordsActivity (screen change); Back returns
 *   action_about        -> showAbout()       AlertDialog
 *   action_clear_trace  -> clear trace + Toast
 *   any other ID        -> logged as UNHANDLED and passed to super; no crash, no action
 * Matching is by item ID, never by title, so changing or translating a label cannot
 * break the handler. No menu path calls commit(): only the dialog's Confirm button does,
 * so recreating the menu or rotating the screen cannot repeat a save.
 */
public class MainActivity extends AppCompatActivity {

    static final String TAG = "MavunoLifecycle";
    static final String TAG_FORM = "MavunoForm";
    static final String TAG_MENU = "MavunoMenu";
    static final String TAG_NAV = "MavunoNav";

    private static final String KEY_FARMER = "draft_farmer";
    private static final String KEY_DATE = "draft_date";
    private static final String KEY_CROP = "draft_crop";
    private static final String KEY_QTY = "draft_qty";
    private static final String KEY_TYPE = "draft_type";
    private static final String KEY_NOTES = "draft_notes";
    private static final String KEY_RECORDS = "records";
    private static final String KEY_DIALOG_OPEN = "dialog_open";

    /** Process memory only: survives rotation, wiped by a process kill (see Lab 1). */
    private static final StringBuilder TRACE = new StringBuilder();

    private EditText etFarmer, etDate, etCrop, etQuantity, etNotes;
    private RadioGroup rgType;
    private TextView tvCount, tvEmpty, tvTrace;

    private ArrayList<FarmerRecord> records;
    private RecordAdapter adapter;
    private AlertDialog confirmDialog;     // non-null while the dialog is on screen
    private boolean navigating;            // blocks a second "View records" launch from a double tap

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etFarmer = findViewById(R.id.etFarmer);
        etDate = findViewById(R.id.etDate);
        etCrop = findViewById(R.id.etCrop);
        etQuantity = findViewById(R.id.etQuantity);
        etNotes = findViewById(R.id.etNotes);
        rgType = findViewById(R.id.rgType);
        tvCount = findViewById(R.id.tvCount);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvTrace = findViewById(R.id.tvTrace);
        ListView lvRecords = findViewById(R.id.lvRecords);

        records = restoreRecords(savedInstanceState);
        adapter = new RecordAdapter(this, records);
        lvRecords.setAdapter(adapter);

        boolean reopenDialog = false;
        if (savedInstanceState != null) {
            etFarmer.setText(savedInstanceState.getString(KEY_FARMER, ""));
            etDate.setText(savedInstanceState.getString(KEY_DATE, ""));
            etCrop.setText(savedInstanceState.getString(KEY_CROP, ""));
            etQuantity.setText(savedInstanceState.getString(KEY_QTY, ""));
            etNotes.setText(savedInstanceState.getString(KEY_NOTES, ""));
            rgType.check(savedInstanceState.getInt(KEY_TYPE, R.id.rbDelivery));
            reopenDialog = savedInstanceState.getBoolean(KEY_DIALOG_OPEN, false);
        }

        findViewById(R.id.btnSubmit).setOnClickListener(v -> onSubmitClicked());
        findViewById(R.id.btnPickDate).setOnClickListener(v -> showDatePicker());
        Button btnClearTrace = findViewById(R.id.btnClearTrace);
        btnClearTrace.setOnClickListener(v -> {
            TRACE.setLength(0);
            tvTrace.setText("");
        });

        refreshCount();
        trace(TAG, "onCreate (savedInstanceState " + (savedInstanceState == null ? "NULL" : "present")
                + ", records restored=" + records.size() + ")");

        if (reopenDialog) {
            // The dialog window belonged to the destroyed Activity. Rebuild it from the
            // restored draft (the single source of truth) instead of saving a second copy.
            trace(TAG_FORM, "DIALOG was open before recreation -> re-validating restored draft");
            validateAndConfirm();
        }
    }

    @Override protected void onStart() { super.onStart(); trace(TAG, "onStart"); }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        trace(TAG, "onRestoreInstanceState");
    }

    @Override
    protected void onResume() {
        super.onResume();
        navigating = false;                // back on this screen: View records may be opened again
        trace(TAG, "onResume");           // also redraws lines written by RecordsActivity
    }
    @Override protected void onPause() { trace(TAG, "onPause"); super.onPause(); }
    @Override protected void onStop() { trace(TAG, "onStop"); super.onStop(); }
    @Override protected void onRestart() { super.onRestart(); trace(TAG, "onRestart"); }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(KEY_FARMER, text(etFarmer));
        outState.putString(KEY_DATE, text(etDate));
        outState.putString(KEY_CROP, text(etCrop));
        outState.putString(KEY_QTY, text(etQuantity));
        outState.putString(KEY_NOTES, text(etNotes));
        outState.putInt(KEY_TYPE, rgType.getCheckedRadioButtonId());
        outState.putSerializable(KEY_RECORDS, records);
        boolean open = confirmDialog != null && confirmDialog.isShowing();
        outState.putBoolean(KEY_DIALOG_OPEN, open);
        trace(TAG, "onSaveInstanceState (draft + " + records.size() + " records, dialogOpen=" + open + ")");
    }

    @Override
    protected void onDestroy() {
        trace(TAG, "onDestroy (isChangingConfigurations=" + isChangingConfigurations()
                + ", isFinishing=" + isFinishing() + ")");
        if (confirmDialog != null) {
            confirmDialog.setOnDismissListener(null);
            confirmDialog.dismiss();        // avoids a leaked window on rotation
            confirmDialog = null;
        }
        super.onDestroy();
    }

    // ---------------------------------------------------------------- event flow

    /** Step 1: click. Step 2: validate. Step 3a: errors, or 3b: dialog. */
    private void onSubmitClicked() {
        trace(TAG_FORM, "SUBMIT clicked (records=" + records.size() + ")");
        validateAndConfirm();
    }

    private void validateAndConfirm() {
        clearErrors();
        TransactionType type = selectedType();
        RecordValidator.Result result = RecordValidator.validateForm(
                text(etFarmer), text(etDate), text(etCrop), text(etQuantity),
                type, text(etNotes), new Date());

        if (!result.valid) {
            for (Map.Entry<RecordValidator.Field, String> e : result.errors.entrySet()) {
                EditText field = fieldFor(e.getKey());
                if (field != null) field.setError(e.getValue());
            }
            EditText first = fieldFor(result.field);
            if (first != null) first.requestFocus();
            Toast.makeText(this, R.string.toast_fix_errors, Toast.LENGTH_SHORT).show();
            trace(TAG_FORM, "VALIDATION failed " + result.errors.keySet()
                    + " -> no dialog, nothing committed (records=" + records.size() + ")");
            return;
        }

        trace(TAG_FORM, "VALIDATION ok -> dialog shown, nothing committed yet (records=" + records.size() + ")");
        showConfirmDialog(result.record);
    }

    /** Displaying the dialog is only a question; it does not touch the records list. */
    private void showConfirmDialog(FarmerRecord pending) {
        confirmDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_title)
                .setMessage(pending.summary() + "\n\n" + getString(R.string.dialog_footer))
                .setPositiveButton(R.string.dialog_confirm, (d, which) -> commit(pending))
                .setNegativeButton(R.string.dialog_edit, (d, which) ->
                        trace(TAG_FORM, "EDIT -> dialog closed, draft kept, nothing committed (records="
                                + records.size() + ")"))
                .setOnCancelListener(d ->
                        trace(TAG_FORM, "CANCEL (Back / tap outside) -> draft kept, nothing committed (records="
                                + records.size() + ")"))
                .create();
        confirmDialog.setOnDismissListener(d -> confirmDialog = null);
        confirmDialog.show();
    }

    /** The ONLY place a record enters the list. Clearing the draft happens after it. */
    private void commit(FarmerRecord record) {
        records.add(record);
        adapter.notifyDataSetChanged();
        refreshCount();
        // The trace and Toast name the record number, not the farmer, so feedback does not
        // expose personal details on screen or in Logcat.
        trace(TAG_FORM, "CONFIRM -> committed record #" + records.size()
                + " (records=" + records.size() + ", in memory only)");

        // Clear only what changes per farmer. Date, crop and type are kept because an
        // officer usually records several farmers for the same day and crop.
        etFarmer.setText("");
        etQuantity.setText("");
        etNotes.setText("");
        clearErrors();
        etFarmer.requestFocus();
        Toast.makeText(this, R.string.toast_committed, Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- options menu (Lab 3)

    /** Attaches res/menu/main_menu.xml to this screen's app bar. Called again after rotation. */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        trace(TAG_MENU, "onCreateOptionsMenu -> menu inflated (" + menu.size() + " items, no action run)");
        return true;
    }

    /**
     * One entry point for every menu selection. if/else on the item ID (resource IDs are
     * not compile-time constants in AGP 8, so a switch on R.id is not allowed).
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        trace(TAG_MENU, "SELECTED id=0x" + Integer.toHexString(id) + " (\"" + item.getTitle() + "\")");

        if (id == R.id.action_new_record) {
            onNewRecord();
            return true;
        } else if (id == R.id.action_view_records) {
            openRecords();
            return true;
        } else if (id == R.id.action_about) {
            showAbout();
            return true;
        } else if (id == R.id.action_clear_trace) {
            TRACE.setLength(0);
            tvTrace.setText("");
            Toast.makeText(this, R.string.toast_trace_cleared, Toast.LENGTH_SHORT).show();
            return true;
        }

        // Unknown or unhandled item: do nothing harmful, leave a trace for diagnosis,
        // and let the framework handle it (e.g. the Up button).
        trace(TAG_MENU, "UNHANDLED id=0x" + Integer.toHexString(id) + " -> passed to super, no action");
        return super.onOptionsItemSelected(item);
    }

    /** New record: an unsaved-work warning must stay until the user decides, so it is a dialog, not a Toast. */
    private void onNewRecord() {
        if (!hasUnsavedInput()) {
            Toast.makeText(this, R.string.toast_form_already_empty, Toast.LENGTH_SHORT).show();
            trace(TAG_MENU, "NEW RECORD -> form already empty, nothing to clear");
            return;
        }
        trace(TAG_MENU, "NEW RECORD -> unsaved input, asking before clearing");
        new AlertDialog.Builder(this)
                .setTitle(R.string.discard_title)
                .setMessage(R.string.discard_message)
                .setPositiveButton(R.string.discard_yes, (d, w) -> {
                    clearForm();
                    Toast.makeText(this, R.string.toast_form_cleared, Toast.LENGTH_SHORT).show();
                    trace(TAG_MENU, "NEW RECORD -> discarded draft (records=" + records.size() + ", unchanged)");
                })
                .setNegativeButton(R.string.discard_no, (d, w) ->
                        trace(TAG_MENU, "NEW RECORD -> kept draft"))
                .show();
    }

    /** View records: the one action that changes the screen. */
    private void openRecords() {
        if (navigating) {
            trace(TAG_NAV, "VIEW RECORDS ignored (already opening)");
            return;
        }
        navigating = true;
        Intent intent = new Intent(this, RecordsActivity.class);
        intent.putExtra(RecordsActivity.EXTRA_RECORDS, new ArrayList<>(records));   // read-only copy
        trace(TAG_NAV, "VIEW RECORDS -> starting RecordsActivity (" + records.size() + " records, draft kept)");
        startActivity(intent);
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.about_title)
                .setMessage(R.string.about_message)
                .setPositiveButton(R.string.ok, null)
                .show();
        trace(TAG_MENU, "ABOUT -> dialog shown");
    }

    /** True if any typed field holds a value that has not been committed. */
    private boolean hasUnsavedInput() {
        return !text(etFarmer).trim().isEmpty() || !text(etDate).trim().isEmpty()
                || !text(etCrop).trim().isEmpty() || !text(etQuantity).trim().isEmpty()
                || !text(etNotes).trim().isEmpty();
    }

    private void clearForm() {
        etFarmer.setText("");
        etDate.setText("");
        etCrop.setText("");
        etQuantity.setText("");
        etNotes.setText("");
        rgType.check(R.id.rbDelivery);
        clearErrors();
        etFarmer.requestFocus();
    }

    // ---------------------------------------------------------------- helpers

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        try {   // open on the typed date if it is valid
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            f.setLenient(false);
            Date typed = f.parse(text(etDate).trim());
            if (typed != null) c.setTime(typed);
        } catch (Exception ignored) { }

        DatePickerDialog dlg = new DatePickerDialog(this, (view, y, m, d) -> {
            etDate.setText(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d));
            etDate.setError(null);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.getDatePicker().setMaxDate(System.currentTimeMillis());   // no future dates
        dlg.show();
    }

    private TransactionType selectedType() {
        return rgType.getCheckedRadioButtonId() == R.id.rbHarvest
                ? TransactionType.WEEKLY_HARVEST : TransactionType.DELIVERY;
    }

    private EditText fieldFor(RecordValidator.Field f) {
        switch (f) {
            case FARMER: return etFarmer;
            case DATE: return etDate;
            case CROP: return etCrop;
            case QUANTITY: return etQuantity;
            case NOTES: return etNotes;
            default: return null;
        }
    }

    private void clearErrors() {
        etFarmer.setError(null);
        etDate.setError(null);
        etCrop.setError(null);
        etQuantity.setError(null);
        etNotes.setError(null);
    }

    private static String text(EditText e) {
        return e.getText().toString();
    }

    private void refreshCount() {
        tvCount.setText(getString(R.string.record_count, records.size()));
        tvEmpty.setVisibility(records.isEmpty() ? TextView.VISIBLE : TextView.GONE);
    }

    @SuppressWarnings("unchecked")
    private static ArrayList<FarmerRecord> restoreRecords(Bundle state) {
        if (state != null) {
            Object saved = state.getSerializable(KEY_RECORDS);
            if (saved instanceof ArrayList) return (ArrayList<FarmerRecord>) saved;
        }
        return new ArrayList<>();
    }

    /** Writes to Logcat and to the on-screen trace, tagged with this Activity instance. */
    private void trace(String tag, String event) {
        write(tag, "act=" + Integer.toHexString(System.identityHashCode(this)), event);
        if (tvTrace != null) tvTrace.setText(TRACE);
    }

    /** Used by RecordsActivity; MainActivity redraws the trace box in onResume. */
    static void appendTrace(String tag, String event) {
        write(tag, "screen=Records", event);
    }

    private static void write(String tag, String source, String event) {
        String time = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
        String prefix = TAG_FORM.equals(tag) ? "FORM "
                : TAG_MENU.equals(tag) ? "MENU "
                : TAG_NAV.equals(tag) ? "NAV " : "";
        String line = time + " pid=" + Process.myPid() + " " + source + " " + prefix + event;
        Log.d(tag, line);
        TRACE.append(line).append('\n');
    }
}
