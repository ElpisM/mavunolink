package ke.ac.jkuat.mavunolink;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

/**
 * Lab 3: the screen opened by the "View records" menu item.
 *
 * It receives a COPY of the committed records in the Intent and only displays them.
 * It has no save, add or delete path, so leaving it with Back or Up cannot repeat or
 * undo any action: Back simply finishes this Activity and MainActivity resumes with
 * its own state unchanged.
 */
public class RecordsActivity extends AppCompatActivity {

    static final String EXTRA_RECORDS = "ke.ac.jkuat.mavunolink.EXTRA_RECORDS";

    @Override
    @SuppressWarnings("unchecked")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_records);

        ActionBar bar = getSupportActionBar();
        if (bar != null) bar.setDisplayHomeAsUpEnabled(true);   // Up arrow = same as Back

        Object extra = getIntent().getSerializableExtra(EXTRA_RECORDS);
        ArrayList<FarmerRecord> records =
                extra instanceof ArrayList ? (ArrayList<FarmerRecord>) extra : new ArrayList<>();

        TextView header = findViewById(R.id.tvRecordsHeader);
        header.setText(getString(R.string.records_header, records.size()));

        ListView list = findViewById(R.id.lvAllRecords);
        list.setAdapter(new RecordAdapter(this, records));
        list.setEmptyView(findViewById(R.id.tvAllEmpty));

        MainActivity.appendTrace(MainActivity.TAG_NAV, "RecordsActivity onCreate (showing "
                + records.size() + " records, read-only)");
    }

    /** Up arrow behaves exactly like Back: finish, do not start a new MainActivity. */
    @Override
    public boolean onSupportNavigateUp() {
        MainActivity.appendTrace(MainActivity.TAG_NAV, "UP pressed -> finish RecordsActivity");
        finish();
        return true;
    }

    @Override
    protected void onDestroy() {
        // Back is not overridden: the system finishes this Activity. This line, with no
        // "UP pressed" before it, is the trace evidence that Back was used.
        MainActivity.appendTrace(MainActivity.TAG_NAV, "RecordsActivity onDestroy (isFinishing="
                + isFinishing() + ")");
        super.onDestroy();
    }
}
