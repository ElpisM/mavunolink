package ke.ac.jkuat.mavunolink;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Lab 2 event flow (one Submit):
 *
 *   btnSubmit click -> onSubmitClicked()
 *     -> RecordValidator.validateForm(...)          pure check, changes nothing
 *        invalid  -> setError on every bad field, focus the first, NO dialog, NO commit
 *        valid    -> showConfirmDialog(record)      a question, still NO commit
 *                     Confirm -> commit(record)     the ONLY place records.add() is called;
 *                                                   then (and only then) the draft is cleared
 *                     Edit    -> dismiss; draft untouched, records unchanged
 *                     Back/outside tap -> onCancel; same as Edit
 *
 * Ownership: the draft lives in this Activity's EditTexts / RadioGroup and is copied
 * into the saved-state Bundle on rotation. It may be cleared only after a successful
 * commit. Every step is written to Logcat (MavunoForm) and to the on-screen trace with
 * the current record count, which is the evidence that Edit/Cancel committed nothing.
 *
 * Lab 3 options menu (res/menu/main_menu.xml), attached in onCreateOptionsMenu():
 *   action_new_record   -> onNewRecord()     clears the form; asks first if input would be lost
 *   action_view_records -> openRecords()     starts RecordsActivity (screen change); Back returns
 *   action_about        -> showAbout()       AlertDialog
 *   action_clear_trace  -> clear trace + Toast
 *   action_sensor_inventory -> SensorsActivity (Lab 5)
 *   action_live_sensor  -> LiveSensorActivity (Lab 6)
 *   any other ID        -> logged as UNHANDLED and passed to super; no crash, no action
 * Matching is by item ID, never by title, so changing or translating a label cannot
 * break the handler. No menu path calls commit(): only the dialog's Confirm button does,
 * so recreating the menu or rotating the screen cannot repeat a save.
 *
 * Lab 4 collection-point Spinner:
 *   source collection  CollectionPoints.load(variant)  (+ prompt row first, id == null)
 *   adapter            CollectionPointAdapter           (closed view + custom drop-down row)
 *   view               spPoint                          (saveEnabled=false, see layout)
 *   saved model        the selected row's stable id ("CP-03"), never its position
 * After rotation or a list change the id is looked up again in the current list:
 * found -> selected at its (possibly new) position; missing -> prompt + visible warning.
 */
public class MainActivity extends AppCompatActivity {

    static final String TAG = "MavunoLifecycle";
    static final String TAG_FORM = "MavunoForm";
    static final String TAG_MENU = "MavunoMenu";
    static final String TAG_NAV = "MavunoNav";
    static final String TAG_SEL = "MavunoSelect";

    private static final String KEY_FARMER = "draft_farmer";
    private static final String KEY_DATE = "draft_date";
    private static final String KEY_CROP = "draft_crop";
    private static final String KEY_QTY = "draft_qty";
    private static final String KEY_TYPE = "draft_type";
    private static final String KEY_NOTES = "draft_notes";
    private static final String KEY_RECORDS = "records";
    private static final String KEY_DIALOG_OPEN = "dialog_open";
    private static final String KEY_POINT_ID = "draft_point_id";       // stable id, not position
    private static final String KEY_POINT_NAME = "draft_point_name";   // only for the "no longer available" message
    private static final String KEY_POINT_STATUS = "draft_point_status";
    private static final String KEY_RECEIPT = "draft_receipt";
    private static final String KEY_LIST_VARIANT = "point_list_variant";

    /** Process memory only: survives rotation, wiped by a process kill (see Lab 1). */
    private static final StringBuilder TRACE = new StringBuilder();

    private EditText etFarmer, etDate, etCrop, etQuantity, etNotes;
    private RadioGroup rgType;
    private Spinner spPoint;
    private CheckBox cbReceipt;
    private TextView tvPointSelected, tvPointStatus;
    private ScrollView scrollForm;
    private final ArrayList<CollectionPoint> pointRows = new ArrayList<>();   // adapter's backing list
    private CollectionPointAdapter pointAdapter;
    private CollectionPoints.Variant listVariant = CollectionPoints.Variant.STANDARD;
    private TextView tvCount, tvEmpty, tvTrace;

    private ArrayList<FarmerRecord> records;
    private RecordAdapter adapter;
    private AlertDialog confirmDialog;     // non-null while the dialog is on screen
    private boolean navigating;            // blocks a second "View records" launch from a double tap

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etFarmer = findViewById(R.id.etFarmer);
        etDate = findViewById(R.id.etDate);
        etCrop = findViewById(R.id.etCrop);
        etQuantity = findViewById(R.id.etQuantity);
        etNotes = findViewById(R.id.etNotes);
        rgType = findViewById(R.id.rgType);
        spPoint = findViewById(R.id.spPoint);
        cbReceipt = findViewById(R.id.cbReceipt);
        tvPointSelected = findViewById(R.id.tvPointSelected);
        tvPointStatus = findViewById(R.id.tvPointStatus);
        scrollForm = findViewById(R.id.scrollForm);
        tvCount = findViewById(R.id.tvCount);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvTrace = findViewById(R.id.tvTrace);
        ListView lvRecords = findViewById(R.id.lvRecords);

        records = restoreRecords(savedInstanceState);
        adapter = new RecordAdapter(this, records);
        lvRecords.setAdapter(adapter);

        // Lab 4: collection -> adapter -> Spinner
        pointAdapter = new CollectionPointAdapter(this, pointRows);
        spPoint.setAdapter(pointAdapter);
        spPoint.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long rowId) {
                onPointSelected(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                trace(TAG_SEL, "nothing selected");
                updatePointViews();
            }
        });
        cbReceipt.setOnCheckedChangeListener((b, checked) ->
                trace(TAG_SEL, "CHECKBOX paper receipt -> " + (checked ? "on" : "off")
                        + " (point unchanged: " + selectedPointIdOrPrompt() + ")"));

        String restoredPointId = null, restoredPointName = null, restoredStatus = null;
        boolean reopenDialog = false;
        if (savedInstanceState != null) {
            listVariant = CollectionPoints.Variant.valueOf(
                    savedInstanceState.getString(KEY_LIST_VARIANT, CollectionPoints.Variant.STANDARD.name()));
            restoredPointId = savedInstanceState.getString(KEY_POINT_ID, null);
            restoredPointName = savedInstanceState.getString(KEY_POINT_NAME, null);
            restoredStatus = savedInstanceState.getString(KEY_POINT_STATUS, null);
            cbReceipt.setChecked(savedInstanceState.getBoolean(KEY_RECEIPT, false));
            etFarmer.setText(savedInstanceState.getString(KEY_FARMER, ""));
            etDate.setText(savedInstanceState.getString(KEY_DATE, ""));
            etCrop.setText(savedInstanceState.getString(KEY_CROP, ""));
            etQuantity.setText(savedInstanceState.getString(KEY_QTY, ""));
            etNotes.setText(savedInstanceState.getString(KEY_NOTES, ""));
            rgType.check(savedInstanceState.getInt(KEY_TYPE, R.id.rbDelivery));
            reopenDialog = savedInstanceState.getBoolean(KEY_DIALOG_OPEN, false);
        }

        loadPoints(restoredPointId, restoredPointName,
                savedInstanceState == null ? "first load" : "restored after recreation");
        if (restoredStatus != null && tvPointStatus.getVisibility() != View.VISIBLE && selectedPoint() == null) {
            showPointStatus(restoredStatus);   // e.g. keep "CP-03 is no longer available" after rotation
        }

        findViewById(R.id.btnSubmit).setOnClickListener(v -> onSubmitClicked());
        findViewById(R.id.btnPickDate).setOnClickListener(v -> showDatePicker());
        Button btnClearTrace = findViewById(R.id.btnClearTrace);
        btnClearTrace.setOnClickListener(v -> {
            TRACE.setLength(0);
            tvTrace.setText("");
        });

        refreshCount();
        trace(TAG, "onCreate (savedInstanceState " + (savedInstanceState == null ? "NULL" : "present")
                + ", records restored=" + records.size() + ")");

        if (reopenDialog) {
            // The dialog window belonged to the destroyed Activity. Rebuild it from the
            // restored draft (the single source of truth) instead of saving a second copy.
            trace(TAG_FORM, "DIALOG was open before recreation -> re-validating restored draft");
            validateAndConfirm();
        }
    }

    @Override protected void onStart() { super.onStart(); trace(TAG, "onStart"); }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        trace(TAG, "onRestoreInstanceState");
    }

    @Override
    protected void onResume() {
        super.onResume();
        navigating = false;                // back on this screen: View records may be opened again
        trace(TAG, "onResume");           // also redraws lines written by RecordsActivity
    }
    @Override protected void onPause() { trace(TAG, "onPause"); super.onPause(); }
    @Override protected void onStop() { trace(TAG, "onStop"); super.onStop(); }
    @Override protected void onRestart() { super.onRestart(); trace(TAG, "onRestart"); }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(KEY_FARMER, text(etFarmer));
        outState.putString(KEY_DATE, text(etDate));
        outState.putString(KEY_CROP, text(etCrop));
        outState.putString(KEY_QTY, text(etQuantity));
        outState.putString(KEY_NOTES, text(etNotes));
        outState.putInt(KEY_TYPE, rgType.getCheckedRadioButtonId());
        CollectionPoint sel = selectedPoint();
        outState.putString(KEY_POINT_ID, sel == null ? null : sel.getId());
        outState.putString(KEY_POINT_NAME, sel == null ? null : sel.getName());
        outState.putString(KEY_POINT_STATUS, tvPointStatus.getVisibility() == View.VISIBLE
                ? tvPointStatus.getText().toString() : null);
        outState.putBoolean(KEY_RECEIPT, cbReceipt.isChecked());
        outState.putString(KEY_LIST_VARIANT, listVariant.name());
        outState.putSerializable(KEY_RECORDS, records);
        boolean open = confirmDialog != null && confirmDialog.isShowing();
        outState.putBoolean(KEY_DIALOG_OPEN, open);
        trace(TAG, "onSaveInstanceState (draft + " + records.size() + " records, dialogOpen=" + open
                + ", point=" + selectedPointIdOrPrompt() + ")");
    }

    @Override
    protected void onDestroy() {
        trace(TAG, "onDestroy (isChangingConfigurations=" + isChangingConfigurations()
                + ", isFinishing=" + isFinishing() + ")");
        if (confirmDialog != null) {
            confirmDialog.setOnDismissListener(null);
            confirmDialog.dismiss();        // avoids a leaked window on rotation
            confirmDialog = null;
        }
        super.onDestroy();
    }

    // ---------------------------------------------------------------- event flow

    /** Step 1: click. Step 2: validate. Step 3a: errors, or 3b: dialog. */
    private void onSubmitClicked() {
        trace(TAG_FORM, "SUBMIT clicked (records=" + records.size() + ")");
        validateAndConfirm();
    }

    private void validateAndConfirm() {
        clearErrors();
        TransactionType type = selectedType();
        CollectionPoint point = selectedPoint();
        RecordValidator.Result result = RecordValidator.validateEntry(
                text(etFarmer), text(etDate), text(etCrop), text(etQuantity), type,
                point == null ? null : point.getId(), point == null ? null : point.getName(),
                CollectionPoints.ids(pointRows), text(etNotes), cbReceipt.isChecked(), new Date());
        trace(TAG_SEL, "SUBMIT uses point id=" + selectedPointIdOrPrompt()
                + " (position " + spPoint.getSelectedItemPosition() + " is not stored)");

        if (!result.valid) {
            for (Map.Entry<RecordValidator.Field, String> e : result.errors.entrySet()) {
                EditText field = fieldFor(e.getKey());
                if (field != null) field.setError(e.getValue());
            }
            if (result.errors.containsKey(RecordValidator.Field.POINT)) {
                showPointStatus(result.errors.get(RecordValidator.Field.POINT));
            }
            EditText first = fieldFor(result.field);
            if (first != null) {
                first.requestFocus();
            } else if (result.field == RecordValidator.Field.POINT) {
                View label = findViewById(R.id.tvPointLabel);
                scrollForm.post(() -> scrollForm.smoothScrollTo(0, label.getTop()));
            }
            Toast.makeText(this, R.string.toast_fix_errors, Toast.LENGTH_SHORT).show();
            trace(TAG_FORM, "VALIDATION failed " + result.errors.keySet()
                    + " -> no dialog, nothing committed (records=" + records.size() + ")");
            return;
        }

        trace(TAG_FORM, "VALIDATION ok -> dialog shown, nothing committed yet (records=" + records.size() + ")");
        showConfirmDialog(result.record);
    }

    /** Displaying the dialog is only a question; it does not touch the records list. */
    private void showConfirmDialog(FarmerRecord pending) {
        confirmDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_title)
                .setMessage(pending.summary() + "\n\n" + getString(R.string.dialog_footer))
                .setPositiveButton(R.string.dialog_confirm, (d, which) -> commit(pending))
                .setNegativeButton(R.string.dialog_edit, (d, which) ->
                        trace(TAG_FORM, "EDIT -> dialog closed, draft kept, nothing committed (records="
                                + records.size() + ")"))
                .setOnCancelListener(d ->
                        trace(TAG_FORM, "CANCEL (Back / tap outside) -> draft kept, nothing committed (records="
                                + records.size() + ")"))
                .create();
        confirmDialog.setOnDismissListener(d -> confirmDialog = null);
        confirmDialog.show();
    }

    /** The ONLY place a record enters the list. Clearing the draft happens after it. */
    private void commit(FarmerRecord record) {
        records.add(record);
        adapter.notifyDataSetChanged();
        refreshCount();
        // The trace and Toast name the record number, not the farmer, so feedback does not
        // expose personal details on screen or in Logcat.
        trace(TAG_FORM, "CONFIRM -> committed record #" + records.size()
                + " at " + record.getPointId() + ", receipt=" + record.isPaperReceipt()
                + " (records=" + records.size() + ", in memory only)");

        // Clear only what changes per farmer. Date, crop and type are kept because an
        // officer usually records several farmers for the same day and crop.
        etFarmer.setText("");
        etQuantity.setText("");
        etNotes.setText("");
        cbReceipt.setChecked(false);      // per-farmer preference; the point is kept for the next farmer
        clearErrors();
        etFarmer.requestFocus();
        Toast.makeText(this, R.string.toast_committed, Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- options menu (Lab 3)

    /** Attaches res/menu/main_menu.xml to this screen's app bar. Called again after rotation. */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        trace(TAG_MENU, "onCreateOptionsMenu -> menu inflated (" + menu.size() + " items, no action run)");
        return true;
    }

    /**
     * One entry point for every menu selection. if/else on the item ID (resource IDs are
     * not compile-time constants in AGP 8, so a switch on R.id is not allowed).
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        trace(TAG_MENU, "SELECTED id=0x" + Integer.toHexString(id) + " (\"" + item.getTitle() + "\")");

        if (id == R.id.action_new_record) {
            onNewRecord();
            return true;
        } else if (id == R.id.action_view_records) {
            openRecords();
            return true;
        } else if (id == R.id.action_about) {
            showAbout();
            return true;
        } else if (id == R.id.action_sensor_inventory) {
            trace(TAG_NAV, "SENSOR INVENTORY -> starting SensorsActivity (draft kept)");
            startActivity(new Intent(this, SensorsActivity.class));
            return true;
        } else if (id == R.id.action_live_sensor) {
            trace(TAG_NAV, "LIVE SENSOR -> starting LiveSensorActivity (draft kept)");
            startActivity(new Intent(this, LiveSensorActivity.class));
            return true;
        } else if (id == R.id.action_point_list) {
            return super.onOptionsItemSelected(item);   // just opens the submenu
        } else if (id == R.id.action_list_standard) {
            switchList(CollectionPoints.Variant.STANDARD, item);
            return true;
        } else if (id == R.id.action_list_reordered) {
            switchList(CollectionPoints.Variant.REORDERED, item);
            return true;
        } else if (id == R.id.action_list_cp03_closed) {
            switchList(CollectionPoints.Variant.CP03_CLOSED, item);
            return true;
        } else if (id == R.id.action_list_empty) {
            switchList(CollectionPoints.Variant.EMPTY, item);
            return true;
        } else if (id == R.id.action_clear_trace) {
            TRACE.setLength(0);
            tvTrace.setText("");
            Toast.makeText(this, R.string.toast_trace_cleared, Toast.LENGTH_SHORT).show();
            return true;
        }

        // Unknown or unhandled item: do nothing harmful, leave a trace for diagnosis,
        // and let the framework handle it (e.g. the Up button).
        trace(TAG_MENU, "UNHANDLED id=0x" + Integer.toHexString(id) + " -> passed to super, no action");
        return super.onOptionsItemSelected(item);
    }

    /** Ticks the current option-list variant in the submenu. */
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        int checkedId = listVariant == CollectionPoints.Variant.REORDERED ? R.id.action_list_reordered
                : listVariant == CollectionPoints.Variant.CP03_CLOSED ? R.id.action_list_cp03_closed
                : listVariant == CollectionPoints.Variant.EMPTY ? R.id.action_list_empty
                : R.id.action_list_standard;
        MenuItem mi = menu.findItem(checkedId);
        if (mi != null) mi.setChecked(true);
        return super.onPrepareOptionsMenu(menu);
    }

    // ---------------------------------------------------------------- Lab 4 selection

    /** Replaces the Spinner's source collection, keeping the selection by id if it still exists. */
    private void switchList(CollectionPoints.Variant v, MenuItem item) {
        listVariant = v;
        item.setChecked(true);
        CollectionPoint cur = selectedPoint();
        loadPoints(cur == null ? null : cur.getId(), cur == null ? null : cur.getName(), "list changed");
        Toast.makeText(this, getString(R.string.toast_list_changed, item.getTitle()), Toast.LENGTH_SHORT).show();
    }

    /**
     * Rebuilds the rows (prompt + current points), tells the adapter, then restores the
     * selection by stable id. Missing id -> prompt + warning; empty list -> disabled Spinner.
     */
    private void loadPoints(String keepId, String keepName, String reason) {
        int oldPos = spPoint.getSelectedItemPosition();
        List<CollectionPoint> real = CollectionPoints.load(listVariant);
        boolean empty = real.isEmpty();

        pointRows.clear();
        pointRows.addAll(CollectionPoints.withPrompt(real,
                getString(empty ? R.string.point_prompt_empty : R.string.point_prompt)));
        pointAdapter.notifyDataSetChanged();
        spPoint.setEnabled(!empty);

        int pos = CollectionPoints.indexOfId(pointRows, keepId);
        if (empty) {
            spPoint.setSelection(0, false);
            showPointStatus(getString(R.string.point_empty_state));
            trace(TAG_SEL, "LIST " + listVariant + " (" + reason + ") -> 0 points: empty state, Spinner disabled");
        } else if (keepId != null && pos < 0) {
            spPoint.setSelection(0, false);
            showPointStatus(getString(R.string.point_removed, keepName + " (" + keepId + ")"));
            trace(TAG_SEL, "LIST " + listVariant + " (" + reason + ") -> " + keepId
                    + " no longer available: reset to prompt, warning shown");
        } else {
            spPoint.setSelection(Math.max(pos, 0), false);
            hidePointStatus();
            trace(TAG_SEL, "LIST " + listVariant + " (" + real.size() + " points, " + reason + ") -> "
                    + (keepId == null ? "prompt" : keepId + " restored by id at position " + pos
                    + (oldPos >= 0 && oldPos != pos ? " (was " + oldPos + ")" : "")));
        }
        updatePointViews();
    }

    private void onPointSelected(int position) {
        CollectionPoint p = pointAdapter.getItem(position);
        if (p == null) return;
        if (p.isPrompt()) {
            trace(TAG_SEL, "SELECTED pos=" + position + " prompt -> no choice (id=null)");
        } else {
            if (!CollectionPoints.ids(pointRows).isEmpty()) hidePointStatus();
            trace(TAG_SEL, "SELECTED pos=" + position + " id=" + p.getId() + " label=\"" + p.getName() + "\"");
        }
        updatePointViews();
    }

    /** The selected real point, or null when the prompt (or nothing) is selected. */
    private CollectionPoint selectedPoint() {
        Object o = spPoint.getSelectedItem();
        if (!(o instanceof CollectionPoint)) return null;
        CollectionPoint p = (CollectionPoint) o;
        return p.isPrompt() ? null : p;
    }

    private String selectedPointIdOrPrompt() {
        CollectionPoint p = selectedPoint();
        return p == null ? "prompt" : p.getId();
    }

    /** Confirmation view under the Spinner: the label the officer will see in the record. */
    private void updatePointViews() {
        CollectionPoint p = selectedPoint();
        tvPointSelected.setText(p == null ? getString(R.string.point_none_selected)
                : getString(R.string.point_selected, p.getName() + " (" + p.getId() + ")"));
    }

    private void showPointStatus(String msg) {
        tvPointStatus.setText(msg);
        tvPointStatus.setVisibility(View.VISIBLE);
    }

    private void hidePointStatus() {
        tvPointStatus.setVisibility(View.GONE);
    }

    /** New record: an unsaved-work warning must stay until the user decides, so it is a dialog, not a Toast. */
    private void onNewRecord() {
        if (!hasUnsavedInput()) {
            Toast.makeText(this, R.string.toast_form_already_empty, Toast.LENGTH_SHORT).show();
            trace(TAG_MENU, "NEW RECORD -> form already empty, nothing to clear");
            return;
        }
        trace(TAG_MENU, "NEW RECORD -> unsaved input, asking before clearing");
        new AlertDialog.Builder(this)
                .setTitle(R.string.discard_title)
                .setMessage(R.string.discard_message)
                .setPositiveButton(R.string.discard_yes, (d, w) -> {
                    clearForm();
                    Toast.makeText(this, R.string.toast_form_cleared, Toast.LENGTH_SHORT).show();
                    trace(TAG_MENU, "NEW RECORD -> discarded draft (records=" + records.size() + ", unchanged)");
                })
                .setNegativeButton(R.string.discard_no, (d, w) ->
                        trace(TAG_MENU, "NEW RECORD -> kept draft"))
                .show();
    }

    /** View records: the one action that changes the screen. */
    private void openRecords() {
        if (navigating) {
            trace(TAG_NAV, "VIEW RECORDS ignored (already opening)");
            return;
        }
        navigating = true;
        Intent intent = new Intent(this, RecordsActivity.class);
        intent.putExtra(RecordsActivity.EXTRA_RECORDS, new ArrayList<>(records));   // read-only copy
        trace(TAG_NAV, "VIEW RECORDS -> starting RecordsActivity (" + records.size() + " records, draft kept)");
        startActivity(intent);
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.about_title)
                .setMessage(R.string.about_message)
                .setPositiveButton(R.string.ok, null)
                .show();
        trace(TAG_MENU, "ABOUT -> dialog shown");
    }

    /** True if any typed field holds a value that has not been committed. */
    private boolean hasUnsavedInput() {
        return !text(etFarmer).trim().isEmpty() || !text(etDate).trim().isEmpty()
                || !text(etCrop).trim().isEmpty() || !text(etQuantity).trim().isEmpty()
                || !text(etNotes).trim().isEmpty();
    }

    private void clearForm() {
        etFarmer.setText("");
        etDate.setText("");
        etCrop.setText("");
        etQuantity.setText("");
        etNotes.setText("");
        rgType.check(R.id.rbDelivery);
        spPoint.setSelection(0);
        cbReceipt.setChecked(false);
        clearErrors();
        etFarmer.requestFocus();
    }

    // ---------------------------------------------------------------- helpers

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        try {   // open on the typed date if it is valid
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            f.setLenient(false);
            Date typed = f.parse(text(etDate).trim());
            if (typed != null) c.setTime(typed);
        } catch (Exception ignored) { }

        DatePickerDialog dlg = new DatePickerDialog(this, (view, y, m, d) -> {
            etDate.setText(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d));
            etDate.setError(null);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.getDatePicker().setMaxDate(System.currentTimeMillis());   // no future dates
        dlg.show();
    }

    private TransactionType selectedType() {
        return rgType.getCheckedRadioButtonId() == R.id.rbHarvest
                ? TransactionType.WEEKLY_HARVEST : TransactionType.DELIVERY;
    }

    private EditText fieldFor(RecordValidator.Field f) {
        switch (f) {
            case FARMER: return etFarmer;
            case DATE: return etDate;
            case CROP: return etCrop;
            case QUANTITY: return etQuantity;
            case NOTES: return etNotes;
            default: return null;
        }
    }

    private void clearErrors() {
        etFarmer.setError(null);
        etDate.setError(null);
        etCrop.setError(null);
        etQuantity.setError(null);
        etNotes.setError(null);
        if (!CollectionPoints.ids(pointRows).isEmpty()) hidePointStatus();   // the empty-list message stays
    }

    private static String text(EditText e) {
        return e.getText().toString();
    }

    private void refreshCount() {
        tvCount.setText(getString(R.string.record_count, records.size()));
        tvEmpty.setVisibility(records.isEmpty() ? TextView.VISIBLE : TextView.GONE);
    }

    @SuppressWarnings("unchecked")
    private static ArrayList<FarmerRecord> restoreRecords(Bundle state) {
        if (state != null) {
            Object saved = state.getSerializable(KEY_RECORDS);
            if (saved instanceof ArrayList) return (ArrayList<FarmerRecord>) saved;
        }
        return new ArrayList<>();
    }

    /** Writes to Logcat and to the on-screen trace, tagged with this Activity instance. */
    private void trace(String tag, String event) {
        write(tag, "act=" + Integer.toHexString(System.identityHashCode(this)), event);
        if (tvTrace != null) tvTrace.setText(TRACE);
    }

    /**
     * Used by the other screens; MainActivity redraws the trace box in onResume.
     * Lab 6 fix: the source label used to be "screen=Records" for every caller, so
     * Live sensor and Sensor inventory lines were mislabelled. It now follows the tag.
     */
    static void appendTrace(String tag, String event) {
        String source = LiveSensorActivity.TAG_LIVE.equals(tag) ? "screen=Live"
                : SensorsActivity.TAG_SENSOR.equals(tag) ? "screen=Sensors"
                : "screen=Records";
        write(tag, source, event);
    }

    private static void write(String tag, String source, String event) {
        String time = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
        String prefix = LiveSensorActivity.TAG_LIVE.equals(tag) ? "LIVE "
                : SensorsActivity.TAG_SENSOR.equals(tag) ? "SENS "
                : TAG_SEL.equals(tag) ? "SEL "
                : TAG_FORM.equals(tag) ? "FORM "
                : TAG_MENU.equals(tag) ? "MENU "
                : TAG_NAV.equals(tag) ? "NAV " : "";
        String line = time + " pid=" + Process.myPid() + " " + source + " " + prefix + event;
        Log.d(tag, line);
        TRACE.append(line).append('\n');
    }
}
