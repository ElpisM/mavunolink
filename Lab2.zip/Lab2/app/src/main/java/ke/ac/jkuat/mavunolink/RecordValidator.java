package ke.ac.jkuat.mavunolink;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Validation rules, kept free of Android classes so they run as plain JUnit tests.
 *
 * Lab 1 rules (validate):
 *  farmer required (<= 40), crop required (<= 30), quantity a plain finite decimal,
 *  not negative, zero only for WEEKLY_HARVEST, <= 100 000 kg.
 *
 * Lab 2 rules (validateForm) add:
 *  date   required, exactly yyyy-MM-dd, a real calendar date (no 2026-02-30),
 *         not in the future, not more than MAX_AGE_DAYS before today.
 *  notes  optional; trimmed; empty becomes null; max MAX_NOTES_LEN characters.
 *
 * validateForm checks EVERY field and returns all errors, so the user sees every
 * problem at once; the first error (in on-screen order) receives focus.
 */
public final class RecordValidator {

    public static final int MAX_FARMER_LEN = 40;
    public static final int MAX_CROP_LEN = 30;
    public static final int MAX_NOTES_LEN = 120;
    public static final double MAX_KG = 100_000.0;
    public static final int MAX_AGE_DAYS = 365;

    private static final Pattern PLAIN_DECIMAL =
            Pattern.compile("^[+-]?(\\d+(\\.\\d*)?|\\.\\d+)$");
    private static final Pattern ISO_DATE = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");

    /** Fields in on-screen order; that order decides which error gets focus. */
    public enum Field { FARMER, DATE, CROP, QUANTITY, NOTES, NONE }

    public static final class Result {
        public final boolean valid;
        public final Field field;          // first failing field (on-screen order)
        public final String message;       // message for that field
        public final Map<Field, String> errors;
        public final FarmerRecord record;

        private Result(Map<Field, String> errors, FarmerRecord record) {
            this.errors = Collections.unmodifiableMap(errors);
            this.valid = errors.isEmpty();
            Field first = Field.NONE;
            for (Field f : Field.values()) {
                if (errors.containsKey(f)) { first = f; break; }
            }
            this.field = first;
            this.message = errors.get(first);
            this.record = record;
        }
    }

    private RecordValidator() { }

    // ------------------------------------------------------------------ Lab 1 entry point

    public static Result validate(String farmerRaw, String cropRaw, String quantityRaw,
                                  TransactionType type) {
        Map<Field, String> errors = new EnumMap<>(Field.class);
        String farmer = trim(farmerRaw), crop = trim(cropRaw);
        putIfError(errors, Field.FARMER, checkFarmer(farmer));
        putIfError(errors, Field.CROP, checkCrop(crop));
        double[] kg = new double[1];
        putIfError(errors, Field.QUANTITY, checkQuantity(trim(quantityRaw), type, kg));
        FarmerRecord r = errors.isEmpty() ? new FarmerRecord(farmer, crop, kg[0], type) : null;
        return new Result(errors, r);
    }

    // ------------------------------------------------------------------ Lab 2 entry point

    /**
     * @param today the current date, passed in so tests are not tied to the real clock.
     */
    public static Result validateForm(String farmerRaw, String dateRaw, String cropRaw,
                                      String quantityRaw, TransactionType type,
                                      String notesRaw, Date today) {
        Map<Field, String> errors = new EnumMap<>(Field.class);
        String farmer = trim(farmerRaw), date = trim(dateRaw), crop = trim(cropRaw);
        String notes = trim(notesRaw);

        putIfError(errors, Field.FARMER, checkFarmer(farmer));
        putIfError(errors, Field.DATE, checkDate(date, today));
        putIfError(errors, Field.CROP, checkCrop(crop));
        double[] kg = new double[1];
        putIfError(errors, Field.QUANTITY, checkQuantity(trim(quantityRaw), type, kg));
        if (notes.length() > MAX_NOTES_LEN) {
            errors.put(Field.NOTES, "Notes must be at most " + MAX_NOTES_LEN + " characters");
        }

        FarmerRecord r = errors.isEmpty()
                ? new FarmerRecord(farmer, crop, kg[0], type, date, notes.isEmpty() ? null : notes)
                : null;
        return new Result(errors, r);
    }

    // ------------------------------------------------------------------ individual rules

    static String checkFarmer(String farmer) {
        if (farmer.isEmpty()) return "Farmer reference or name is required";
        if (farmer.length() > MAX_FARMER_LEN) return "Farmer reference is too long (max " + MAX_FARMER_LEN + ")";
        return null;
    }

    static String checkCrop(String crop) {
        if (crop.isEmpty()) return "Crop is required";
        if (crop.length() > MAX_CROP_LEN) return "Crop name is too long (max " + MAX_CROP_LEN + ")";
        return null;
    }

    /** On success writes the parsed value into out[0] and returns null. */
    static String checkQuantity(String qty, TransactionType type, double[] out) {
        if (qty.isEmpty()) return "Quantity is required";
        if (!PLAIN_DECIMAL.matcher(qty).matches()) {
            return "Quantity must be a plain number in kg, e.g. 120 or 85.5 (no units, commas or letters)";
        }
        double kg;
        try {
            kg = Double.parseDouble(qty);
        } catch (NumberFormatException e) {
            return "Quantity is not a valid number";
        }
        if (Double.isNaN(kg) || Double.isInfinite(kg)) return "Quantity is too large to be a real value";
        if (kg < 0) return "Quantity cannot be negative";
        if (kg == 0) {
            if (!type.isZeroAllowed()) {
                return "A delivery must be more than 0 kg (use Weekly harvest to report a zero week)";
            }
            kg = 0.0;   // normalise -0.0
        }
        if (kg > MAX_KG) return "Quantity exceeds " + (long) MAX_KG + " kg; check the entry";
        out[0] = kg;
        return null;
    }

    static String checkDate(String date, Date today) {
        if (date.isEmpty()) return "Date is required (yyyy-mm-dd)";
        if (!ISO_DATE.matcher(date).matches()) return "Use the format yyyy-mm-dd, e.g. 2026-11-18";

        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        fmt.setLenient(false);               // rejects 2026-02-30 and 2026-13-01
        Date d;
        try {
            d = fmt.parse(date);
        } catch (ParseException e) {
            return "That date does not exist on the calendar";
        }

        Date todayStart = startOfDay(today);
        if (d.after(todayStart)) return "Date cannot be in the future";

        Calendar oldest = Calendar.getInstance();
        oldest.setTime(todayStart);
        oldest.add(Calendar.DAY_OF_YEAR, -MAX_AGE_DAYS);
        if (d.before(oldest.getTime())) {
            return "Date is more than " + MAX_AGE_DAYS + " days ago; late entries need a supervisor";
        }
        return null;
    }

    // ------------------------------------------------------------------ helpers

    private static Date startOfDay(Date when) {
        Calendar c = Calendar.getInstance();
        c.setTime(when);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTime();
    }

    private static String trim(String s) {
        return s == null ? "" : s.trim();
    }

    private static void putIfError(Map<Field, String> errors, Field f, String msg) {
        if (msg != null) errors.put(f, msg);
    }
}
