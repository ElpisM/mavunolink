package ke.ac.jkuat.mavunolink;

/**
 * The business event being recorded. The zero rule belongs to the event,
 * not to the "quantity" field in general:
 *
 *  - DELIVERY: produce physically handed over to a MavunoLink collection point.
 *    A 0 kg delivery is meaningless (nothing changed hands), so quantity must be > 0.
 *  - WEEKLY_HARVEST: the farmer's harvest report for the week. A 0 kg week is a
 *    real, useful fact (crop failure, off-season, drought) and must be recordable,
 *    otherwise "no report" and "reported nothing harvested" look the same.
 */
public enum TransactionType {
    DELIVERY("Delivery", false),
    WEEKLY_HARVEST("Weekly harvest", true);

    private final String label;
    private final boolean zeroAllowed;

    TransactionType(String label, boolean zeroAllowed) {
        this.label = label;
        this.zeroAllowed = zeroAllowed;
    }

    public String getLabel() {
        return label;
    }

    public boolean isZeroAllowed() {
        return zeroAllowed;
    }
}
