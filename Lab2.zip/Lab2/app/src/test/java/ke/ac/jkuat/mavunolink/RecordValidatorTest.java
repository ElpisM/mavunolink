package ke.ac.jkuat.mavunolink;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/** Run with: ./gradlew test  (plain JVM, no emulator needed). */
public class RecordValidatorTest {

    private static RecordValidator.Result v(String f, String c, String q, TransactionType t) {
        return RecordValidator.validate(f, c, q, t);
    }

    private static void rejects(String f, String c, String q, TransactionType t,
                                RecordValidator.Field expected) {
        RecordValidator.Result r = v(f, c, q, t);
        assertFalse("expected reject for qty='" + q + "' farmer='" + f + "'", r.valid);
        assertEquals(expected, r.field);
    }

    // V1 valid record
    @Test public void validDelivery() {
        RecordValidator.Result r = v("  FRM-001 ", "Maize", " 120.5 ", TransactionType.DELIVERY);
        assertTrue(r.valid);
        assertEquals("FRM-001", r.record.getFarmerRef());   // trimmed
        assertEquals(120.5, r.record.getQuantityKg(), 0.0);
    }

    // V2-V3 identity
    @Test public void blankFarmerRejected() {
        rejects("", "Maize", "10", TransactionType.DELIVERY, RecordValidator.Field.FARMER);
        rejects("   ", "Maize", "10", TransactionType.DELIVERY, RecordValidator.Field.FARMER);
        rejects(null, "Maize", "10", TransactionType.DELIVERY, RecordValidator.Field.FARMER);
    }

    @Test public void blankCropRejected() {
        rejects("FRM-001", " ", "10", TransactionType.DELIVERY, RecordValidator.Field.CROP);
    }

    // V4 blank quantity
    @Test public void blankQuantityRejected() {
        rejects("FRM-001", "Maize", "", TransactionType.DELIVERY, RecordValidator.Field.QUANTITY);
        rejects("FRM-001", "Maize", "   ", TransactionType.WEEKLY_HARVEST, RecordValidator.Field.QUANTITY);
    }

    // V5 negative
    @Test public void negativeRejected() {
        rejects("FRM-001", "Maize", "-5", TransactionType.DELIVERY, RecordValidator.Field.QUANTITY);
        rejects("FRM-001", "Maize", "-0.1", TransactionType.WEEKLY_HARVEST, RecordValidator.Field.QUANTITY);
    }

    // V6 malformed / non-numeric
    @Test public void malformedRejected() {
        String[] bad = {"abc", "12kg", "1,200", "12.5.3", "1e3", "0x10", "12d", "12f", "--5", ".", "+", "5 0"};
        for (String q : bad) {
            rejects("FRM-001", "Maize", q, TransactionType.DELIVERY, RecordValidator.Field.QUANTITY);
        }
    }

    // V7 non-finite
    @Test public void nonFiniteRejected() {
        rejects("FRM-001", "Maize", "NaN", TransactionType.DELIVERY, RecordValidator.Field.QUANTITY);
        rejects("FRM-001", "Maize", "Infinity", TransactionType.DELIVERY, RecordValidator.Field.QUANTITY);
        rejects("FRM-001", "Maize", "-Infinity", TransactionType.DELIVERY, RecordValidator.Field.QUANTITY);
        StringBuilder huge = new StringBuilder("1");
        for (int i = 0; i < 400; i++) huge.append('0');      // parses to Infinity
        RecordValidator.Result r = v("FRM-001", "Maize", huge.toString(), TransactionType.WEEKLY_HARVEST);
        assertFalse(r.valid);
        assertTrue(r.message.contains("too large"));
    }

    // V8-V9 zero depends on the business event
    @Test public void zeroRejectedForDelivery() {
        rejects("FRM-001", "Maize", "0", TransactionType.DELIVERY, RecordValidator.Field.QUANTITY);
        rejects("FRM-001", "Maize", "0.00", TransactionType.DELIVERY, RecordValidator.Field.QUANTITY);
        rejects("FRM-001", "Maize", "-0", TransactionType.DELIVERY, RecordValidator.Field.QUANTITY);
    }

    @Test public void zeroAcceptedForWeeklyHarvest() {
        RecordValidator.Result r = v("FRM-002", "Beans", "-0", TransactionType.WEEKLY_HARVEST);
        assertTrue(r.valid);
        assertEquals(0.0, r.record.getQuantityKg(), 0.0);
        assertEquals("0.00 kg", r.record.formattedQuantity());  // not "-0.00 kg"
    }

    // V10 sanity cap and accepted edge formats
    @Test public void aboveCapRejected() {
        rejects("FRM-001", "Maize", "100000.01", TransactionType.DELIVERY, RecordValidator.Field.QUANTITY);
        assertTrue(v("FRM-001", "Maize", "100000", TransactionType.DELIVERY).valid);
    }

    @Test public void acceptedNumberFormats() {
        assertTrue(v("FRM-001", "Maize", "85", TransactionType.DELIVERY).valid);
        assertTrue(v("FRM-001", "Maize", ".5", TransactionType.DELIVERY).valid);
        assertTrue(v("FRM-001", "Maize", "5.", TransactionType.DELIVERY).valid);
        assertTrue(v("FRM-001", "Maize", "+12", TransactionType.DELIVERY).valid);
    }
}
