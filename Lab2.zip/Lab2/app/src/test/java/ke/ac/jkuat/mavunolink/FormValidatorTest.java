package ke.ac.jkuat.mavunolink;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

/** Lab 2 form rules. "Today" is fixed at 2026-11-18 so results never depend on the clock. */
public class FormValidatorTest {

    private static final Date TODAY;
    static {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(2026, Calendar.NOVEMBER, 18, 14, 30);
        TODAY = c.getTime();
    }

    private static RecordValidator.Result form(String farmer, String date, String qty,
                                               TransactionType type, String notes) {
        return RecordValidator.validateForm(farmer, date, "Maize", qty, type, notes, TODAY);
    }

    // F1 valid complete form, optional notes empty
    @Test public void validFormWithoutNotes() {
        RecordValidator.Result r = form("FRM-001", "2026-11-18", "120", TransactionType.DELIVERY, "  ");
        assertTrue(r.valid);
        assertEquals("2026-11-18", r.record.getDate());
        assertNull(r.record.getNotes());               // empty optional field stored as "none"
        assertTrue(r.record.summary().contains("Notes: (none)"));
    }

    // F2 valid with notes
    @Test public void validFormWithNotes() {
        RecordValidator.Result r = form("FRM-002", "2026-11-11", "0", TransactionType.WEEKLY_HARVEST, " Dry week ");
        assertTrue(r.valid);
        assertEquals("Dry week", r.record.getNotes());
    }

    // F3 incomplete form: every missing required field reported, focus goes to the first
    @Test public void incompleteFormReportsAllErrors() {
        RecordValidator.Result r = RecordValidator.validateForm("", "", "", "", TransactionType.DELIVERY, "", TODAY);
        assertFalse(r.valid);
        assertEquals(4, r.errors.size());              // farmer, date, crop, quantity (notes optional)
        assertEquals(RecordValidator.Field.FARMER, r.field);
        assertFalse(r.errors.containsKey(RecordValidator.Field.NOTES));
    }

    // F4 malformed dates
    @Test public void malformedDateRejected() {
        String[] bad = {"18/11/2026", "2026-11-1", "20261118", "2026/11/18", "yesterday", "2026-11-18x"};
        for (String d : bad) {
            RecordValidator.Result r = form("FRM-001", d, "10", TransactionType.DELIVERY, "");
            assertEquals("date " + d, RecordValidator.Field.DATE, r.field);
        }
    }

    // F5 impossible calendar dates
    @Test public void impossibleDateRejected() {
        for (String d : new String[]{"2026-02-30", "2026-13-01", "2026-00-10", "2025-02-29"}) {
            RecordValidator.Result r = form("FRM-001", d, "10", TransactionType.DELIVERY, "");
            assertEquals("date " + d, RecordValidator.Field.DATE, r.field);
            assertTrue(r.message.contains("does not exist"));
        }
    }

    // F6 future and too-old dates; boundaries accepted
    @Test public void dateRangeEnforced() {
        assertEquals(RecordValidator.Field.DATE, form("FRM-001", "2026-11-19", "10", TransactionType.DELIVERY, "").field);
        assertEquals(RecordValidator.Field.DATE, form("FRM-001", "2025-11-17", "10", TransactionType.DELIVERY, "").field);
        assertTrue(form("FRM-001", "2026-11-18", "10", TransactionType.DELIVERY, "").valid);   // today
        assertTrue(form("FRM-001", "2025-11-18", "10", TransactionType.DELIVERY, "").valid);   // 365 days ago
    }

    // F7 numeric value still checked inside the form
    @Test public void invalidQuantityInForm() {
        RecordValidator.Result r = form("FRM-001", "2026-11-18", "12kg", TransactionType.DELIVERY, "");
        assertEquals(RecordValidator.Field.QUANTITY, r.field);
        r = form("FRM-001", "2026-11-18", "0", TransactionType.DELIVERY, "");
        assertEquals(RecordValidator.Field.QUANTITY, r.field);
    }

    // F8 optional field still has a limit
    @Test public void notesTooLong() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 121; i++) sb.append('x');
        RecordValidator.Result r = form("FRM-001", "2026-11-18", "10", TransactionType.DELIVERY, sb.toString());
        assertEquals(RecordValidator.Field.NOTES, r.field);
    }
}
