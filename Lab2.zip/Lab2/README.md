# Lab 1 project, extended for Lab_02_hm2 (ICS 2300)

Same project (Lab1, package `ke.ac.jkuat.mavunolink`) as Lab_01_hm1, extended with a
ConstraintLayout form, date and optional notes fields, AlertDialog confirmation and an
event trace. All Lab 1 behaviour (validation rules, list, count, lifecycle trace) is kept.

## Build and run

1. Android Studio, JDK 17, SDK 34. **File → Open → Lab1**, then Sync.
2. Run on an emulator (min API 24).
3. Unit tests: `./gradlew test`. Expected: 19 tests pass (11 Lab 1 + 8 Lab 2).
4. Logcat filter: `tag:MavunoForm | tag:MavunoLifecycle`. The same lines appear in the
   grey trace box below the Submit button (scroll down).

## What changed from Lab 1

| Area | Lab 1 | Lab 2 |
|---|---|---|
| Layout | LinearLayout, hint-only fields | ConstraintLayout form in a ScrollView, visible labels (`labelFor`), 48dp targets, `adjustResize` |
| Fields | farmer, crop, quantity, type | + **date** (typed or Pick button), + **notes (optional)** |
| Quantity input | `text` (to test the validator) | `numberDecimal` |
| Add | added immediately | **Submit → validate → AlertDialog → Confirm** commits; **Edit**/Back commits nothing |
| Errors | first field only | every invalid field marked at once; focus on the first |
| Rotation | draft + list saved | also date, notes, and whether the dialog was open (re-shown after rotation) |

## Event flow (one Submit)

```
Submit click → onSubmitClicked()            trace: FORM SUBMIT clicked (records=N)
  → validateForm(...)                        changes nothing
     invalid → setError on bad fields, focus first, Toast
                                             trace: FORM VALIDATION failed [..] -> no dialog (records=N)
     valid   → showConfirmDialog(record)     trace: FORM VALIDATION ok -> dialog shown, nothing committed yet (records=N)
         Confirm → commit(): records.add, notify adapter, count+1, clear farmer/qty/notes
                                             trace: FORM CONFIRM -> committed FRM-xxx (records=N+1)
         Edit    → dialog closes, every field still filled
                                             trace: FORM EDIT -> ... nothing committed (records=N)
         Back / tap outside                  trace: FORM CANCEL ... nothing committed (records=N)
```

The unchanged `records=N` on the EDIT/CANCEL lines and the unchanged "Committed records"
bar are the evidence that cancelling committed nothing.

## Test plan (evidence IDs)

| ID | Input / action | Expected |
|---|---|---|
| F1 | FRM-001, today, Maize, 120, Delivery, notes empty → Submit | Dialog with summary, "Notes: (none)" |
| F2 | F1 → Confirm | Count 0→1, row shows date; farmer/qty/notes cleared, date/crop kept |
| F3 | All fields empty → Submit | Errors on farmer, date, crop, quantity (not notes); focus on farmer; no dialog |
| F4 | Date `18/11/2026` or `2026-11-1` | "Use the format yyyy-mm-dd"; no dialog |
| F5 | Date `2026-02-30` | "That date does not exist on the calendar" |
| F6 | Tomorrow's date | "Date cannot be in the future" |
| F7 | Quantity `0` with Delivery; quantity `.` | Quantity error; no dialog |
| F8 | Valid form → Submit → **Edit** | Dialog closes, all values still there, count unchanged, trace "EDIT ... records=N" |
| F9 | Valid form → Submit → **Back** | Same as F8 with "CANCEL" |
| F10 | Valid form → Submit → **rotate** with dialog open | Dialog reappears with same summary; trace shows DIALOG re-validating after onCreate |
| F11 | Half-filled form → rotate | All six values kept |
| F12 | Small screen (e.g. Pixel 4a / 5", or Display size Largest) | Form scrolls; nothing cut off |
| F13 | Settings → Display → Font size largest | Labels and fields grow, no overlap, form scrolls |
| F14 | Tap Quantity with keyboard open | Field scrolls above keyboard (adjustResize); Next moves Farmer → Date → Crop → Quantity → Notes |

## Accessibility issue corrected

Lab 1 used hints as the only labels. Once a value was typed, the hint disappeared, so
nothing on screen said what the field was, and screen readers could read the value
without its name. Lab 2 adds a visible label above every field, linked with
`android:labelFor`, keeps hints only as example values, makes touch targets at least
48dp, and uses `sp` text sizes so the form follows the system font size.

## Known limitations

- Records are still in memory/saved state only (no database).
- The date picker dialog is not restored after rotation (the typed date is).
- Synthetic data only (FRM-001, FRM-002, ...).
