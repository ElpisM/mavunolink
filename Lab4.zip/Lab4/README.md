# Lab 1 project, extended for Lab_02_hm2, Lab_03_hm3 and Lab_04_hm4 (ICS 2300)

Same project (Lab1, package `ke.ac.jkuat.mavunolink`) as Lab_01_hm1, extended with a
ConstraintLayout form, date and optional notes fields, AlertDialog confirmation and an
event trace. All Lab 1 behaviour (validation rules, list, count, lifecycle trace) is kept.

## Build and run

1. Android Studio, JDK 17, SDK 34. **File → Open → Lab1**, then Sync.
2. Run on an emulator (min API 24).
3. Unit tests: `./gradlew test`. Expected: 27 tests pass (11 Lab 1 + 8 Lab 2 + 8 Lab 4).
4. Logcat filter: `tag:MavunoForm | tag:MavunoLifecycle`. The same lines appear in the
   grey trace box below the Submit button (scroll down).

## What changed from Lab 1

| Area | Lab 1 | Lab 2 |
|---|---|---|
| Layout | LinearLayout, hint-only fields | ConstraintLayout form in a ScrollView, visible labels (`labelFor`), 48dp targets, `adjustResize` |
| Fields | farmer, crop, quantity, type | + **date** (typed or Pick button), + **notes (optional)** |
| Quantity input | `text` (to test the validator) | `numberDecimal` |
| Add | added immediately | **Submit → validate → AlertDialog → Confirm** commits; **Edit**/Back commits nothing |
| Errors | first field only | every invalid field marked at once; focus on the first |
| Rotation | draft + list saved | also date, notes, and whether the dialog was open (re-shown after rotation) |

## Event flow (one Submit)

```
Submit click → onSubmitClicked()            trace: FORM SUBMIT clicked (records=N)
  → validateForm(...)                        changes nothing
     invalid → setError on bad fields, focus first, Toast
                                             trace: FORM VALIDATION failed [..] -> no dialog (records=N)
     valid   → showConfirmDialog(record)     trace: FORM VALIDATION ok -> dialog shown, nothing committed yet (records=N)
         Confirm → commit(): records.add, notify adapter, count+1, clear farmer/qty/notes
                                             trace: FORM CONFIRM -> committed FRM-xxx (records=N+1)
         Edit    → dialog closes, every field still filled
                                             trace: FORM EDIT -> ... nothing committed (records=N)
         Back / tap outside                  trace: FORM CANCEL ... nothing committed (records=N)
```

The unchanged `records=N` on the EDIT/CANCEL lines and the unchanged "Committed records"
bar are the evidence that cancelling committed nothing.

## Test plan (evidence IDs)

| ID | Input / action | Expected |
|---|---|---|
| F1 | FRM-001, today, Maize, 120, Delivery, notes empty → Submit | Dialog with summary, "Notes: (none)" |
| F2 | F1 → Confirm | Count 0→1, row shows date; farmer/qty/notes cleared, date/crop kept |
| F3 | All fields empty → Submit | Errors on farmer, date, crop, quantity (not notes); focus on farmer; no dialog |
| F4 | Date `18/11/2026` or `2026-11-1` | "Use the format yyyy-mm-dd"; no dialog |
| F5 | Date `2026-02-30` | "That date does not exist on the calendar" |
| F6 | Tomorrow's date | "Date cannot be in the future" |
| F7 | Quantity `0` with Delivery; quantity `.` | Quantity error; no dialog |
| F8 | Valid form → Submit → **Edit** | Dialog closes, all values still there, count unchanged, trace "EDIT ... records=N" |
| F9 | Valid form → Submit → **Back** | Same as F8 with "CANCEL" |
| F10 | Valid form → Submit → **rotate** with dialog open | Dialog reappears with same summary; trace shows DIALOG re-validating after onCreate |
| F11 | Half-filled form → rotate | All six values kept |
| F12 | Small screen (e.g. Pixel 4a / 5", or Display size Largest) | Form scrolls; nothing cut off |
| F13 | Settings → Display → Font size largest | Labels and fields grow, no overlap, form scrolls |
| F14 | Tap Quantity with keyboard open | Field scrolls above keyboard (adjustResize); Next moves Farmer → Date → Crop → Quantity → Notes |

## Accessibility issue corrected

Lab 1 used hints as the only labels. Once a value was typed, the hint disappeared, so
nothing on screen said what the field was, and screen readers could read the value
without its name. Lab 2 adds a visible label above every field, linked with
`android:labelFor`, keeps hints only as example values, makes touch targets at least
48dp, and uses `sp` text sizes so the form follows the system font size.

## Known limitations

- Records are still in memory/saved state only (no database).
- The date picker dialog is not restored after rotation (the typed date is).
- Synthetic data only (FRM-001, FRM-002, ...).


---

# Lab_03_hm3: options menu, navigation and Toast feedback

Logcat filter for this lab: `tag:MavunoMenu | tag:MavunoNav | tag:MavunoForm`.
The same lines appear in the grey trace box (scroll down the form).

## Menu-to-handler mapping

Menu resource: `app/src/main/res/menu/main_menu.xml`, inflated in
`MainActivity.onCreateOptionsMenu()`. Every selection goes to
`MainActivity.onOptionsItemSelected()`, which compares `item.getItemId()` with these IDs.

| Title | ID | Handler | Feedback |
|---|---|---|---|
| View records (app bar if room) | `action_view_records` | `openRecords()` → starts `RecordsActivity` | New screen (no Toast needed) |
| New record (overflow ⋮) | `action_new_record` | `onNewRecord()` | Empty form: Toast "Form is already empty". Unsaved input: **dialog** "Discard unsaved entry?" (stays until the user decides), then Toast "Entry discarded" |
| About (overflow) | `action_about` | `showAbout()` | AlertDialog (too long for a Toast) |
| Clear trace (overflow) | `action_clear_trace` | inline | Toast "Trace cleared" |
| anything else | – | logged `UNHANDLED`, passed to `super` | nothing happens, no crash |

## Event path: View records and Back

```
tap ⋮ / View records
 → onOptionsItemSelected(item)      trace: MENU SELECTED id=0x... ("View records")
 → openRecords()                    navigating=true (a second tap is ignored)
 → startActivity(RecordsActivity)   trace: NAV VIEW RECORDS -> starting ... (N records, draft kept)
     RecordsActivity.onCreate       trace: NAV RecordsActivity onCreate (showing N records, read-only)
 Back (or Up arrow)
 → RecordsActivity finishes         trace: NAV RecordsActivity onDestroy (isFinishing=true)
 → MainActivity.onResume            navigating=false; form and draft unchanged, records unchanged
```

RecordsActivity only displays a copy of the list; it has no save path, so Back cannot repeat
or undo anything. No menu handler calls `commit()`; only the Confirm button in the Lab 2
dialog does. `onCreateOptionsMenu()` runs again after rotation but only inflates the menu
(trace: "menu inflated ... no action run").

## Test plan

| ID | Action | Expected |
|---|---|---|
| M1 | ⋮ → View records (0 records) | Records screen, "0 committed record(s)", empty message |
| M2 | Confirm 2 records → View records | Both rows shown; count 2 |
| M3 | On Records screen press Back | Form returns with any draft intact; count unchanged; trace onDestroy isFinishing=true |
| M4 | On Records screen tap Up arrow | Same as M3, trace "UP pressed" |
| M5 | Double-tap View records quickly | One Records screen; trace "VIEW RECORDS ignored" or a single start |
| M6 | ⋮ → New record with empty form | Toast "Form is already empty" |
| M7 | Type a farmer → ⋮ → New record → Keep editing | Dialog; values kept |
| M8 | Same → Discard | Form cleared; Toast; records unchanged |
| M9 | ⋮ → About | Dialog with app info; OK closes it |
| M10 | ⋮ → Clear trace | Trace empty; Toast |
| M11 | Rotate on main screen, then open ⋮ | Menu still has 4 items; trace "menu inflated ... no action run"; record count unchanged |
| M12 | Rotate on Records screen, press Back | Records screen rebuilt with same list; Back returns once |
| M13 | Confirm a record | Toast "Record committed (in memory)"; trace says "record #N", not the farmer name |
| M14 | Deliberate fault (below) | Symptom, cause, fix, retest |

## Deliberate fault exercise (M14): an unhandled selection

1. **Introduce:** in `MainActivity.onOptionsItemSelected()` comment out the About branch:
   ```java
   // } else if (id == R.id.action_about) {
   //     showAbout();
   //     return true;
   ```
   (keep the braces balanced: the next line `} else if (id == R.id.action_clear_trace) {`
   stays). Run the app.
2. **Symptom:** ⋮ → About does nothing. No dialog, no crash.
3. **Evidence:** the trace shows `MENU SELECTED id=0x... ("About")` immediately followed by
   `MENU UNHANDLED id=0x... -> passed to super, no action`.
4. **Cause:** the menu item exists, but no branch matches its ID, so the selection falls
   through to the safe default at the end of the method.
5. **Correction:** remove the comment markers so the About branch is back.
6. **Retest:** ⋮ → About shows the dialog and the trace shows `ABOUT -> dialog shown`.

Why IDs and not titles: if the About item's id in `main_menu.xml` is renamed (for example to
`action_info`), the build fails immediately because `R.id.action_about` no longer exists.
A typo in a title string, or a translated title, would compile and fail silently if the code
compared labels.


---

# Lab_04_hm4: Spinner, ArrayAdapter and meaningful selection

Logcat filter: `tag:MavunoSelect | tag:MavunoForm`. Trace lines start with `SEL`.

## Data → adapter → view

```
CollectionPoints.load(variant)          source collection (List<CollectionPoint>, synthetic)
   + CollectionPoints.withPrompt(...)   row 0 = prompt (id == null), then real points
        │
        ▼
CollectionPointAdapter                  ArrayAdapter<CollectionPoint>
   getView()          → spinner_point_selected.xml   (closed Spinner, one line)
   getDropDownView()  → spinner_point_dropdown.xml   (two lines: name; id · area/schedule)
   isEnabled(0)=false → prompt cannot be picked
        │
        ▼
Spinner spPoint  (saveEnabled=false)
   onItemSelected(pos) → selected row → stable id "CP-03"
        │                                  │
        ▼                                  ▼
tvPointSelected "Selected: Thika       Bundle KEY_POINT_ID / FarmerRecord.pointId
Road Depot (CP-03)"                    (the saved model: id, never position)
```

| Point | ID | Standard position |
|---|---|---|
| Gatundu Market | CP-01 | 1 (first) |
| Juja Farm Gate | CP-02 | 2 |
| Thika Road Depot | CP-03 | 3 |
| Ruiru Cooperative Store | CP-04 | 4 |
| Kiambu Town Centre | CP-05 | 5 (last) |

Row 0 is the prompt "Choose a collection point…".

Test tool: **⋮ → Collection point list → Standard / Reordered / CP-03 closed / Empty**
swaps the source collection. Reordered order is CP-05, CP-03, CP-01, CP-04, CP-02.

The checkbox **Print a paper receipt for the farmer (optional)** is a separate yes/no
preference stored as `FarmerRecord.paperReceipt`. It does not change or depend on the point.

## Test plan

| ID | Action | Expected |
|---|---|---|
| S1 | Fill the form, leave the Spinner on the prompt, Submit | Red message "Choose a collection point" under the Spinner; no dialog |
| S2 | Open the Spinner | Prompt is greyed and cannot be tapped; real rows show name + id line |
| S3 | Choose Gatundu Market (first) → Submit → Confirm | Dialog shows "Collection point: Gatundu Market (CP-01)"; record row shows it |
| S4 | Choose Kiambu Town Centre (last) → Submit → Confirm | Same with CP-05 |
| S5 | Choose Thika Road Depot → rotate | Still Thika Road Depot; trace "CP-03 restored by id at position 3" |
| S6 | Thika selected → ⋮ → Collection point list → Reordered | Still Thika Road Depot, now at position 2; trace "(was 3)" |
| S7 | Thika selected → list → CP-03 closed | Spinner back to prompt; red "Thika Road Depot (CP-03) is no longer available"; Submit blocked |
| S8 | S7 then rotate | Warning still shown, prompt still selected |
| S9 | list → Empty | Spinner disabled showing "No collection points available"; empty-state message; Submit blocked with that message |
| S10 | list → Standard | Spinner enabled again with 5 points |
| S11 | Tick checkbox → Submit | Dialog "Paper receipt: yes"; trace "CHECKBOX ... on (point unchanged ...)" |
| S12 | Untick → Submit | "Paper receipt: no"; point unchanged |
| S13 | Settings → Display → Font size largest → open Spinner | Rows grow; two lines still readable; no clipping |
| S14 | Confirm a record | Point kept for the next farmer; checkbox reset |
