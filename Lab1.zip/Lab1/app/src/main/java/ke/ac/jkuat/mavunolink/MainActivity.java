package ke.ac.jkuat.mavunolink;

import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Data flow:  EditTexts (input) -> RecordValidator -> FarmerRecord (model)
 *             -> records ArrayList -> RecordAdapter -> ListView (visible list)
 *             and records.size() -> tvCount.
 *
 * State layers in this app:
 *  - Screen state:  the View objects and the `records` field. Destroyed with the
 *                   Activity on rotation.
 *  - Saved state:   the Bundle written in onSaveInstanceState (draft fields,
 *                   selected type, records list). Survives rotation and a
 *                   system-initiated process kill while the task is in Recents.
 *                   Lost on swipe-away, Force stop, reboot or reinstall.
 *  - Database:      NONE in this lab. Nothing here is persistent storage.
 *                   (Room/SQLite would be the next step for real MavunoLink records.)
 */
public class MainActivity extends AppCompatActivity {

    static final String TAG = "MavunoLifecycle";

    private static final String KEY_FARMER = "draft_farmer";
    private static final String KEY_CROP = "draft_crop";
    private static final String KEY_QTY = "draft_qty";
    private static final String KEY_TYPE = "draft_type";
    private static final String KEY_RECORDS = "records";

    /**
     * On-screen copy of the lifecycle trace. It is a static field, i.e. plain
     * process memory: it survives rotation (same process) but is wiped by a
     * process kill. That makes it a built-in demonstration of the difference.
     */
    private static final StringBuilder TRACE = new StringBuilder();

    private EditText etFarmer, etCrop, etQuantity;
    private RadioGroup rgType;
    private TextView tvCount, tvEmpty, tvTrace;

    private ArrayList<FarmerRecord> records;
    private RecordAdapter adapter;

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etFarmer = findViewById(R.id.etFarmer);
        etCrop = findViewById(R.id.etCrop);
        etQuantity = findViewById(R.id.etQuantity);
        rgType = findViewById(R.id.rgType);
        tvCount = findViewById(R.id.tvCount);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvTrace = findViewById(R.id.tvTrace);
        ListView lvRecords = findViewById(R.id.lvRecords);
        Button btnAdd = findViewById(R.id.btnAdd);
        Button btnClearTrace = findViewById(R.id.btnClearTrace);

        records = restoreRecords(savedInstanceState);
        adapter = new RecordAdapter(this, records);
        lvRecords.setAdapter(adapter);

        if (savedInstanceState != null) {
            // Explicit draft restore. EditTexts with IDs would also restore their own
            // text, but saving it ourselves documents the intent and keeps it working
            // if a field ever loses its ID or has saveEnabled=false.
            etFarmer.setText(savedInstanceState.getString(KEY_FARMER, ""));
            etCrop.setText(savedInstanceState.getString(KEY_CROP, ""));
            etQuantity.setText(savedInstanceState.getString(KEY_QTY, ""));
            rgType.check(savedInstanceState.getInt(KEY_TYPE, R.id.rbDelivery));
        }

        btnAdd.setOnClickListener(v -> onAddClicked());
        btnClearTrace.setOnClickListener(v -> {
            TRACE.setLength(0);
            tvTrace.setText("");
        });

        refreshCount();
        trace("onCreate (savedInstanceState " + (savedInstanceState == null ? "NULL" : "present")
                + ", records restored=" + records.size() + ")");
    }

    @Override
    protected void onStart() {
        super.onStart();
        trace("onStart");
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        trace("onRestoreInstanceState");
    }

    @Override
    protected void onResume() {
        super.onResume();
        trace("onResume");
    }

    @Override
    protected void onPause() {
        trace("onPause");
        super.onPause();
    }

    @Override
    protected void onStop() {
        trace("onStop");
        super.onStop();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(KEY_FARMER, etFarmer.getText().toString());
        outState.putString(KEY_CROP, etCrop.getText().toString());
        outState.putString(KEY_QTY, etQuantity.getText().toString());
        outState.putInt(KEY_TYPE, rgType.getCheckedRadioButtonId());
        outState.putSerializable(KEY_RECORDS, records);
        trace("onSaveInstanceState (draft + " + records.size() + " records)");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        trace("onRestart");
    }

    @Override
    protected void onDestroy() {
        trace("onDestroy (isChangingConfigurations=" + isChangingConfigurations()
                + ", isFinishing=" + isFinishing() + ")");
        super.onDestroy();
    }

    // ---------------------------------------------------------------- behaviour

    private void onAddClicked() {
        TransactionType type = rgType.getCheckedRadioButtonId() == R.id.rbHarvest
                ? TransactionType.WEEKLY_HARVEST
                : TransactionType.DELIVERY;

        etFarmer.setError(null);
        etCrop.setError(null);
        etQuantity.setError(null);

        RecordValidator.Result result = RecordValidator.validate(
                etFarmer.getText().toString(),
                etCrop.getText().toString(),
                etQuantity.getText().toString(),
                type);

        if (!result.valid) {
            EditText target = result.field == RecordValidator.Field.FARMER ? etFarmer
                    : result.field == RecordValidator.Field.CROP ? etCrop
                    : etQuantity;
            target.setError(result.message);
            target.requestFocus();
            Log.i(TAG, "REJECTED " + result.field + ": " + result.message);
            return;
        }

        records.add(result.record);
        adapter.notifyDataSetChanged();   // model changed -> ListView redraws
        refreshCount();
        Log.i(TAG, "ACCEPTED " + result.record + " (in memory only; total=" + records.size() + ")");

        etFarmer.setText("");
        etQuantity.setText("");
        etFarmer.requestFocus();          // crop kept: officers often enter several farmers per crop
        Toast.makeText(this, R.string.toast_added, Toast.LENGTH_SHORT).show();
    }

    private void refreshCount() {
        tvCount.setText(getString(R.string.record_count, records.size()));
        tvEmpty.setVisibility(records.isEmpty() ? TextView.VISIBLE : TextView.GONE);
    }

    @SuppressWarnings("unchecked")
    private static ArrayList<FarmerRecord> restoreRecords(Bundle state) {
        if (state != null) {
            Object saved = state.getSerializable(KEY_RECORDS);
            if (saved instanceof ArrayList) {
                return (ArrayList<FarmerRecord>) saved;
            }
        }
        return new ArrayList<>();
    }

    /** Writes to Logcat (tag MavunoLifecycle) and to the on-screen trace. */
    private void trace(String event) {
        String time = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
        String line = time + " pid=" + Process.myPid()
                + " act=" + Integer.toHexString(System.identityHashCode(this))
                + " " + event;
        Log.d(TAG, line);
        TRACE.append(line).append('\n');
        if (tvTrace != null) {
            tvTrace.setText(TRACE);
        }
    }
}
