package ke.ac.jkuat.mavunolink;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Adapter: the bridge between the model list (List<FarmerRecord>) and the
 * visible ListView. The ListView asks the adapter for a row View per position;
 * the adapter inflates item_record.xml (or recycles convertView) and binds the
 * record's fields into it. After the list changes, notifyDataSetChanged()
 * tells the ListView to ask again.
 */
public class RecordAdapter extends ArrayAdapter<FarmerRecord> {

    private final LayoutInflater inflater;

    public RecordAdapter(Context context, List<FarmerRecord> records) {
        super(context, 0, records);
        this.inflater = LayoutInflater.from(context);
    }

    /** ViewHolder avoids repeated findViewById calls on recycled rows. */
    private static final class Holder {
        final TextView title;
        final TextView detail;

        Holder(View row) {
            title = row.findViewById(R.id.tvItemTitle);
            detail = row.findViewById(R.id.tvItemDetail);
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        Holder h;
        if (row == null) {
            row = inflater.inflate(R.layout.item_record, parent, false);
            h = new Holder(row);
            row.setTag(h);
        } else {
            h = (Holder) row.getTag();
        }

        FarmerRecord r = getItem(position);
        if (r != null) {
            h.title.setText((position + 1) + ". " + r.getFarmerRef() + " — " + r.getCrop());
            h.detail.setText(r.formattedQuantity() + " · " + r.getType().getLabel());
        }
        return row;
    }
}
