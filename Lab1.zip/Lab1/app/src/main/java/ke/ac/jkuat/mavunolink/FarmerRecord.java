package ke.ac.jkuat.mavunolink;

import java.io.Serializable;
import java.util.Locale;

/**
 * Model: one accepted farmer record. Immutable, and only ever constructed
 * from values that already passed {@link RecordValidator}, so the list can
 * never contain an invalid row.
 *
 * Serializable so the list can be placed in the saved-instance-state Bundle.
 * That Bundle is NOT persistent storage: it is lost when the user swipes the
 * app away, force-stops it, reboots, or the app is reinstalled.
 */
public final class FarmerRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String farmerRef;
    private final String crop;
    private final double quantityKg;
    private final TransactionType type;

    public FarmerRecord(String farmerRef, String crop, double quantityKg, TransactionType type) {
        this.farmerRef = farmerRef;
        this.crop = crop;
        this.quantityKg = quantityKg;
        this.type = type;
    }

    public String getFarmerRef() { return farmerRef; }
    public String getCrop() { return crop; }
    public double getQuantityKg() { return quantityKg; }
    public TransactionType getType() { return type; }

    public String formattedQuantity() {
        return String.format(Locale.US, "%.2f kg", quantityKg);
    }

    @Override
    public String toString() {
        return farmerRef + " | " + crop + " | " + formattedQuantity() + " | " + type.getLabel();
    }
}
