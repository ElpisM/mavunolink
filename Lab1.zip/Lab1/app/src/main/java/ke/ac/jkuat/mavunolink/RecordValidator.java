package ke.ac.jkuat.mavunolink;

import java.util.regex.Pattern;

/**
 * Validation rules, written before the UI and kept free of Android classes so
 * they can be unit-tested on a plain JVM (see RecordValidatorTest).
 *
 * Rules (in the order they are checked):
 *  1. Farmer reference/name: required after trimming; max 40 chars.
 *  2. Crop: required after trimming; max 30 chars.
 *  3. Quantity:
 *     a. blank                                  -> reject
 *     b. not a plain decimal number             -> reject ("12kg", "1,200", "abc",
 *        "NaN", "Infinity", "1e3", "0x10", "12d" are all malformed here)
 *     c. parses but is not finite (e.g. 400 digits overflow to Infinity) -> reject
 *     d. negative                               -> reject
 *     e. zero: rejected for DELIVERY, accepted for WEEKLY_HARVEST
 *     f. above MAX_KG (sanity cap for a single smallholder entry) -> reject
 */
public final class RecordValidator {

    public static final int MAX_FARMER_LEN = 40;
    public static final int MAX_CROP_LEN = 30;
    public static final double MAX_KG = 100_000.0;

    /**
     * Optional sign, digits with optional fraction, or a leading-dot fraction.
     * Deliberately stricter than Double.parseDouble, which would otherwise accept
     * "NaN", "Infinity", "1e5", "0x1p3" and type suffixes such as "12d"/"12f".
     */
    private static final Pattern PLAIN_DECIMAL =
            Pattern.compile("^[+-]?(\\d+(\\.\\d*)?|\\.\\d+)$");

    public enum Field { FARMER, CROP, QUANTITY, NONE }

    /** Result object: either a valid record, or the first failing field + message. */
    public static final class Result {
        public final boolean valid;
        public final Field field;
        public final String message;
        public final FarmerRecord record;

        private Result(boolean valid, Field field, String message, FarmerRecord record) {
            this.valid = valid;
            this.field = field;
            this.message = message;
            this.record = record;
        }

        static Result ok(FarmerRecord r) { return new Result(true, Field.NONE, null, r); }
        static Result error(Field f, String msg) { return new Result(false, f, msg, null); }
    }

    private RecordValidator() { }

    public static Result validate(String farmerRaw, String cropRaw, String quantityRaw,
                                  TransactionType type) {
        String farmer = farmerRaw == null ? "" : farmerRaw.trim();
        String crop = cropRaw == null ? "" : cropRaw.trim();
        String qty = quantityRaw == null ? "" : quantityRaw.trim();

        if (farmer.isEmpty()) {
            return Result.error(Field.FARMER, "Farmer reference or name is required");
        }
        if (farmer.length() > MAX_FARMER_LEN) {
            return Result.error(Field.FARMER, "Farmer reference is too long (max " + MAX_FARMER_LEN + ")");
        }
        if (crop.isEmpty()) {
            return Result.error(Field.CROP, "Crop is required");
        }
        if (crop.length() > MAX_CROP_LEN) {
            return Result.error(Field.CROP, "Crop name is too long (max " + MAX_CROP_LEN + ")");
        }

        if (qty.isEmpty()) {
            return Result.error(Field.QUANTITY, "Quantity is required");
        }
        if (!PLAIN_DECIMAL.matcher(qty).matches()) {
            return Result.error(Field.QUANTITY,
                    "Quantity must be a plain number in kg, e.g. 120 or 85.5 (no units, commas or letters)");
        }

        double kg;
        try {
            kg = Double.parseDouble(qty);
        } catch (NumberFormatException e) {
            // Should be unreachable after the regex, kept as a safety net.
            return Result.error(Field.QUANTITY, "Quantity is not a valid number");
        }

        if (Double.isNaN(kg) || Double.isInfinite(kg)) {
            return Result.error(Field.QUANTITY, "Quantity is too large to be a real value");
        }
        if (kg < 0) {
            return Result.error(Field.QUANTITY, "Quantity cannot be negative");
        }
        if (kg == 0) {               // also catches "-0" and "0.000"
            if (!type.isZeroAllowed()) {
                return Result.error(Field.QUANTITY,
                        "A delivery must be more than 0 kg (use Weekly harvest to report a zero week)");
            }
            kg = 0.0;                // normalise -0.0 to 0.0
        }
        if (kg > MAX_KG) {
            return Result.error(Field.QUANTITY, "Quantity exceeds " + (long) MAX_KG + " kg; check the entry");
        }

        return Result.ok(new FarmerRecord(farmer, crop, kg, type));
    }
}
