# Lab 1 — MavunoLink Farmer Records (Lab_01_hm1) (ICS 2300)

Java/XML Android app that captures a fictional farmer reference, crop and quantity (kg),
validates the entry, shows accepted records in a ListView with a record count, and logs
every Activity lifecycle callback so the launch / Home / return / rotation / restart
experiments can be traced.

## Build and run

1. Android Studio (Koala or newer), JDK 17, Android SDK 34.
2. **File → Open** → select the `Lab1` folder. Let Gradle sync
   (Studio will generate the Gradle wrapper if prompted).
3. Run on an emulator or phone (min API 24).
4. Validation unit tests (no emulator needed): `./gradlew test`
   or right-click `RecordValidatorTest` → Run. Expected: 11 tests, all pass.
5. Lifecycle trace: Logcat filter `tag:MavunoLifecycle`. The same lines also appear in
   the grey trace box at the bottom of the screen.

## Code map (input → model → adapter → list)

| File | Role |
|---|---|
| `activity_main.xml` | Input fields, transaction type, Add button, count, ListView, trace box |
| `RecordValidator.java` | All validation rules; no Android classes, so it is unit-testable |
| `TransactionType.java` | DELIVERY (zero rejected) vs WEEKLY_HARVEST (zero accepted) |
| `FarmerRecord.java` | Immutable model; only built from validated values |
| `RecordAdapter.java` | Binds each `FarmerRecord` to `item_record.xml` rows |
| `MainActivity.java` | Wires it together; lifecycle logging; saves draft + list in `onSaveInstanceState` |
| `RecordValidatorTest.java` | JUnit tests for every validation-table row |

Flow: Add → `RecordValidator.validate(...)` → on success `records.add(record)` →
`adapter.notifyDataSetChanged()` → ListView redraws → `tvCount` updated.
On failure, `setError` on the first bad field; nothing is added.

## Validation table (matches the unit tests)

| ID | Farmer | Crop | Qty | Type | Expected |
|---|---|---|---|---|---|
| V1 | FRM-001 | Maize | 120.5 | Delivery | Accepted, list +1, count +1 |
| V2 | *(blank)* | Maize | 10 | Delivery | Rejected: farmer required |
| V3 | FRM-001 | *(blank)* | 10 | Delivery | Rejected: crop required |
| V4 | FRM-001 | Maize | *(blank)* | Delivery | Rejected: quantity required |
| V5 | FRM-001 | Maize | -5 | Delivery | Rejected: negative |
| V6 | FRM-001 | Maize | 12kg / 1,200 / abc / 1e3 | Delivery | Rejected: malformed |
| V7 | FRM-001 | Maize | NaN / Infinity / 1 followed by 400 zeros | Delivery | Rejected: non-finite |
| V8 | FRM-001 | Maize | 0 | Delivery | Rejected: delivery must be > 0 |
| V9 | FRM-002 | Beans | 0 | Weekly harvest | **Accepted** (zero week is a real event) |
| V10 | FRM-001 | Maize | 100000.01 | Delivery | Rejected: above sanity cap |

Note: the quantity field uses `inputType="text"` on purpose so malformed input can be
typed during testing and is rejected by the validator rather than hidden by the keyboard.

## Lifecycle experiments (record the actual output; predictions are to compare against)

| ID | Action | Predicted sequence |
|---|---|---|
| L1 | Cold launch | onCreate (state NULL) → onStart → onResume |
| L2 | Press Home | onPause → onStop → onSaveInstanceState* |
| L3 | Return from Recents | onRestart → onStart → onResume (same pid, same act id) |
| L4 | Rotate with half-filled form | onPause → onStop → onSaveInstanceState* → onDestroy (isChangingConfigurations=true) → onCreate (state present) → onStart → onRestoreInstanceState → onResume (same pid, **new** act id) |

\* On API 28+ `onSaveInstanceState` runs after `onStop`; on older versions before it.
Note the on-screen trace survives L4 because it is a static field in the same process.

### L5 — Restart experiment (process death)

**A. System-initiated kill (saved state should survive):**
1. Add 2 records, half-fill the form.
2. Press **Home** (do not swipe away).
3. `adb shell am kill ke.ac.jkuat.mavunolink`
   (if it does not die, enable Developer options → "Don't keep activities", or use
   `adb shell ps | grep mavuno` to confirm the pid is gone).
4. Reopen from Recents.
5. Expect: **new pid**, onCreate (state present), records and draft restored, but the
   on-screen trace was wiped (it was only process memory).

**B. User-initiated end (nothing survives):**
1. Add records, then swipe the app out of Recents (or Settings → Force stop).
2. Relaunch. Expect: onCreate (state NULL), Records: 0.
   This shows the saved-state Bundle is not persistent storage; a database (e.g. Room)
   would be needed for real MavunoLink records.

## Synthetic data only
Use invented references such as FRM-001, FRM-002. Do not enter real farmer details.
