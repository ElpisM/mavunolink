// UNEXECUTED: written without a Mac/Xcode. Not compiled or run. See README.md.

import SwiftUI

@main
struct MavunoLinkApp: App {
    /// The app owns the single RecordStore for its whole life (@StateObject: created once,
    /// not recreated when views redraw) and hands it down through the environment.
    @StateObject private var store = RecordStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .task { store.load() }      // committed records come back from disk on every launch
        }
    }
}
