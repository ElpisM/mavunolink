// UNEXECUTED: written without a Mac/Xcode. Not compiled or run. See README.md.
//
// Lab 9 data model for a fictional MavunoLink mushroom delivery (synthetic data only).
// Mirrors the Android app (Labs 1-8): same field meanings, units and rules.

import Foundation

/// What happened. The zero rule belongs to the event, not to the field (Android Lab 1).
enum TransactionKind: String, Codable, CaseIterable, Identifiable {
    case delivery        // produce handed over at a collection point: must be > 0 kg
    case weeklyHarvest   // farmer's weekly report: 0 kg is a real, recordable week

    var id: String { rawValue }
    var label: String { self == .delivery ? "Delivery" : "Weekly harvest" }
    var zeroAllowed: Bool { self == .weeklyHarvest }
}

enum MushroomVariety: String, Codable, CaseIterable, Identifiable {
    case oyster, button, shiitake
    var id: String { rawValue }
    var label: String { rawValue.capitalized }
}

/// Stable id ("CP-03") is what is validated and stored; the name is display only (Android Lab 4).
struct CollectionPoint: Identifiable, Hashable, Codable {
    let id: String
    let name: String
    let area: String

    static let all: [CollectionPoint] = [
        .init(id: "CP-01", name: "Gatundu Market", area: "Gatundu North"),
        .init(id: "CP-02", name: "Juja Farm Gate", area: "Juja"),
        .init(id: "CP-03", name: "Thika Road Depot", area: "Thika"),
        .init(id: "CP-04", name: "Ruiru Cooperative Store", area: "Ruiru"),
        .init(id: "CP-05", name: "Kiambu Town Centre", area: "Kiambu"),
    ]
}

/// Server side of a record's life. This lab stops at .pending: no server is called.
enum SyncState: String, Codable {
    case pending        // committed on this iPhone, not yet acknowledged by any server
    case acknowledged   // (future) a valid server acknowledgement for this id and version
    case failed         // (future) transient failure, retry with the same id
    case conflict       // (future) server refused; needs a person
}

/// DRAFT: what the user is typing. Lives only in memory, owned by ContentView.
/// `id` is created once when the draft starts and becomes the record id on commit,
/// so going form -> review -> edit -> review any number of times keeps one identity.
struct DeliveryDraft: Equatable {
    let id: UUID
    var farmerRef = ""
    var date = Date()
    var pointID: String? = nil          // nil = prompt "Choose…", never a valid value
    var variety: MushroomVariety? = nil
    var quantityText = ""               // kept as typed so malformed input can be rejected, not hidden
    var kind: TransactionKind = .delivery
    var notes = ""
    var paperReceipt = false

    init(id: UUID = UUID()) { self.id = id }

    /// True when cancelling would lose nothing the user typed.
    var isEmpty: Bool {
        farmerRef.trimmingCharacters(in: .whitespaces).isEmpty
            && pointID == nil && variety == nil
            && quantityText.trimmingCharacters(in: .whitespaces).isEmpty
            && notes.trimmingCharacters(in: .whitespaces).isEmpty
    }
}

/// COMMITTED LOCAL RECORD: validated, written to this iPhone's storage, survives relaunch.
/// Says nothing about any server (syncState stays .pending in this lab).
struct DeliveryRecord: Identifiable, Codable, Equatable {
    let id: UUID                // same UUID as the draft it came from
    var farmerRef: String
    var date: Date
    var pointID: String
    var pointName: String       // label snapshot for display
    var variety: MushroomVariety
    var quantityKg: Double
    var kind: TransactionKind
    var notes: String?
    var paperReceipt: Bool
    var version: Int            // 1 at commit; +1 per correction (future)
    var syncState: SyncState
    var savedAt: Date
}
