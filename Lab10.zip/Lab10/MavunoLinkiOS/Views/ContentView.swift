// UNEXECUTED: written without a Mac/Xcode. Not compiled or run. See README.md.
//
// Navigation and draft ownership.
//
//   ContentView (@State)       owns `path` (which screens are stacked) and `draft`
//   DeliveryFormView           gets a @Binding to the draft: may edit it
//   ReviewView                 gets the draft by value: may only read it, then asks
//                              the store to commit; reports back with closures
//   RecordStore (environment)  owns committed records; only commit()/load() change them
//
// The draft lives HERE, above the NavigationStack destinations, so popping from Review
// back to the form (Edit) or pushing again does not destroy it.

import SwiftUI
import os

enum Route: Hashable {
    case form
    case review
}

struct ContentView: View {
    @EnvironmentObject private var store: RecordStore
    @State private var path: [Route] = []
    @State private var draft: DeliveryDraft?           // nil = no delivery in progress
    @State private var banner: String?
    private let log = Logger(subsystem: "ke.ac.jkuat.mavunolink", category: "flow")

    var body: some View {
        NavigationStack(path: $path) {
            RecordListView(records: store.records, banner: banner, loadError: store.loadError)
                .navigationTitle("Mushroom deliveries")
                .toolbar {
                    ToolbarItem(placement: .primaryAction) {
                        Button {
                            startOrResume()
                        } label: {
                            Label(draft == nil ? "New delivery" : "Resume delivery", systemImage: "plus")
                        }
                    }
                }
                .navigationDestination(for: Route.self) { route in
                    switch route {
                    case .form:
                        DeliveryFormView(draft: draftBinding,
                                         onReview: { path.append(.review) },
                                         onCancel: discardDraft)
                    case .review:
                        ReviewView(draft: draft ?? DeliveryDraft(),
                                   onEdit: { _ = path.popLast() },
                                   onCancel: discardDraft,
                                   onSaved: finished)
                    }
                }
        }
    }

    /// Form edits go straight into the owned draft.
    private var draftBinding: Binding<DeliveryDraft> {
        Binding(get: { draft ?? DeliveryDraft() }, set: { draft = $0 })
    }

    /// Repeated taps never create a second draft or a second form screen:
    /// an existing draft is reused (same id) and the path is SET, not appended.
    private func startOrResume() {
        if draft == nil {
            draft = DeliveryDraft()
            log.info("DRAFT created id=\(String(draft!.id.uuidString.prefix(8)))")
        } else {
            log.info("DRAFT resumed id=\(String(draft!.id.uuidString.prefix(8)))")
        }
        banner = nil
        path = [.form]
    }

    private func discardDraft() {
        log.info("DRAFT discarded by user (nothing saved)")
        draft = nil
        path = []
        banner = "Draft discarded. Nothing was saved."
    }

    private func finished(_ outcome: RecordStore.CommitOutcome) {
        draft = nil
        path = []
        banner = outcome == .saved
            ? "Saved on this iPhone. Not sent to any server."
            : "Already saved earlier. No duplicate was created."
    }
}

/// Committed records, newest first. Reads the store's list; cannot change it.
struct RecordListView: View {
    let records: [DeliveryRecord]
    let banner: String?
    let loadError: String?

    var body: some View {
        List {
            if let loadError {
                Text(loadError).foregroundStyle(.red)
            }
            if let banner {
                Text(banner)
                    .font(.callout)
            }
            Section("Saved on this iPhone: \(records.count)") {
                if records.isEmpty {
                    Text("No deliveries saved yet. Tap New delivery to start.")
                        .foregroundStyle(.secondary)
                }
                ForEach(Array(records.reversed())) { r in
                    VStack(alignment: .leading, spacing: 4) {
                        Text("\(r.farmerRef) — \(r.variety.label)").font(.headline)
                        Text("\(r.date.formatted(date: .abbreviated, time: .omitted)) · \(r.quantityKg.formatted()) kg · \(r.kind.label)")
                            .font(.subheadline)
                        Text("\(r.pointName) (\(r.pointID)) · \(r.syncState.rawValue)")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .accessibilityElement(children: .combine)
                }
            }
        }
    }
}
