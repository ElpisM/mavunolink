// UNEXECUTED: written without a Mac/Xcode. Not compiled or run. See README.md.
//
// Review screen. Reads the draft (by value), shows exactly what will be saved, and
// asks the store to commit. Redrawing this view re-runs validate() but never saves:
// only the Save button calls store.commit().

import SwiftUI

struct ReviewView: View {
    @EnvironmentObject private var store: RecordStore
    let draft: DeliveryDraft
    let onEdit: () -> Void
    let onCancel: () -> Void
    let onSaved: (RecordStore.CommitOutcome) -> Void

    @State private var saveError: String?
    @State private var confirmCancel = false
    @State private var isSaving = false

    var body: some View {
        let result = DeliveryValidator.validate(draft, points: CollectionPoint.all)
        List {
            switch result {
            case .success(let r):
                Section("Check before saving") {
                    LabeledContent("Farmer", value: r.farmerRef)
                    LabeledContent("Date", value: r.date.formatted(date: .long, time: .omitted))
                    LabeledContent("Collection point", value: "\(r.pointName) (\(r.pointID))")
                    LabeledContent("Variety", value: r.variety.label)
                    LabeledContent("Quantity", value: "\(r.quantityKg.formatted()) kg")
                    LabeledContent("Type", value: r.kind.label)
                    LabeledContent("Notes", value: r.notes ?? "(none)")
                    LabeledContent("Paper receipt", value: r.paperReceipt ? "Yes" : "No")
                }
                Section {
                    Text("Nothing is saved until you tap Save. Saving stores it on this iPhone only.")
                        .font(.footnote)
                }
            case .failure(let f):
                Section("Fix these first") {
                    ForEach(f.errors, id: \.self) { e in Text(e.message).foregroundStyle(.red) }
                }
            }
        }
        .navigationTitle("Review")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") { confirmCancel = true }
            }
        }
        .safeAreaInset(edge: .bottom) {
            // At accessibility text sizes the two buttons stack instead of being squeezed.
            ViewThatFits {
                HStack(spacing: 12) { editButton; saveButton(result) }
                VStack(spacing: 12) { saveButton(result); editButton }
            }
            .padding()
            .background(.bar)
        }
        .confirmationDialog("Discard this draft?", isPresented: $confirmCancel, titleVisibility: .visible) {
            Button("Discard draft", role: .destructive, action: onCancel)
            Button("Keep reviewing", role: .cancel) { }
        }
        .alert("Not saved", isPresented: Binding(get: { saveError != nil },
                                                 set: { if !$0 { saveError = nil } })) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(saveError ?? "")
        }
    }

    private var editButton: some View {
        Button("Edit", action: onEdit)
            .buttonStyle(.bordered)
            .frame(maxWidth: .infinity)
    }

    private func saveButton(_ result: Result<DeliveryRecord, ValidationFailure>) -> some View {
        Button(isSaving ? "Saving…" : "Save") { save(result) }
            .buttonStyle(.borderedProminent)
            .frame(maxWidth: .infinity)
            .disabled(isSaving || !result.isSuccess)
    }

    /// The only place a record is committed. On failure: alert, stay here, draft untouched.
    private func save(_ result: Result<DeliveryRecord, ValidationFailure>) {
        guard case .success(let record) = result, !isSaving else { return }
        isSaving = true
        defer { isSaving = false }
        do {
            let outcome = try store.commit(record)
            onSaved(outcome)
        } catch {
            saveError = "The delivery was not saved, so nothing changed. Your entry is still here; try again.\n\nDetail: \(error.localizedDescription)"
        }
    }
}

private extension Result {
    var isSuccess: Bool {
        if case .success = self { return true }
        return false
    }
}
