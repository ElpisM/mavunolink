// UNEXECUTED: written without a Mac/Xcode. Not compiled or run. See README.md.
//
// The form. It may EDIT the draft (via @Binding) but owns only its own UI state:
// which field has focus and which errors to show. It never saves anything.

import SwiftUI

struct DeliveryFormView: View {
    @Binding var draft: DeliveryDraft
    let onReview: () -> Void
    let onCancel: () -> Void

    @FocusState private var focus: Field?
    @State private var errors: [FieldError] = []
    @State private var confirmCancel = false

    private let points = CollectionPoint.all

    var body: some View {
        Form {
            Section {
                labelled("Farmer reference", field: .farmer) {
                    TextField("Farmer reference", text: $draft.farmerRef, prompt: Text("FRM-001"))
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                        .focused($focus, equals: .farmer)
                }
                labelled("Date", field: .date) {
                    DatePicker("Delivery date", selection: $draft.date, in: ...Date(), displayedComponents: .date)
                        .labelsHidden()
                }
                labelled("Collection point", field: .point) {
                    Picker("Collection point", selection: $draft.pointID) {
                        Text("Choose a collection point…").tag(String?.none)
                        ForEach(points) { p in
                            Text("\(p.name) (\(p.id))").tag(Optional(p.id))
                        }
                    }
                    .labelsHidden()
                }
                labelled("Mushroom variety", field: .variety) {
                    Picker("Mushroom variety", selection: $draft.variety) {
                        Text("Choose a variety…").tag(MushroomVariety?.none)
                        ForEach(MushroomVariety.allCases) { v in
                            Text(v.label).tag(Optional(v))
                        }
                    }
                    .labelsHidden()
                }
            }
            Section {
                labelled("Quantity in kg", field: .quantity) {
                    TextField("Quantity in kilograms", text: $draft.quantityText, prompt: Text("12.5"))
                        .keyboardType(.decimalPad)
                        .focused($focus, equals: .quantity)
                }
                Picker("Transaction type", selection: $draft.kind) {
                    ForEach(TransactionKind.allCases) { k in Text(k.label).tag(k) }
                }
                .pickerStyle(.segmented)
                .accessibilityHint("Delivery must be more than 0 kilograms; weekly harvest may be 0")
            }
            Section {
                labelled("Notes (optional)", field: .notes) {
                    TextField("Notes", text: $draft.notes, prompt: Text("Collected at Gatundu point"), axis: .vertical)
                        .lineLimit(1...4)
                        .focused($focus, equals: .notes)
                }
                Toggle("Print a paper receipt for the farmer", isOn: $draft.paperReceipt)
            }
            Section {
                Button("Review delivery") { review() }
                    .frame(maxWidth: .infinity)
            }
        }
        .navigationTitle("New delivery")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") {
                    if draft.isEmpty { onCancel() } else { confirmCancel = true }
                }
            }
        }
        .confirmationDialog("Discard this draft?", isPresented: $confirmCancel, titleVisibility: .visible) {
            Button("Discard draft", role: .destructive, action: onCancel)
            Button("Keep editing", role: .cancel) { }
        } message: {
            Text("What you typed will be lost. Nothing has been saved.")
        }
    }

    /// Validate first; only a valid draft moves on to Review. Errors stay on screen.
    private func review() {
        switch DeliveryValidator.validate(draft, points: points) {
        case .success:
            errors = []
            onReview()
        case .failure(let f):
            errors = f.errors
            focus = f.first?.field          // focus applies only to text fields; pickers just show the error
        }
    }

    /// Visible label above every control (the Android Lab 2 accessibility fix), plus the
    /// field's error underneath. Nothing has a fixed height, so it grows with Dynamic Type.
    @ViewBuilder
    private func labelled<Content: View>(_ title: String, field: Field,
                                         @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.subheadline.weight(.semibold))
            content()
            if let e = errors.first(where: { $0.field == field }) {
                Text(e.message)
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .accessibilityLabel("Error: \(e.message)")
            }
        }
    }
}
