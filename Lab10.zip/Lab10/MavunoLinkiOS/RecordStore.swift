// UNEXECUTED: written without a Mac/Xcode. Not compiled or run. See README.md.
//
// Lab 9 storage path. RecordStore OWNS the committed records: views can read them
// (`records` is published) but only `load()` and `commit(_:)` can change them
// (`private(set)`).
//
// Storage: one JSON file in Application Support, written with `.atomic`, so a crash
// mid-write leaves the old file intact. Chosen over UserDefaults (settings, not
// records) and over SwiftData/Core Data (SwiftData needs iOS 17, and a few dozen
// records do not need a database here). Android used SQLite (Lab 8); see report.

import Foundation
import os

@MainActor
final class RecordStore: ObservableObject {

    enum CommitOutcome: Equatable {
        case saved          // newly written to disk
        case alreadySaved   // same id was committed before: nothing written, no duplicate
    }

    enum StoreError: LocalizedError {
        case simulatedFailure
        var errorDescription: String? { "Simulated write failure (test option); nothing was saved" }
    }

    @Published private(set) var records: [DeliveryRecord] = []
    @Published private(set) var loadError: String?

    /// Test option: make the next write throw before anything reaches the disk.
    var simulateWriteFailure = false

    private let fileURL: URL
    private let log = Logger(subsystem: "ke.ac.jkuat.mavunolink", category: "store")

    init(fileURL: URL = RecordStore.defaultURL) {
        self.fileURL = fileURL
    }

    static var defaultURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("MavunoLink", isDirectory: true)
            .appendingPathComponent("records.json")
    }

    /// Reads the committed records from disk (called once at launch).
    func load() {
        do {
            let data = try Data(contentsOf: fileURL)
            records = try Self.decoder.decode([DeliveryRecord].self, from: data)
            log.info("LOAD \(self.records.count) records from disk")
        } catch let e as CocoaError where e.code == .fileReadNoSuchFile {
            records = []                                   // first launch: nothing saved yet
            log.info("LOAD no file yet (first launch)")
        } catch {
            loadError = "Saved records could not be read: \(error.localizedDescription)"
            log.error("LOAD failed: \(error.localizedDescription)")
        }
    }

    /// Commit boundary: the new list is written to disk FIRST; `records` (and so the UI)
    /// changes only after the write succeeded. If the write throws, nothing changes and
    /// the caller keeps the draft.
    func commit(_ record: DeliveryRecord) throws -> CommitOutcome {
        if records.contains(where: { $0.id == record.id }) {
            log.info("COMMIT id=\(String(record.id.uuidString.prefix(8))) already saved -> no duplicate")
            return .alreadySaved
        }
        var next = records
        next.append(record)
        try write(next)                 // throws -> `records` untouched
        records = next
        log.info("COMMIT id=\(String(record.id.uuidString.prefix(8))) saved; total=\(next.count)")
        return .saved
    }

    private func write(_ list: [DeliveryRecord]) throws {
        if simulateWriteFailure {
            log.error("COMMIT simulated failure before write")
            throw StoreError.simulatedFailure
        }
        try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(),
                                                withIntermediateDirectories: true)
        let data = try Self.encoder.encode(list)
        try data.write(to: fileURL, options: [.atomic, .completeFileProtection])
    }

    private static let encoder: JSONEncoder = {
        let e = JSONEncoder()
        e.dateEncodingStrategy = .iso8601
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        return e
    }()

    private static let decoder: JSONDecoder = {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        return d
    }()
}
