// UNEXECUTED: written without a Mac/Xcode. Not compiled or run. See README.md.
//
// Lab 9 validation. A pure function of the draft (no UI, no storage), so it can be
// unit-tested with XCTest. Same rule table as the Android RecordValidator (Labs 1, 2, 4),
// which WAS executed there with JUnit.

import Foundation

enum Field: String, CaseIterable, Hashable {
    case farmer, date, point, variety, quantity, notes   // on-screen order: first error gets focus
}

struct FieldError: Equatable, Hashable {
    let field: Field
    let message: String
}

struct ValidationFailure: Error, Equatable {
    let errors: [FieldError]
    var first: FieldError? { errors.first }
}

enum DeliveryValidator {
    static let maxFarmerLength = 40
    static let maxNotesLength = 120
    static let maxKg = 100_000.0
    static let maxAgeDays = 365

    /// Plain decimal only. Double("1e3"), Double("nan") and Double("inf") would succeed,
    /// so the text is checked first (the same defect the Android version guards against).
    private static let plainDecimal = #"^[+-]?(\d+(\.\d*)?|\.\d+)$"#

    /// Returns a record ready to commit, or every error in on-screen order.
    static func validate(_ d: DeliveryDraft,
                         points: [CollectionPoint],
                         today: Date = Date(),
                         calendar: Calendar = .current) -> Result<DeliveryRecord, ValidationFailure> {
        var errors: [FieldError] = []
        func fail(_ f: Field, _ m: String) { errors.append(FieldError(field: f, message: m)) }

        // Farmer
        let farmer = d.farmerRef.trimmingCharacters(in: .whitespacesAndNewlines)
        if farmer.isEmpty { fail(.farmer, "Farmer reference is required") }
        else if farmer.count > maxFarmerLength { fail(.farmer, "Farmer reference is too long (max \(maxFarmerLength))") }

        // Date: the DatePicker cannot produce a malformed date, so only the range is checked.
        let day = calendar.startOfDay(for: d.date)
        let todayStart = calendar.startOfDay(for: today)
        if day > todayStart { fail(.date, "Date cannot be in the future") }
        else if let oldest = calendar.date(byAdding: .day, value: -maxAgeDays, to: todayStart), day < oldest {
            fail(.date, "Date is more than \(maxAgeDays) days ago; late entries need a supervisor")
        }

        // Collection point: prompt (nil) is not a choice; id must still exist.
        var point: CollectionPoint?
        if points.isEmpty { fail(.point, "No collection points are available, so the record cannot be saved") }
        else if let pid = d.pointID {
            point = points.first { $0.id == pid }
            if point == nil { fail(.point, "That collection point is no longer available; choose another") }
        } else { fail(.point, "Choose a collection point") }

        // Variety
        if d.variety == nil { fail(.variety, "Choose a mushroom variety") }

        // Quantity
        var kg = 0.0
        let q = d.quantityText.trimmingCharacters(in: .whitespacesAndNewlines)
        if q.isEmpty { fail(.quantity, "Quantity is required") }
        else if q.range(of: plainDecimal, options: .regularExpression) == nil {
            fail(.quantity, "Quantity must be a plain number in kg, e.g. 12 or 8.5 (no units, commas or letters)")
        } else if let v = Double(q), v.isFinite {
            if v < 0 { fail(.quantity, "Quantity cannot be negative") }
            else if v == 0 && !d.kind.zeroAllowed { fail(.quantity, "A delivery must be more than 0 kg (use Weekly harvest for a zero week)") }
            else if v > maxKg { fail(.quantity, "Quantity exceeds \(Int(maxKg)) kg; check the entry") }
            else { kg = v == 0 ? 0 : v }      // normalise -0
        } else {
            fail(.quantity, "Quantity is too large to be a real value")
        }

        // Notes (optional)
        let notes = d.notes.trimmingCharacters(in: .whitespacesAndNewlines)
        if notes.count > maxNotesLength { fail(.notes, "Notes must be at most \(maxNotesLength) characters") }

        // Errors were appended in on-screen order, so errors[0] is the field to focus.
        guard errors.isEmpty, let p = point, let variety = d.variety else {
            return .failure(ValidationFailure(errors: errors))
        }
        return .success(DeliveryRecord(
            id: d.id, farmerRef: farmer, date: day, pointID: p.id, pointName: p.name,
            variety: variety, quantityKg: kg, kind: d.kind,
            notes: notes.isEmpty ? nil : notes, paperReceipt: d.paperReceipt,
            version: 1, syncState: .pending, savedAt: today))
    }
}
