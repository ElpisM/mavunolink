// MavunoLink PWA: capture -> review -> save flow (same feature as Android Labs 2-8 and iOS Lab 9).
import { validate, POINTS, KINDS } from './validate.js';
import { allRecords, commit, testOptions } from './store.js';

const $ = id => document.getElementById(id);
const FIELDS = ['farmer', 'date', 'point', 'quantity', 'notes'];
const FIELD_INPUT = { farmer: 'farmer', date: 'date', point: 'point', quantity: 'quantity', notes: 'notes' };

let draft = newDraft();
let saving = false;

// ------------------------------------------------------------------ setup

function init() {
  const v = self.MAVUNOLINK_VERSION || { version: 'dev', commit: 'dev' };
  $('version').textContent = `${v.version} (${v.commit})`;

  for (const p of POINTS) {
    const o = document.createElement('option');
    o.value = p.id;
    o.textContent = `${p.name} (${p.id})`;
    $('point').append(o);
  }
  $('date').value = today();
  $('date').max = today();

  $('form').addEventListener('submit', e => { e.preventDefault(); onReview(); });
  $('edit').addEventListener('click', onEdit);
  $('save').addEventListener('click', onSave);
  $('cancel').addEventListener('click', onCancel);
  $('sim-fail').addEventListener('change', e => { testOptions.simulateWriteFailure = e.target.checked; });

  updateNet();
  addEventListener('online', updateNet);
  addEventListener('offline', updateNet);

  refreshList();
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js');
}

function newDraft() {
  return { id: crypto.randomUUID() };   // identity created once; kept through Review/Edit
}

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function readForm() {
  draft.farmer = $('farmer').value;
  draft.date = $('date').value;
  draft.pointId = $('point').value;
  draft.quantity = $('quantity').value;
  draft.kind = document.querySelector('input[name=kind]:checked').value;
  draft.notes = $('notes').value;
}

// ------------------------------------------------------------------ capture and review

function onReview() {
  readForm();
  clearErrors();
  hideMessages();
  const result = validate(draft);
  if (!result.ok) {
    for (const e of result.errors) {
      const input = $(FIELD_INPUT[e.field]);
      input.setAttribute('aria-invalid', 'true');
      $('err-' + e.field).textContent = e.message;
    }
    const n = result.errors.length;
    $('summary').textContent = `${n} ${n === 1 ? 'field needs' : 'fields need'} attention. The first one has focus.`;
    $('summary').hidden = false;
    $(FIELD_INPUT[result.errors[0].field]).focus();     // accessibility A2
    return;
  }
  renderReview(result.record);
  $('form-view').hidden = true;
  $('review-view').hidden = false;
  $('review-title').focus();
}

function renderReview(r) {
  const rows = [
    ['Farmer', r.farmer], ['Date', r.date], ['Collection point', `${r.pointName} (${r.pointId})`],
    ['Quantity', `${r.quantityKg} kg`], ['Type', KINDS[r.kind]], ['Notes', r.notes ?? '(none)'],
  ];
  const dl = $('review-list');
  dl.replaceChildren();
  for (const [k, v] of rows) {
    const dt = document.createElement('dt'); dt.textContent = k;
    const dd = document.createElement('dd'); dd.textContent = v;   // textContent, never innerHTML (R2)
    dl.append(dt, dd);
  }
}

function onEdit() {
  $('review-view').hidden = true;
  $('form-view').hidden = false;
  $('farmer').focus();                     // the draft is still in the form fields
}

async function onSave() {
  if (saving) return;
  const result = validate(draft);
  if (!result.ok) { onEdit(); return; }
  saving = true;
  $('save').disabled = true;
  hideMessages();
  try {
    const outcome = await commit(result.record);
    console.info('[mavunolink] saved id', draft.id.slice(0, 8), outcome);   // id only, no personal data (R1)
    const keepDate = draft.date, keepPoint = draft.pointId;
    draft = newDraft();
    $('form').reset();
    $('date').value = keepDate;
    $('point').value = keepPoint;
    $('review-view').hidden = true;
    $('form-view').hidden = false;
    showStatus(outcome === 'saved'
      ? 'Saved on this device. Not sent to any server.'
      : 'Already saved earlier. No duplicate was created.');
    await refreshList();
    $('farmer').focus();
  } catch (err) {
    console.warn('[mavunolink] save failed for id', draft.id.slice(0, 8));
    $('alert').textContent = 'Not saved. Nothing has changed and your entry is still here; try again.';
    $('alert').hidden = false;
    // v1.0.1 fix: the alert sits above the Review section, so after tapping Save near the bottom
    // it was off screen for sighted users. Move focus to it so it scrolls into view.
    $('alert').focus();
  } finally {
    saving = false;
    $('save').disabled = false;
  }
}

function onCancel() {
  readForm();
  const typed = ['farmer', 'quantity', 'notes'].some(k => (draft[k] ?? '').trim()) || draft.pointId;
  if (typed && !confirm('Discard this entry? Nothing has been saved.')) return;
  draft = newDraft();
  $('form').reset();
  $('date').value = today();
  clearErrors();
  hideMessages();
  showStatus('Entry discarded. Nothing was saved.');
}

// ------------------------------------------------------------------ list and messages

async function refreshList() {
  const records = await allRecords();
  $('count').textContent = String(records.length);
  const ul = $('records');
  ul.replaceChildren();
  for (const r of records.slice().reverse()) {
    const li = document.createElement('li');
    const t = document.createElement('div'); t.className = 'title';
    t.textContent = `${r.farmer} — ${r.quantityKg} kg ${KINDS[r.kind].toLowerCase()}`;
    const m = document.createElement('div'); m.className = 'meta';
    m.textContent = `${r.date} · ${r.pointName} (${r.pointId}) · ${r.syncState.toLowerCase()}`
      + (r.notes ? ` · ${r.notes}` : '');                       // textContent: notes are shown, never executed
    li.append(t, m);
    ul.append(li);
  }
}

function clearErrors() {
  for (const f of FIELDS) {
    $(FIELD_INPUT[f]).removeAttribute('aria-invalid');
    $('err-' + f).textContent = '';
  }
  $('summary').hidden = true;
}

function hideMessages() {
  $('status').hidden = true;
  $('alert').hidden = true;
}

function showStatus(text) {
  $('status').textContent = text;
  $('status').hidden = false;
}

function updateNet() {
  const on = navigator.onLine;
  $('net').textContent = on ? 'Online' : 'Offline: saving still works';
  $('net').classList.toggle('offline', !on);
}

init();
