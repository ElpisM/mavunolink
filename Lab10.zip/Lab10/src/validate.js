// MavunoLink PWA: validation rules (shared, no DOM, unit-tested with node:test).
// Same rule table as the Android RecordValidator (Labs 1, 2, 4) and the iOS port (Lab 9).

export const MAX_FARMER = 40;
export const MAX_NOTES = 120;
export const MAX_KG = 100000;
export const MAX_AGE_DAYS = 365;

export const POINTS = [
  { id: 'CP-01', name: 'Gatundu Market' },
  { id: 'CP-02', name: 'Juja Farm Gate' },
  { id: 'CP-03', name: 'Thika Road Depot' },
  { id: 'CP-04', name: 'Ruiru Cooperative Store' },
  { id: 'CP-05', name: 'Kiambu Town Centre' },
];

export const KINDS = { DELIVERY: 'Delivery', WEEKLY_HARVEST: 'Weekly harvest' };

// Plain decimal only. Number('1e3') and Number('Infinity') would succeed, so test the text first.
const PLAIN_DECIMAL = /^[+-]?(\d+(\.\d*)?|\.\d+)$/;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
// Farmer reference is a code, not a name: letters, digits and dashes only (privacy control R1).
const FARMER_CODE = /^[A-Za-z]{2,5}-?\d{1,6}$/;

/** Returns { ok: true, record } or { ok: false, errors: [{field, message}] } in on-screen order. */
export function validate(draft, { points = POINTS, today = new Date() } = {}) {
  const errors = [];
  const fail = (field, message) => errors.push({ field, message });

  const farmer = (draft.farmer ?? '').trim().toUpperCase();
  if (!farmer) fail('farmer', 'Farmer reference is required');
  else if (farmer.length > MAX_FARMER) fail('farmer', `Farmer reference is too long (max ${MAX_FARMER})`);
  else if (!FARMER_CODE.test(farmer)) fail('farmer', 'Use the farmer code (e.g. FRM-001), not a name or phone number');

  const date = (draft.date ?? '').trim();
  if (!date) fail('date', 'Date is required');
  else if (!ISO_DATE.test(date) || !isRealDate(date)) fail('date', 'That date does not exist on the calendar');
  else {
    const d = startOfDay(new Date(date + 'T00:00:00'));
    const t = startOfDay(today);
    const oldest = new Date(t); oldest.setDate(oldest.getDate() - MAX_AGE_DAYS);
    if (d > t) fail('date', 'Date cannot be in the future');
    else if (d < oldest) fail('date', `Date is more than ${MAX_AGE_DAYS} days ago`);
  }

  const point = points.find(p => p.id === draft.pointId);
  if (points.length === 0) fail('point', 'No collection points are available');
  else if (!draft.pointId) fail('point', 'Choose a collection point');
  else if (!point) fail('point', 'That collection point is no longer available');

  const kind = KINDS[draft.kind] ? draft.kind : 'DELIVERY';
  let kg = 0;
  const q = (draft.quantity ?? '').trim();
  if (!q) fail('quantity', 'Quantity is required');
  else if (!PLAIN_DECIMAL.test(q)) fail('quantity', 'Quantity must be a plain number in kg, e.g. 12 or 8.5');
  else {
    const v = Number(q);
    if (!Number.isFinite(v)) fail('quantity', 'Quantity is too large to be a real value');
    else if (v < 0) fail('quantity', 'Quantity cannot be negative');
    else if (v === 0 && kind !== 'WEEKLY_HARVEST') fail('quantity', 'A delivery must be more than 0 kg');
    else if (v > MAX_KG) fail('quantity', `Quantity exceeds ${MAX_KG} kg`);
    else kg = v === 0 ? 0 : v;   // normalise -0
  }

  const notes = (draft.notes ?? '').trim();
  if (notes.length > MAX_NOTES) fail('notes', `Notes must be at most ${MAX_NOTES} characters`);

  if (errors.length) return { ok: false, errors };
  return {
    ok: true,
    record: {
      id: draft.id, farmer, date, pointId: point.id, pointName: point.name,
      quantityKg: kg, kind, notes: notes || null, syncState: 'PENDING',
    },
  };
}

function isRealDate(s) {
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

function startOfDay(d) {
  const c = new Date(d);
  c.setHours(0, 0, 0, 0);
  return c;
}
