// Development default. build.sh overwrites this in dist/ with the release version and git commit.
self.MAVUNOLINK_VERSION = { version: "dev", commit: "dev", builtAt: "" };
