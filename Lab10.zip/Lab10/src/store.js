// MavunoLink PWA: committed records in IndexedDB (survives reload, offline, browser restart).
// Not synced: data belongs to this browser profile on this device only.

const DB_NAME = 'mavunolink';
const DB_VERSION = 1;            // schema version; a later version must migrate, never drop data
const STORE = 'records';

export const testOptions = { simulateWriteFailure: false };

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function allRecords() {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = db.transaction(STORE, 'readonly').objectStore(STORE).getAll();
    req.onsuccess = () => resolve(req.result.sort((a, b) => a.savedAt - b.savedAt));
    req.onerror = () => reject(req.error);
  });
}

/**
 * Commit boundary: one readwrite transaction. The promise resolves only on `complete`
 * (the browser has committed it); any error or abort rejects and nothing is stored.
 * The same id is never stored twice ("alreadySaved").
 */
export async function commit(record) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    const store = tx.objectStore(STORE);
    let outcome = 'saved';
    const get = store.get(record.id);
    get.onsuccess = () => {
      if (get.result) { outcome = 'alreadySaved'; return; }
      store.add({ ...record, savedAt: Date.now() });
      if (testOptions.simulateWriteFailure) tx.abort();
    };
    tx.oncomplete = () => resolve(outcome);
    tx.onabort = () => reject(tx.error || new Error('Simulated write failure: transaction aborted, nothing saved'));
    tx.onerror = () => reject(tx.error);
  });
}
