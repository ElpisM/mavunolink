// MavunoLink PWA service worker: caches the app shell so the app opens offline.
// The cache name includes the version and commit, so each release gets its own cache and
// activating a release deletes the others. Rolling back = redeploying the older build.
importScripts('./src/version.js');
const V = self.MAVUNOLINK_VERSION || { version: 'dev', commit: 'dev' };
const CACHE = `mavunolink-shell-${V.version}-${V.commit}`;
const SHELL = [
  './', './index.html', './styles.css', './manifest.webmanifest', './icon-192.png', './icon-512.png',
  './src/app.js', './src/validate.js', './src/store.js', './src/version.js',
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k.startsWith('mavunolink-shell-') && k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

// Cache first for the app's own files; records never pass through here (they are in IndexedDB).
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== location.origin) return;
  event.respondWith(
    caches.match(event.request, { ignoreSearch: true }).then(hit => {
      if (hit) return hit;
      if (event.request.mode === 'navigate') return caches.match('./index.html');
      return fetch(event.request);
    }),
  );
});
