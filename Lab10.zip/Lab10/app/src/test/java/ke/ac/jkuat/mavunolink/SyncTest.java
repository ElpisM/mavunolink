package ke.ac.jkuat.mavunolink;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/** Lab 8: every sync outcome against the deterministic mock server. */
public class SyncTest {

    private final Sync.MockServer server = new Sync.MockServer(new Sync.MemoryStore());

    private static Sync.Request req(String client, int v) {
        return new Sync.Request(Sync.opId(client, v), client, v);
    }

    @Test public void normalAcknowledgement() {
        Sync.Outcome o = Sync.attempt(server, req("c1", 1), Sync.MockMode.NORMAL);
        assertEquals(Sync.State.ACKNOWLEDGED, o.state);
        assertEquals("SRV-1001", o.serverId);
        assertEquals(1, server.recordCount());
    }

    @Test public void unavailableIsTransientAndStoresNothing() {
        Sync.Outcome o = Sync.attempt(server, req("c1", 1), Sync.MockMode.UNAVAILABLE);
        assertEquals(Sync.State.FAILED, o.state);
        assertTrue(Sync.shouldSend(o.state));
        assertEquals(0, server.recordCount());
    }

    @Test public void lostResponseRetryDoesNotDuplicate() {
        Sync.Request r = req("c1", 1);
        Sync.Outcome first = Sync.attempt(server, r, Sync.MockMode.LOST_RESPONSE);
        assertEquals(Sync.State.FAILED, first.state);           // client cannot know
        assertTrue(first.note.contains("NOT a rejection"));
        assertEquals(1, server.recordCount());                  // but the server did store it

        Sync.Outcome retry = Sync.attempt(server, r, Sync.MockMode.NORMAL);   // same op id
        assertEquals(Sync.State.ACKNOWLEDGED, retry.state);
        assertEquals("SRV-1001", retry.serverId);
        assertTrue(retry.note.contains("replayed"));
        assertEquals(1, server.recordCount());                  // still one: no duplicate
        assertEquals(1, server.opCount());
    }

    @Test public void retryingAnAcknowledgedOperationReplays() {
        Sync.Request r = req("c1", 1);
        Sync.attempt(server, r, Sync.MockMode.NORMAL);
        Sync.Outcome again = Sync.attempt(server, r, Sync.MockMode.NORMAL);
        assertEquals(Sync.State.ACKNOWLEDGED, again.state);
        assertEquals(1, server.recordCount());
    }

    @Test public void malformedAckIsNotSuccess() {
        Sync.Outcome o = Sync.attempt(server, req("c1", 1), Sync.MockMode.MALFORMED_ACK);
        assertEquals(Sync.State.FAILED, o.state);
        assertNull(o.serverId);
        assertTrue(o.note.startsWith("malformed acknowledgement"));
        // retry with the same op id gets the stored, well-formed result
        Sync.Outcome retry = Sync.attempt(server, req("c1", 1), Sync.MockMode.NORMAL);
        assertEquals(Sync.State.ACKNOWLEDGED, retry.state);
        assertEquals(1, server.recordCount());
    }

    @Test public void wrongOpIdEchoIsMalformed() {
        Sync.Response r = new Sync.Response("ACCEPTED", "other-v1", "SRV-9", "ok", false);
        assertEquals(Sync.State.FAILED, Sync.classify(r, "c1-v1").state);
    }

    @Test public void conflictIsNotRetriedAndNotSuccess() {
        Sync.Outcome o = Sync.attempt(server, req("c1", 1), Sync.MockMode.CONFLICT);
        assertEquals(Sync.State.CONFLICT, o.state);
        assertFalse(Sync.shouldSend(o.state));
        assertEquals(0, server.recordCount());
    }

    @Test public void staleVersionIsAConflict() {
        Sync.attempt(server, req("c1", 2), Sync.MockMode.NORMAL);      // server already has v2
        Sync.Outcome old = Sync.attempt(server, req("c1", 1), Sync.MockMode.NORMAL);
        assertEquals(Sync.State.CONFLICT, old.state);
    }

    @Test public void correctionUpdatesSameServerRecord() {
        Sync.attempt(server, req("c1", 1), Sync.MockMode.NORMAL);
        Sync.Outcome v2 = Sync.attempt(server, req("c1", 2), Sync.MockMode.NORMAL);
        assertEquals(Sync.State.ACKNOWLEDGED, v2.state);
        assertEquals("SRV-1001", v2.serverId);
        assertEquals(1, server.recordCount());     // corrected, not duplicated
        assertEquals(2, server.opCount());
    }
}
