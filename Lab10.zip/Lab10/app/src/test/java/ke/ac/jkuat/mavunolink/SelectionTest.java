package ke.ac.jkuat.mavunolink;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/** Lab 4: prompt vs real choice, stable ids, list changes, empty list, checkbox. */
public class SelectionTest {

    private static final Date TODAY;
    static {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(2026, Calendar.NOVEMBER, 18, 10, 0);
        TODAY = c.getTime();
    }

    private static final List<CollectionPoint> STD = CollectionPoints.load(CollectionPoints.Variant.STANDARD);
    private static final List<String> STD_IDS = CollectionPoints.ids(STD);

    private static RecordValidator.Result entry(String pointId, List<String> ids, boolean receipt) {
        return RecordValidator.validateEntry("FRM-001", "2026-11-18", "Maize", "120",
                TransactionType.DELIVERY, pointId, "label", ids, "", receipt, TODAY);
    }

    // S1 the prompt row is not a valid submitted value
    @Test public void promptIsNotAChoice() {
        List<CollectionPoint> rows = CollectionPoints.withPrompt(STD, "Choose a collection point");
        assertTrue(rows.get(0).isPrompt());
        RecordValidator.Result r = entry(rows.get(0).getId(), STD_IDS, false);
        assertFalse(r.valid);
        assertEquals(RecordValidator.Field.POINT, r.field);
        assertEquals("Choose a collection point", r.message);
    }

    // S2 first and last valid options
    @Test public void firstAndLastOptionsAccepted() {
        List<CollectionPoint> rows = CollectionPoints.withPrompt(STD, "Choose");
        assertEquals("CP-01", rows.get(1).getId());
        assertEquals("CP-05", rows.get(rows.size() - 1).getId());
        assertTrue(entry("CP-01", STD_IDS, false).valid);
        assertTrue(entry("CP-05", STD_IDS, false).valid);
    }

    // S3 the record stores the stable id, not the position
    @Test public void recordStoresStableId() {
        RecordValidator.Result r = RecordValidator.validateEntry("FRM-001", "2026-11-18", "Maize", "120",
                TransactionType.DELIVERY, "CP-03", "Thika Road Depot", STD_IDS, "", true, TODAY);
        assertTrue(r.valid);
        assertEquals("CP-03", r.record.getPointId());
        assertEquals("Thika Road Depot (CP-03)", r.record.pointLabel());
        assertTrue(r.record.summary().contains("Collection point: Thika Road Depot (CP-03)"));
    }

    // S4 reordering changes positions but the id still finds the same point
    @Test public void reorderKeepsIdChangesPosition() {
        List<CollectionPoint> before = CollectionPoints.withPrompt(STD, "Choose");
        List<CollectionPoint> after = CollectionPoints.withPrompt(
                CollectionPoints.load(CollectionPoints.Variant.REORDERED), "Choose");
        int oldPos = CollectionPoints.indexOfId(before, "CP-03");
        int newPos = CollectionPoints.indexOfId(after, "CP-03");
        assertEquals(3, oldPos);
        assertEquals(2, newPos);
        // Relying on the old position would now select a different point:
        assertEquals("CP-01", after.get(oldPos).getId());
    }

    // S5 a previously selected option that disappears is detected
    @Test public void removedOptionIsRejected() {
        List<CollectionPoint> closed = CollectionPoints.load(CollectionPoints.Variant.CP03_CLOSED);
        assertEquals(-1, CollectionPoints.indexOfId(CollectionPoints.withPrompt(closed, "Choose"), "CP-03"));
        RecordValidator.Result r = entry("CP-03", CollectionPoints.ids(closed), false);
        assertEquals(RecordValidator.Field.POINT, r.field);
        assertTrue(r.message.contains("no longer available"));
    }

    // S6 empty option list blocks submission with its own message
    @Test public void emptyListBlocksSubmit() {
        List<CollectionPoint> none = CollectionPoints.load(CollectionPoints.Variant.EMPTY);
        assertTrue(none.isEmpty());
        assertEquals(1, CollectionPoints.withPrompt(none, "No collection points available").size());
        RecordValidator.Result r = entry(null, Collections.<String>emptyList(), false);
        assertEquals(RecordValidator.Field.POINT, r.field);
        assertTrue(r.message.startsWith("No collection points are available"));
    }

    // S7 checkbox is independent: both values valid, neither affects the point rule
    @Test public void checkboxIndependent() {
        assertTrue(entry("CP-02", STD_IDS, true).record.isPaperReceipt());
        assertFalse(entry("CP-02", STD_IDS, false).record.isPaperReceipt());
        assertEquals(RecordValidator.Field.POINT, entry(null, STD_IDS, true).field);
    }

    // S8 Lab 2 records still work without a point
    @Test public void olderRecordsHaveNoPoint() {
        RecordValidator.Result r = RecordValidator.validateForm("FRM-001", "2026-11-18", "Maize", "120",
                TransactionType.DELIVERY, "", TODAY);
        assertTrue(r.valid);
        assertNull(r.record.pointLabel());
        assertFalse(r.record.summary().contains("Collection point"));
    }
}
