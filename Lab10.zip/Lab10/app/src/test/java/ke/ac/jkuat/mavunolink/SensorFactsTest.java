package ke.ac.jkuat.mavunolink;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/** Lab 5: units and honest labelling of sensor metadata (no Android needed). */
public class SensorFactsTest {

    private static SensorFacts accel() {
        return new SensorFacts("Goldfish 3-axis Accelerometer", SensorFacts.TYPE_ACCELEROMETER,
                "android.sensor.accelerometer", "The Android Open Source Project", 1,
                39.3f, 0.0023956299f, 3.0f, 10000, 500000, 0, false);
    }

    @Test public void unitsMatchSensorType() {
        assertEquals("m/s²", SensorFacts.unitFor(SensorFacts.TYPE_ACCELEROMETER));
        assertEquals("µT", SensorFacts.unitFor(SensorFacts.TYPE_MAGNETIC_FIELD));
        assertEquals("rad/s", SensorFacts.unitFor(SensorFacts.TYPE_GYROSCOPE));
        assertEquals("lx", SensorFacts.unitFor(SensorFacts.TYPE_LIGHT));
        assertEquals("hPa", SensorFacts.unitFor(SensorFacts.TYPE_PRESSURE));
        assertEquals("°C", SensorFacts.unitFor(SensorFacts.TYPE_AMBIENT_TEMPERATURE));
        assertEquals("%", SensorFacts.unitFor(SensorFacts.TYPE_RELATIVE_HUMIDITY));
        assertEquals("cm", SensorFacts.unitFor(SensorFacts.TYPE_PROXIMITY));
    }

    @Test public void unknownTypeIsReportedHonestly() {
        assertNull(SensorFacts.unitFor(65_537));
        SensorFacts f = new SensorFacts("Vendor thing", 65_537, "com.vendor.thing", "", 1,
                1f, 1f, 0f, 0, 0, -1, false);
        assertTrue(f.rangeText().contains("unit not known"));
        assertEquals("(not reported)", f.vendorText());
        assertEquals("Other (com.vendor.thing)", SensorFacts.typeLabel(f.type, f.stringType));
        assertEquals("not reported", SensorFacts.reportingModeLabel(f.reportingMode));
    }

    @Test public void delayConvertedToRate() {
        assertEquals("10000 µs (up to 100 Hz)", accel().minDelayText());
        assertEquals("500000 µs", accel().maxDelayText());
    }

    @Test public void zeroDelayMeansNoFixedRate() {
        SensorFacts step = new SensorFacts("Step counter", SensorFacts.TYPE_STEP_COUNTER, null, "x", 1,
                1e9f, 1f, 0f, 0, 0, 1, true);
        assertEquals("0 µs: no fixed rate (on-change)", step.minDelayText());
        assertTrue(step.powerText().contains("reported as 0"));
        assertTrue(step.detailText().contains("wake-up"));
    }

    @Test public void numbersAreReadable() {
        assertEquals("39.3", SensorFacts.num(39.3f));
        assertEquals("0.00239563", SensorFacts.num(0.0023956299f));
        assertEquals("3", SensorFacts.num(3.0f));
        assertTrue(accel().detailText().contains("Range: 39.3 m/s²"));
    }
}
