package ke.ac.jkuat.mavunolink;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/** Lab 6: smoothing rule, event-timing maths, observation rows. */
public class LiveStatsTest {

    @Test public void smootherStartsAtFirstValueThenMoves20Percent() {
        LiveStats.Smoother s = new LiveStats.Smoother();
        assertEquals(100.0, s.add(100), 1e-9);
        assertEquals(80.0, s.add(0), 1e-9);      // 100 + 0.2 * (0 - 100)
        assertEquals(64.0, s.add(0), 1e-9);      // 80 + 0.2 * (0 - 80)
    }

    @Test public void smootherDampsSingleSpike() {
        LiveStats.Smoother s = new LiveStats.Smoother();
        for (int i = 0; i < 20; i++) s.add(300);
        double afterSpike = s.add(3000);         // one glitch
        assertEquals(840.0, afterSpike, 1e-6);   // raw jumped 2700, smoothed only 540
    }

    @Test public void smootherFollowsStepWithinAbout10Events() {
        LiveStats.Smoother s = new LiveStats.Smoother();
        s.add(0);
        double v = 0;
        for (int i = 0; i < 10; i++) v = s.add(1000);
        assertTrue(v > 890 && v < 900);           // 1000 * (1 - 0.8^10) ≈ 892.6
    }

    @Test public void intervalsGiveObservedRate() {
        LiveStats.IntervalStats st = new LiveStats.IntervalStats();
        long t = 1_000_000_000L;
        for (int i = 0; i < 11; i++) { st.add(t); t += 66_666_667L; }   // ~15 Hz
        assertEquals(11, st.events());
        assertEquals(10, st.samples());
        assertEquals(66.67, st.meanMs(), 0.01);
        assertEquals(15.0, st.meanHz(), 0.01);
        assertTrue(st.describe().startsWith("observed mean 66.7 ms (15.0 Hz)"));
    }

    @Test public void irregularIntervalsShowMinAndMax() {
        LiveStats.IntervalStats st = new LiveStats.IntervalStats();
        st.add(0);
        st.add(60_000_000L);
        st.add(260_000_000L);       // a 200 ms gap: on-change sensor saw no change
        assertEquals(60.0, st.minMs(), 1e-9);
        assertEquals(200.0, st.maxMs(), 1e-9);
        assertEquals(130.0, st.meanMs(), 1e-9);
    }

    @Test public void noEventsDescribedHonestly() {
        LiveStats.IntervalStats st = new LiveStats.IntervalStats();
        assertEquals("no events yet", st.describe());
        st.add(5);
        assertEquals("1 event so far (need 2 for an interval)", st.describe());
        assertEquals("requested 60000 µs (nominal 16.7 Hz)", LiveStats.requestedText(60000));
    }

    @Test public void magnitudeAtRestIsGravity() {
        assertEquals(9.81, LiveStats.magnitude(0f, 0f, 9.81f), 1e-5);
        assertEquals(9.81, LiveStats.magnitude(0f, 6.9367f, 6.9367f), 1e-3);   // tilted 45°, same size
    }

    @Test public void observationRowAndCsv() {
        LiveStats.Observation o = new LiveStats.Observation("12:01:05", "covered, desk", 0.0, 12.5, "lx", 42);
        assertTrue(o.row().contains("12:01:05"));
        assertEquals("12:01:05,covered; desk,0.00,12.50,lx,42", o.csv());
    }
}
