package ke.ac.jkuat.mavunolink;

/**
 * Lab 8: one row of the local "records" table. The FarmerRecord holds the business
 * fields; this class adds identity, version and sync bookkeeping.
 */
public final class StoredRecord {
    public final long localId;          // SQLite INTEGER PRIMARY KEY (this phone only)
    public final String clientId;       // UUID made on the phone; never changes; sent to the server
    public final int version;           // 1 on save, +1 on each correction
    public final Sync.State state;
    public final String serverId;       // set by a valid acknowledgement
    public final int attempts;
    public final String lastNote;       // last sync outcome in words
    public final long createdAt, updatedAt;
    public final FarmerRecord record;

    public StoredRecord(long localId, String clientId, int version, Sync.State state, String serverId,
                        int attempts, String lastNote, long createdAt, long updatedAt, FarmerRecord record) {
        this.localId = localId;
        this.clientId = clientId;
        this.version = version;
        this.state = state;
        this.serverId = serverId;
        this.attempts = attempts;
        this.lastNote = lastNote;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.record = record;
    }

    /** Operation id for the current version; reused for every retry of this version. */
    public String opId() {
        return Sync.opId(clientId, version);
    }

    public String shortClient() {
        return clientId.length() > 8 ? clientId.substring(0, 8) : clientId;
    }
}
