package ke.ac.jkuat.mavunolink;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Lab 5: sensor inventory and capability analysis.
 *
 * Mechanism: getSystemService(SENSOR_SERVICE) -> SensorManager.getSensorList(TYPE_ALL)
 *   -> each android.hardware.Sensor is copied into a SensorFacts (metadata only)
 *   -> SensorRowAdapter -> ListView, with a header showing device, OS, environment,
 *      total count and availability of the sensors MavunoLink might use.
 *
 * No SensorEventListener is registered: this screen reads what sensors CLAIM, not what
 * they measure (live readings are Lab 6). That also means it costs no battery.
 *
 * Safe handling:
 *   - getSystemService may return null      -> "service not available" message, empty list
 *   - getDefaultSensor(type) may return null -> that candidate is shown as "not available"
 *   - an empty list                          -> empty-state message instead of rows
 *   - menu "Simulate empty inventory"        -> exercises the empty path on any device
 */
public class SensorsActivity extends AppCompatActivity {

    static final String TAG_SENSOR = "MavunoSensor";
    private static final String KEY_SIMULATE_EMPTY = "simulate_empty";

    /** Sensor types that could help MavunoLink, with the reason shown to the user. */
    private static final int[] CANDIDATE_TYPES = {
            SensorFacts.TYPE_AMBIENT_TEMPERATURE,
            SensorFacts.TYPE_RELATIVE_HUMIDITY,
            SensorFacts.TYPE_LIGHT,
            SensorFacts.TYPE_ACCELEROMETER,
            SensorFacts.TYPE_PRESSURE,
    };
    private static final String[] CANDIDATE_USES = {
            "storage temperature at a collection point",
            "storage humidity (mushrooms spoil when damp)",
            "screen readability outdoors",
            "detect the phone being dropped or steady for a photo",
            "weather trend (falling pressure before rain)",
    };

    private boolean simulateEmpty;
    private final List<SensorFacts> facts = new ArrayList<>();
    private SensorRowAdapter adapter;
    private View header;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensors);
        ActionBar bar = getSupportActionBar();
        if (bar != null) bar.setDisplayHomeAsUpEnabled(true);

        if (savedInstanceState != null) {
            simulateEmpty = savedInstanceState.getBoolean(KEY_SIMULATE_EMPTY, false);
        }

        ListView list = findViewById(R.id.lvSensors);
        header = LayoutInflater.from(this).inflate(R.layout.header_sensors, list, false);
        list.addHeaderView(header, null, false);
        adapter = new SensorRowAdapter(this, facts);
        list.setAdapter(adapter);

        loadInventory("onCreate (" + (savedInstanceState == null ? "first open" : "recreated") + ")");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(KEY_SIMULATE_EMPTY, simulateEmpty);
    }

    // ---------------------------------------------------------------- inventory

    private void loadInventory(String reason) {
        SensorManager sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        facts.clear();
        String emptyMessage = null;
        if (simulateEmpty) {
            emptyMessage = getString(R.string.sensors_empty_simulated);
        } else if (sm == null) {
            emptyMessage = getString(R.string.sensors_no_service);
        } else {
            List<Sensor> sensors = sm.getSensorList(Sensor.TYPE_ALL);
            for (Sensor s : sensors) facts.add(toFacts(s));
            if (facts.isEmpty()) emptyMessage = getString(R.string.sensors_empty_real);
        }
        adapter.notifyDataSetChanged();

        TextView tvDevice = header.findViewById(R.id.tvDevice);
        TextView tvEnv = header.findViewById(R.id.tvEnvironment);
        TextView tvCount = header.findViewById(R.id.tvSensorCount);
        TextView tvCandidates = header.findViewById(R.id.tvCandidates);
        TextView tvEmpty = header.findViewById(R.id.tvSensorsEmpty);
        TextView tvListHeading = header.findViewById(R.id.tvListHeading);

        tvDevice.setText(deviceText());
        tvEnv.setText(environmentText());
        tvCount.setText(facts.isEmpty() ? getString(R.string.sensors_count_zero)
                : getString(R.string.sensors_count, facts.size()));
        tvCandidates.setText(candidateText(simulateEmpty ? null : sm));
        tvEmpty.setText(emptyMessage);
        tvEmpty.setVisibility(emptyMessage == null ? View.GONE : View.VISIBLE);
        tvListHeading.setVisibility(emptyMessage == null ? View.VISIBLE : View.GONE);

        log("INVENTORY " + reason + " -> " + facts.size() + " sensors"
                + (simulateEmpty ? " (simulated empty)" : "")
                + ", environment=" + (isProbablyEmulator() ? "emulator" : "physical device"));
    }

    private static SensorFacts toFacts(Sensor s) {
        return new SensorFacts(s.getName(), s.getType(), s.getStringType(), s.getVendor(),
                s.getVersion(), s.getMaximumRange(), s.getResolution(), s.getPower(),
                s.getMinDelay(), s.getMaxDelay(), s.getReportingMode(), s.isWakeUpSensor());
    }

    private static String deviceText() {
        return "Manufacturer: " + Build.MANUFACTURER
                + "\nModel: " + Build.MODEL + " (device " + Build.DEVICE + ")"
                + "\nAndroid " + Build.VERSION.RELEASE + ", API level " + Build.VERSION.SDK_INT
                + "\nHardware: " + Build.HARDWARE;
    }

    /**
     * Emulator check from build properties. It is a heuristic, so the screen says
     * "probably" and shows the evidence instead of claiming certainty.
     */
    static boolean isProbablyEmulator() {
        String fp = Build.FINGERPRINT == null ? "" : Build.FINGERPRINT;
        String model = Build.MODEL == null ? "" : Build.MODEL;
        String hw = Build.HARDWARE == null ? "" : Build.HARDWARE;
        String product = Build.PRODUCT == null ? "" : Build.PRODUCT;
        return fp.startsWith("generic") || fp.contains("emulator") || fp.contains("sdk_gphone")
                || model.contains("sdk_gphone") || model.contains("Emulator")
                || model.contains("Android SDK built for")
                || hw.contains("ranchu") || hw.contains("goldfish")
                || product.startsWith("sdk") || product.contains("emulator");
    }

    private static String environmentText() {
        if (isProbablyEmulator()) {
            return "Environment: SIMULATED (Android Emulator; hardware=" + Build.HARDWARE + ")."
                    + " Sensor values are generated by the emulator, and the list reflects the"
                    + " emulator's virtual hardware, not any particular phone.";
        }
        return "Environment: physical device (no emulator markers in build properties).";
    }

    /** Uses getDefaultSensor(type), which returns null when the type is unavailable. */
    private static String candidateText(SensorManager sm) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < CANDIDATE_TYPES.length; i++) {
            int type = CANDIDATE_TYPES[i];
            Sensor s = sm == null ? null : sm.getDefaultSensor(type);
            if (i > 0) sb.append('\n');
            sb.append(s != null ? "✓ " : "✗ ")
                    .append(SensorFacts.typeLabel(type, null))
                    .append(s != null ? ": available (" + s.getName() + ")" : ": not available on this device")
                    .append(" — ").append(CANDIDATE_USES[i]);
        }
        return sb.toString();
    }

    private static void log(String msg) {
        Log.d(TAG_SENSOR, msg);
        MainActivity.appendTrace(TAG_SENSOR, msg);
    }

    // ---------------------------------------------------------------- menu

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.sensors_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem mi = menu.findItem(R.id.action_simulate_empty);
        if (mi != null) mi.setChecked(simulateEmpty);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_simulate_empty) {
            simulateEmpty = !simulateEmpty;
            item.setChecked(simulateEmpty);
            loadInventory("simulate empty " + (simulateEmpty ? "on" : "off"));
            return true;
        } else if (id == R.id.action_refresh_sensors) {
            loadInventory("refresh");
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    // ---------------------------------------------------------------- adapter

    /** Binds SensorFacts to item_sensor.xml; long names wrap because the row has no maxLines. */
    static final class SensorRowAdapter extends ArrayAdapter<SensorFacts> {
        private final LayoutInflater inflater;

        SensorRowAdapter(Context c, List<SensorFacts> items) {
            super(c, 0, items);
            inflater = LayoutInflater.from(c);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View row = convertView != null ? convertView
                    : inflater.inflate(R.layout.item_sensor, parent, false);
            SensorFacts f = getItem(position);
            if (f != null) {
                ((TextView) row.findViewById(R.id.tvSensorName)).setText((position + 1) + ". " + f.name);
                String unit = f.unit();
                ((TextView) row.findViewById(R.id.tvSensorKind)).setText(
                        SensorFacts.typeLabel(f.type, f.stringType)
                                + " · unit: " + (unit == null ? "not known" : unit));
                ((TextView) row.findViewById(R.id.tvSensorDetails)).setText(f.detailText());
            }
            return row;
        }
    }

}
