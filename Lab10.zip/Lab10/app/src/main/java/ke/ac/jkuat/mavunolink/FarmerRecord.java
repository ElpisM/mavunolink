package ke.ac.jkuat.mavunolink;

import java.io.Serializable;
import java.util.Locale;

/**
 * Model: one committed farmer record. Immutable, and only ever constructed
 * from values that already passed {@link RecordValidator}.
 *
 * Lab 2 adds the transaction date (ISO yyyy-MM-dd) and optional notes.
 * Serializable so the list can be placed in the saved-instance-state Bundle,
 * which is NOT persistent storage.
 */
public final class FarmerRecord implements Serializable {
    private static final long serialVersionUID = 4L;

    private final String farmerRef;
    private final String crop;
    private final double quantityKg;
    private final TransactionType type;
    private final String date;    // yyyy-MM-dd, null only for Lab 1 style records
    private final String notes;   // null when the optional field was left empty
    private final String pointId;     // Lab 4: stable collection-point id, e.g. "CP-03"
    private final String pointName;   // Lab 4: label at the time of commit (display only)
    private final boolean paperReceipt;   // Lab 4: optional preference (checkbox)

    public FarmerRecord(String farmerRef, String crop, double quantityKg, TransactionType type) {
        this(farmerRef, crop, quantityKg, type, null, null);
    }

    public FarmerRecord(String farmerRef, String crop, double quantityKg, TransactionType type,
                        String date, String notes) {
        this(farmerRef, crop, quantityKg, type, date, notes, null, null, false);
    }

    public FarmerRecord(String farmerRef, String crop, double quantityKg, TransactionType type,
                        String date, String notes, String pointId, String pointName,
                        boolean paperReceipt) {
        this.pointId = pointId;
        this.pointName = pointName;
        this.paperReceipt = paperReceipt;
        this.farmerRef = farmerRef;
        this.crop = crop;
        this.quantityKg = quantityKg;
        this.type = type;
        this.date = date;
        this.notes = notes;
    }

    public String getFarmerRef() { return farmerRef; }
    public String getCrop() { return crop; }
    public double getQuantityKg() { return quantityKg; }
    public TransactionType getType() { return type; }
    public String getDate() { return date; }
    public String getNotes() { return notes; }
    public boolean hasNotes() { return notes != null && !notes.isEmpty(); }
    public String getPointId() { return pointId; }
    public String getPointName() { return pointName; }
    public boolean isPaperReceipt() { return paperReceipt; }

    /** "Thika Road Depot (CP-03)", or null for records made before Lab 4. */
    public String pointLabel() {
        return pointId == null ? null : pointName + " (" + pointId + ")";
    }

    public String formattedQuantity() {
        return String.format(Locale.US, "%.2f kg", quantityKg);
    }

    /** Human-readable summary used in the confirmation dialog. */
    public String summary() {
        return "Farmer: " + farmerRef
                + "\nDate: " + (date == null ? "-" : date)
                + (pointId == null ? "" : "\nCollection point: " + pointLabel())
                + "\nCrop: " + crop
                + "\nQuantity: " + formattedQuantity()
                + "\nType: " + type.getLabel()
                + "\nNotes: " + (hasNotes() ? notes : "(none)")
                + (pointId == null ? "" : "\nPaper receipt: " + (paperReceipt ? "yes" : "no"));
    }

    @Override
    public String toString() {
        return farmerRef + " | " + (date == null ? "-" : date) + " | " + crop + " | "
                + formattedQuantity() + " | " + type.getLabel();
    }
}
