package ke.ac.jkuat.mavunolink;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Lab 4 adapter between the source collection (List<CollectionPoint>, prompt first)
 * and the Spinner. It is more than a copy of the data:
 *  - it decides how each item looks, with TWO layouts: the closed Spinner
 *    (spinner_point_selected.xml, one line) and the open drop-down
 *    (spinner_point_dropdown.xml, name + id/schedule);
 *  - it recycles row Views (convertView) instead of creating one per item;
 *  - it marks the prompt row as not enabled, so it cannot be picked from the drop-down;
 *  - it notifies the Spinner when the collection changes (notifyDataSetChanged).
 */
public class CollectionPointAdapter extends ArrayAdapter<CollectionPoint> {

    private final LayoutInflater inflater;

    public CollectionPointAdapter(Context context, List<CollectionPoint> rows) {
        super(context, 0, rows);
        inflater = LayoutInflater.from(context);
    }

    /** Closed Spinner: one line. The prompt is shown in a muted italic style. */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView tv = (TextView) (convertView != null ? convertView
                : inflater.inflate(R.layout.spinner_point_selected, parent, false));
        CollectionPoint p = getItem(position);
        if (p != null) {
            tv.setText(p.getName());
            tv.setTypeface(null, p.isPrompt() ? Typeface.ITALIC : Typeface.NORMAL);
            tv.setAlpha(p.isPrompt() ? 0.6f : 1f);
        }
        return tv;
    }

    /** Open drop-down: two lines for real points; the prompt has no second line. */
    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        View row = convertView != null ? convertView
                : inflater.inflate(R.layout.spinner_point_dropdown, parent, false);
        TextView name = row.findViewById(R.id.tvPointName);
        TextView detail = row.findViewById(R.id.tvPointDetail);
        CollectionPoint p = getItem(position);
        if (p != null) {
            name.setText(p.getName());
            name.setTypeface(null, p.isPrompt() ? Typeface.ITALIC : Typeface.BOLD);
            row.setAlpha(p.isPrompt() ? 0.6f : 1f);
            if (p.isPrompt()) {
                detail.setVisibility(View.GONE);
            } else {
                detail.setVisibility(View.VISIBLE);
                detail.setText(p.getId() + " · " + p.getArea());
            }
        }
        return row;
    }

    /** The prompt cannot be chosen from the drop-down. */
    @Override
    public boolean isEnabled(int position) {
        CollectionPoint p = getItem(position);
        return p != null && !p.isPrompt();
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }
}
