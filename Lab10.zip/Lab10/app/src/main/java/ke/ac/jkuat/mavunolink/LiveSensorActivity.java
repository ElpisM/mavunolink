package ke.ac.jkuat.mavunolink;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Lab 6: live sensor experiment (ambient light by default, accelerometer optional).
 *
 * Listener lifecycle: registered in onResume(), unregistered in onPause(). That is the
 * "visible and in front" pair, so no events are delivered (and no battery is spent)
 * while another screen covers this one, the app is in the background, or the screen
 * is off. `registered` guards against a second registration; the on-screen line
 * "Listener: registered (1 active)" and the trace are the evidence.
 *
 * Rotation destroys and recreates this Activity: onPause unregisters the old listener,
 * onResume of the new instance registers a new one. The observation table and the chosen
 * sensor are kept in the Bundle; the smoother and timing stats restart (stated on screen).
 *
 * Sampling: SENSOR_DELAY_UI requests one event about every 60 000 µs. It is a hint, not
 * a guarantee: the system may deliver faster or slower, and on-change sensors such as
 * light deliver nothing while the value is constant. The screen therefore shows the
 * observed interval between SensorEvent.timestamp values next to the requested one.
 */
public class LiveSensorActivity extends AppCompatActivity implements SensorEventListener {

    static final String TAG_LIVE = "MavunoLive";
    private static final int REQUESTED_DELAY_US = 60_000;   // SENSOR_DELAY_UI

    private static final String KEY_TYPE = "live_type";
    private static final String KEY_OBS = "live_observations";
    private static final String KEY_SIM_MISSING = "live_sim_missing";

    private SensorManager sensorManager;
    private Sensor sensor;                 // null when missing (real or simulated)
    private int sensorType = Sensor.TYPE_LIGHT;
    private boolean simulateMissing;
    private boolean registered;            // guard: never register twice
    private int accuracy = SensorManager.SENSOR_STATUS_ACCURACY_HIGH;

    private final LiveStats.Smoother smoother = new LiveStats.Smoother();
    private final LiveStats.IntervalStats timing = new LiveStats.IntervalStats();
    private double lastRaw = Double.NaN;
    private ArrayList<LiveStats.Observation> observations = new ArrayList<>();

    private TextView tvQuestion, tvIdentity, tvEnv, tvRaw, tvSmoothed, tvAxes, tvStatus, tvTiming, tvListener, tvTable;
    private EditText etCondition;
    private RadioGroup rgSensor;

    // ---------------------------------------------------------------- lifecycle

    @Override
    @SuppressWarnings("unchecked")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_sensor);
        ActionBar bar = getSupportActionBar();
        if (bar != null) bar.setDisplayHomeAsUpEnabled(true);

        tvQuestion = findViewById(R.id.tvQuestion);
        tvIdentity = findViewById(R.id.tvLiveIdentity);
        tvEnv = findViewById(R.id.tvLiveEnv);
        tvRaw = findViewById(R.id.tvRaw);
        tvSmoothed = findViewById(R.id.tvSmoothed);
        tvAxes = findViewById(R.id.tvAxes);
        tvStatus = findViewById(R.id.tvLiveStatus);
        tvTiming = findViewById(R.id.tvTiming);
        tvListener = findViewById(R.id.tvListener);
        tvTable = findViewById(R.id.tvTable);
        etCondition = findViewById(R.id.etCondition);
        rgSensor = findViewById(R.id.rgLiveSensor);

        if (savedInstanceState != null) {
            sensorType = savedInstanceState.getInt(KEY_TYPE, Sensor.TYPE_LIGHT);
            simulateMissing = savedInstanceState.getBoolean(KEY_SIM_MISSING, false);
            Object saved = savedInstanceState.getSerializable(KEY_OBS);
            if (saved instanceof ArrayList) observations = (ArrayList<LiveStats.Observation>) saved;
        }
        rgSensor.check(sensorType == Sensor.TYPE_ACCELEROMETER ? R.id.rbAccel : R.id.rbLight);
        rgSensor.setOnCheckedChangeListener((g, id) -> switchSensor(
                id == R.id.rbAccel ? Sensor.TYPE_ACCELEROMETER : Sensor.TYPE_LIGHT));

        findViewById(R.id.btnRecord).setOnClickListener(v -> recordObservation());
        findViewById(R.id.btnCopy).setOnClickListener(v -> copyCsv());

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        selectSensor();
        tvEnv.setText(SensorsActivity.isProbablyEmulator()
                ? "Data: SIMULATED. This is the Android Emulator, so values come from the emulator's"
                  + " virtual sensors (Extended controls → Virtual sensors), not from a physical sensor."
                  + " The experiment tests the app's handling of the values, not the real world."
                : "Data: MEASURED by this device's physical sensor. No calibration was performed.");
        renderTable();
        log("onCreate (" + (savedInstanceState == null ? "first open" : "recreated, "
                + observations.size() + " observations restored; smoothing and timing restart") + ")");
    }

    @Override
    protected void onResume() {
        super.onResume();
        register("onResume");
    }

    @Override
    protected void onPause() {
        unregister("onPause");   // stop events before the screen stops being in front
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_TYPE, sensorType);
        outState.putBoolean(KEY_SIM_MISSING, simulateMissing);
        outState.putSerializable(KEY_OBS, observations);
    }

    @Override
    protected void onDestroy() {
        log("onDestroy (isChangingConfigurations=" + isChangingConfigurations() + ", registered=" + registered + ")");
        super.onDestroy();
    }

    // ---------------------------------------------------------------- sensor selection

    /** Finds the default sensor of the chosen type; null means "missing" and is handled. */
    private void selectSensor() {
        sensor = (sensorManager == null || simulateMissing) ? null : sensorManager.getDefaultSensor(sensorType);
        smoother.reset();
        timing.reset();
        lastRaw = Double.NaN;
        accuracy = SensorManager.SENSOR_STATUS_ACCURACY_HIGH;

        tvQuestion.setText(sensorType == Sensor.TYPE_LIGHT ? R.string.live_question_light : R.string.live_question_accel);
        tvAxes.setVisibility(sensorType == Sensor.TYPE_ACCELEROMETER ? View.VISIBLE : View.GONE);
        tvAxes.setText("");

        boolean available = sensor != null;
        findViewById(R.id.btnRecord).setEnabled(available);
        if (!available) {
            tvIdentity.setText("Sensor: none (" + label() + ")");
            tvRaw.setText("—");
            tvSmoothed.setText("");
            showStatus(getString(simulateMissing ? R.string.live_missing_simulated : R.string.live_missing, label()), true);
            log("SENSOR " + label() + " -> MISSING" + (simulateMissing ? " (simulated)" : "") + "; nothing to register");
        } else {
            tvIdentity.setText("Sensor: " + sensor.getName() + "\nVendor: " + sensor.getVendor()
                    + " · type " + sensor.getType() + " · unit " + unit()
                    + "\nRange " + LiveStats.fmt(sensor.getMaximumRange()) + " " + unit()
                    + ", resolution " + sensor.getResolution() + " " + unit()
                    + ", power " + sensor.getPower() + " mA");
            tvRaw.setText("— " + unit());
            tvSmoothed.setText("");
            showStatus(getString(sensorType == Sensor.TYPE_LIGHT ? R.string.live_waiting_light : R.string.live_waiting_accel), false);
            log("SENSOR " + label() + " -> " + sensor.getName());
        }
        updateTiming();
        updateListenerLine();
    }

    private void switchSensor(int type) {
        if (type == sensorType) return;
        unregister("sensor switch");
        sensorType = type;
        selectSensor();
        register("sensor switch");
    }

    // ---------------------------------------------------------------- register / unregister

    private void register(String why) {
        if (sensor == null || sensorManager == null) {
            log("REGISTER skipped (" + why + "): no sensor");
            updateListenerLine();
            return;
        }
        if (registered) {
            log("REGISTER skipped (" + why + "): already registered, no duplicate");
            return;
        }
        registered = sensorManager.registerListener(this, sensor, REQUESTED_DELAY_US);
        log("REGISTER (" + why + ") -> " + (registered ? "ok" : "FAILED") + ", active listeners=" + (registered ? 1 : 0)
                + ", " + LiveStats.requestedText(REQUESTED_DELAY_US));
        updateListenerLine();
    }

    private void unregister(String why) {
        if (!registered) {
            log("UNREGISTER (" + why + ") -> nothing registered");
            return;
        }
        sensorManager.unregisterListener(this);
        registered = false;
        log("UNREGISTER (" + why + ") -> active listeners=0 after " + timing.events() + " events");
        updateListenerLine();
    }

    private void updateListenerLine() {
        tvListener.setText("Listener: " + (registered ? "registered (1 active)" : "not registered (0 active)"));
    }

    // ---------------------------------------------------------------- events

    @Override
    public void onSensorChanged(SensorEvent event) {
        timing.add(event.timestamp);
        double raw;
        if (sensorType == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0], y = event.values[1], z = event.values[2];
            raw = LiveStats.magnitude(x, y, z);
            tvAxes.setText(String.format(Locale.US, "x %.2f   y %.2f   z %.2f m/s²", x, y, z));
        } else {
            raw = event.values[0];
        }
        if (Double.isNaN(raw) || Double.isInfinite(raw)) {
            showStatus("Received a non-numeric reading; it was ignored.", true);
            return;
        }
        lastRaw = raw;
        double smooth = smoother.add(raw);

        tvRaw.setText(LiveStats.fmt(raw) + " " + unit() + (sensorType == Sensor.TYPE_ACCELEROMETER ? " (magnitude)" : ""));
        tvSmoothed.setText("Smoothed (EMA, α = 0.2): " + LiveStats.fmt(smooth) + " " + unit());
        if (accuracy == SensorManager.SENSOR_STATUS_UNRELIABLE || accuracy == SensorManager.SENSOR_STATUS_NO_CONTACT) {
            showStatus(getString(R.string.live_unreliable, accuracyLabel(accuracy)), true);
        } else {
            hideStatus();
        }
        updateTiming();
    }

    @Override
    public void onAccuracyChanged(Sensor s, int newAccuracy) {
        accuracy = newAccuracy;
        log("ACCURACY -> " + accuracyLabel(newAccuracy));
        if (newAccuracy == SensorManager.SENSOR_STATUS_UNRELIABLE || newAccuracy == SensorManager.SENSOR_STATUS_NO_CONTACT) {
            showStatus(getString(R.string.live_unreliable, accuracyLabel(newAccuracy)), true);
        }
    }

    private void updateTiming() {
        tvTiming.setText("Timing: " + LiveStats.requestedText(REQUESTED_DELAY_US) + "; " + timing.describe()
                + "; events " + timing.events());
    }

    // ---------------------------------------------------------------- observation table

    private void recordObservation() {
        String cond = etCondition.getText().toString().trim();
        if (cond.isEmpty()) {
            etCondition.setError(getString(R.string.live_need_condition));
            etCondition.requestFocus();
            return;
        }
        if (Double.isNaN(lastRaw)) {
            Toast.makeText(this, R.string.live_need_reading, Toast.LENGTH_SHORT).show();
            return;
        }
        String time = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        LiveStats.Observation o = new LiveStats.Observation(time, cond, lastRaw, smoother.value(), unit(), timing.events());
        observations.add(o);
        renderTable();
        Log.i(TAG_LIVE, "OBS," + o.csv());
        log("OBSERVATION " + o.csv());
        etCondition.setText("");
    }

    private void renderTable() {
        if (observations.isEmpty()) {
            tvTable.setText("No observations yet. Set a condition, wait for the value to settle, then tap Record.");
            return;
        }
        StringBuilder sb = new StringBuilder(LiveStats.Observation.header(unit())).append('\n');
        for (LiveStats.Observation o : observations) sb.append(o.row()).append('\n');
        tvTable.setText(sb.toString().trim());
    }

    private void copyCsv() {
        StringBuilder sb = new StringBuilder(LiveStats.Observation.csvHeader()).append('\n');
        for (LiveStats.Observation o : observations) sb.append(o.csv()).append('\n');
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("observations", sb.toString()));
            Toast.makeText(this, R.string.live_copied, Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------- helpers

    private String unit() {
        return sensorType == Sensor.TYPE_ACCELEROMETER ? "m/s²" : "lx";
    }

    private String label() {
        return sensorType == Sensor.TYPE_ACCELEROMETER ? "accelerometer" : "ambient light";
    }

    private static String accuracyLabel(int a) {
        switch (a) {
            case SensorManager.SENSOR_STATUS_ACCURACY_HIGH: return "high";
            case SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM: return "medium";
            case SensorManager.SENSOR_STATUS_ACCURACY_LOW: return "low";
            case SensorManager.SENSOR_STATUS_UNRELIABLE: return "unreliable";
            case SensorManager.SENSOR_STATUS_NO_CONTACT: return "no contact";
            default: return "unknown (" + a + ")";
        }
    }

    private void showStatus(String msg, boolean problem) {
        tvStatus.setText(msg);
        tvStatus.setBackgroundColor(problem ? 0xFFFDECEA : 0xFFE3F4EE);   // red problem / jungle-green info
        tvStatus.setTextColor(problem ? 0xFFB71C1C : 0xFF0F4D3C);
        tvStatus.setVisibility(View.VISIBLE);
    }

    private void hideStatus() {
        tvStatus.setVisibility(View.GONE);
    }

    private static void log(String msg) {
        Log.d(TAG_LIVE, msg);
        MainActivity.appendTrace(TAG_LIVE, msg);
    }

    // ---------------------------------------------------------------- menu

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.live_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem mi = menu.findItem(R.id.action_simulate_missing);
        if (mi != null) mi.setChecked(simulateMissing);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_simulate_missing) {
            unregister("simulate missing toggled");
            simulateMissing = !simulateMissing;
            item.setChecked(simulateMissing);
            selectSensor();
            register("simulate missing toggled");
            return true;
        } else if (id == R.id.action_clear_observations) {
            observations.clear();
            renderTable();
            log("OBSERVATIONS cleared");
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
