package ke.ac.jkuat.mavunolink;

import java.util.Locale;

/**
 * Lab 5: metadata for one sensor, copied out of android.hardware.Sensor so it can be
 * formatted and unit-tested without Android. Only DESCRIPTIONS are held here; no live
 * readings are taken (live readings belong to Lab 6).
 *
 * Units and meanings (Android documentation):
 *   maxRange     largest value the sensor reports, in the sensor's own unit
 *   resolution   smallest step between two reported values, same unit
 *   powerMa      current drawn while the sensor is in use, milliamperes (mA)
 *   minDelayUs   shortest gap between events in microseconds (µs);
 *                0 = no fixed rate (on-change, one-shot or special trigger)
 *   maxDelayUs   longest gap the sensor can be asked for, µs; 0 = not reported/unbounded
 *   reportingMode 0 continuous, 1 on-change, 2 one-shot, 3 special trigger, -1 unknown
 */
public final class SensorFacts {

    // Copies of android.hardware.Sensor.TYPE_* so this class has no Android dependency.
    public static final int TYPE_ACCELEROMETER = 1;
    public static final int TYPE_MAGNETIC_FIELD = 2;
    public static final int TYPE_ORIENTATION = 3;
    public static final int TYPE_GYROSCOPE = 4;
    public static final int TYPE_LIGHT = 5;
    public static final int TYPE_PRESSURE = 6;
    public static final int TYPE_PROXIMITY = 8;
    public static final int TYPE_GRAVITY = 9;
    public static final int TYPE_LINEAR_ACCELERATION = 10;
    public static final int TYPE_ROTATION_VECTOR = 11;
    public static final int TYPE_RELATIVE_HUMIDITY = 12;
    public static final int TYPE_AMBIENT_TEMPERATURE = 13;
    public static final int TYPE_MAGNETIC_FIELD_UNCALIBRATED = 14;
    public static final int TYPE_GAME_ROTATION_VECTOR = 15;
    public static final int TYPE_GYROSCOPE_UNCALIBRATED = 16;
    public static final int TYPE_SIGNIFICANT_MOTION = 17;
    public static final int TYPE_STEP_DETECTOR = 18;
    public static final int TYPE_STEP_COUNTER = 19;
    public static final int TYPE_GEOMAGNETIC_ROTATION_VECTOR = 20;
    public static final int TYPE_HEART_RATE = 21;
    public static final int TYPE_STATIONARY_DETECT = 29;
    public static final int TYPE_MOTION_DETECT = 30;
    public static final int TYPE_ACCELEROMETER_UNCALIBRATED = 35;
    public static final int TYPE_HINGE_ANGLE = 36;
    public static final int TYPE_HEADING = 42;

    public final String name;
    public final int type;
    public final String stringType;   // e.g. "android.sensor.accelerometer"; may be null
    public final String vendor;
    public final int version;
    public final float maxRange;
    public final float resolution;
    public final float powerMa;
    public final int minDelayUs;
    public final int maxDelayUs;
    public final int reportingMode;
    public final boolean wakeUp;

    public SensorFacts(String name, int type, String stringType, String vendor, int version,
                       float maxRange, float resolution, float powerMa,
                       int minDelayUs, int maxDelayUs, int reportingMode, boolean wakeUp) {
        this.name = name;
        this.type = type;
        this.stringType = stringType;
        this.vendor = vendor;
        this.version = version;
        this.maxRange = maxRange;
        this.resolution = resolution;
        this.powerMa = powerMa;
        this.minDelayUs = minDelayUs;
        this.maxDelayUs = maxDelayUs;
        this.reportingMode = reportingMode;
        this.wakeUp = wakeUp;
    }

    // ------------------------------------------------------------------ units and labels

    /** Unit of the values this sensor type reports (and so of maxRange and resolution). */
    public static String unitFor(int type) {
        switch (type) {
            case TYPE_ACCELEROMETER:
            case TYPE_GRAVITY:
            case TYPE_LINEAR_ACCELERATION:
            case TYPE_ACCELEROMETER_UNCALIBRATED:
                return "m/s²";
            case TYPE_MAGNETIC_FIELD:
            case TYPE_MAGNETIC_FIELD_UNCALIBRATED:
                return "µT";
            case TYPE_GYROSCOPE:
            case TYPE_GYROSCOPE_UNCALIBRATED:
                return "rad/s";
            case TYPE_LIGHT:
                return "lx";
            case TYPE_PRESSURE:
                return "hPa";
            case TYPE_PROXIMITY:
                return "cm";
            case TYPE_RELATIVE_HUMIDITY:
                return "%";
            case TYPE_AMBIENT_TEMPERATURE:
                return "°C";
            case TYPE_ORIENTATION:
            case TYPE_HINGE_ANGLE:
            case TYPE_HEADING:
                return "°";
            case TYPE_ROTATION_VECTOR:
            case TYPE_GAME_ROTATION_VECTOR:
            case TYPE_GEOMAGNETIC_ROTATION_VECTOR:
                return "unitless";
            case TYPE_STEP_COUNTER:
                return "steps";
            case TYPE_HEART_RATE:
                return "bpm";
            case TYPE_SIGNIFICANT_MOTION:
            case TYPE_STEP_DETECTOR:
            case TYPE_STATIONARY_DETECT:
            case TYPE_MOTION_DETECT:
                return "event";
            default:
                return null;   // unknown: say so instead of guessing
        }
    }

    /** Short human label for the type, e.g. "Accelerometer". */
    public static String typeLabel(int type, String stringType) {
        switch (type) {
            case TYPE_ACCELEROMETER: return "Accelerometer";
            case TYPE_MAGNETIC_FIELD: return "Magnetometer";
            case TYPE_ORIENTATION: return "Orientation (deprecated)";
            case TYPE_GYROSCOPE: return "Gyroscope";
            case TYPE_LIGHT: return "Ambient light";
            case TYPE_PRESSURE: return "Barometer (pressure)";
            case TYPE_PROXIMITY: return "Proximity";
            case TYPE_GRAVITY: return "Gravity";
            case TYPE_LINEAR_ACCELERATION: return "Linear acceleration";
            case TYPE_ROTATION_VECTOR: return "Rotation vector";
            case TYPE_RELATIVE_HUMIDITY: return "Relative humidity";
            case TYPE_AMBIENT_TEMPERATURE: return "Ambient temperature";
            case TYPE_MAGNETIC_FIELD_UNCALIBRATED: return "Magnetometer (uncalibrated)";
            case TYPE_GAME_ROTATION_VECTOR: return "Game rotation vector";
            case TYPE_GYROSCOPE_UNCALIBRATED: return "Gyroscope (uncalibrated)";
            case TYPE_SIGNIFICANT_MOTION: return "Significant motion";
            case TYPE_STEP_DETECTOR: return "Step detector";
            case TYPE_STEP_COUNTER: return "Step counter";
            case TYPE_GEOMAGNETIC_ROTATION_VECTOR: return "Geomagnetic rotation vector";
            case TYPE_HEART_RATE: return "Heart rate";
            case TYPE_STATIONARY_DETECT: return "Stationary detect";
            case TYPE_MOTION_DETECT: return "Motion detect";
            case TYPE_ACCELEROMETER_UNCALIBRATED: return "Accelerometer (uncalibrated)";
            case TYPE_HINGE_ANGLE: return "Hinge angle";
            case TYPE_HEADING: return "Heading";
            default:
                return stringType != null && !stringType.isEmpty()
                        ? "Other (" + stringType + ")" : "Other (type " + type + ")";
        }
    }

    public static String reportingModeLabel(int mode) {
        switch (mode) {
            case 0: return "continuous";
            case 1: return "on-change";
            case 2: return "one-shot";
            case 3: return "special trigger";
            default: return "not reported";
        }
    }

    // ------------------------------------------------------------------ formatted lines

    public String unit() {
        return unitFor(type);
    }

    public String vendorText() {
        return vendor == null || vendor.trim().isEmpty() ? "(not reported)" : vendor;
    }

    public String rangeText() {
        return num(maxRange) + " " + unitOrUnknown();
    }

    public String resolutionText() {
        return num(resolution) + " " + unitOrUnknown();
    }

    /** 0 mA is shown as reported but flagged, because emulators and some drivers report 0. */
    public String powerText() {
        String s = num(powerMa) + " mA";
        return powerMa == 0f ? s + " (reported as 0; real cost unknown)" : s;
    }

    /** Minimum delay with the matching maximum rate, or why there is none. */
    public String minDelayText() {
        if (minDelayUs > 0) {
            double hz = 1_000_000.0 / minDelayUs;
            return minDelayUs + " µs (up to " + num((float) hz) + " Hz)";
        }
        if (minDelayUs == 0) return "0 µs: no fixed rate (" + reportingModeLabel(reportingMode) + ")";
        return minDelayUs + " µs (not a valid delay)";
    }

    public String maxDelayText() {
        return maxDelayUs > 0 ? maxDelayUs + " µs" : "0 (not reported)";
    }

    private String unitOrUnknown() {
        String u = unit();
        return u == null ? "(unit not known for this type)" : u;
    }

    /** Up to 6 significant digits, no trailing zeros, no scientific notation for normal values. */
    static String num(float v) {
        if (v == 0f) return "0";
        double d = v;
        String s = String.format(Locale.US, "%.6g", d);
        if (s.contains("e")) return s;
        if (s.contains(".")) s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s;
    }

    /** All metadata as labelled lines for the inventory row. */
    public String detailText() {
        return "Type: " + type + (stringType == null ? "" : " · " + stringType)
                + "\nVendor: " + vendorText() + " · version " + version
                + "\nRange: " + rangeText()
                + "\nResolution: " + resolutionText()
                + "\nPower: " + powerText()
                + "\nMin delay: " + minDelayText()
                + "\nMax delay: " + maxDelayText()
                + "\nReporting: " + reportingModeLabel(reportingMode) + (wakeUp ? " · wake-up" : " · non-wake-up");
    }
}
