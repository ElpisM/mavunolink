package ke.ac.jkuat.mavunolink;

import java.util.HashMap;
import java.util.Map;

/**
 * Lab 8: sync model, deterministic MOCK server and the client rule that classifies
 * responses. Plain Java so every outcome is unit-tested (SyncTest).
 *
 * Words used in the app:
 *   Saved         the record is committed in the phone's SQLite database (survives relaunch).
 *                 It says nothing about the server.
 *   PENDING       saved, not yet acknowledged by the server.
 *   ACKNOWLEDGED  a well-formed ACCEPTED response for THIS operation id was received.
 *   FAILED        transient: unavailable, timeout or malformed reply. Outcome may be unknown;
 *                 retried later with the SAME operation id.
 *   CONFLICT      the server answered and refused (e.g. a newer version exists). Retrying the
 *                 same operation will not help; a person must review it.
 *
 * Duplicates are prevented by idempotency: every operation carries an opId
 * (clientId + "-v" + version). The server stores the first result for an opId and
 * replays it for any repeat, so a retry after a lost response cannot create a second record.
 */
public final class Sync {

    private Sync() { }

    public enum State { PENDING, ACKNOWLEDGED, FAILED, CONFLICT }

    /** What the MOCK server should do with the next request (deterministic test control). */
    public enum MockMode {
        NORMAL("Normal acknowledgement"),
        UNAVAILABLE("Service unavailable (nothing reaches the server)"),
        LOST_RESPONSE("Lost response (server stores it, client times out)"),
        MALFORMED_ACK("Malformed acknowledgement (no server id)"),
        CONFLICT("Conflict (server refuses)");

        public final String label;
        MockMode(String label) { this.label = label; }
    }

    public static String opId(String clientId, int version) {
        return clientId + "-v" + version;
    }

    // ------------------------------------------------------------------ messages

    public static final class Request {
        public final String opId, clientId;
        public final int version;
        public Request(String opId, String clientId, int version) {
            this.opId = opId;
            this.clientId = clientId;
            this.version = version;
        }
    }

    public static final class Response {
        public final String status;    // "ACCEPTED" or "CONFLICT"
        public final String opId;      // must echo the request
        public final String serverId;  // required for ACCEPTED
        public final String message;
        public final boolean replay;   // true when the server returned a stored result
        public Response(String status, String opId, String serverId, String message, boolean replay) {
            this.status = status;
            this.opId = opId;
            this.serverId = serverId;
            this.message = message;
            this.replay = replay;
        }
    }

    public static final class UnavailableException extends Exception {
        public UnavailableException(String m) { super(m); }
    }

    public static final class TimeoutException extends Exception {
        public TimeoutException(String m) { super(m); }
    }

    // ------------------------------------------------------------------ MOCK server

    /** Where the mock server keeps its own data (SQLite on the phone, a map in tests). */
    public interface ServerStore {
        /** Stored result for an operation, or null. */
        String[] findOp(String opId);                      // {serverId, clientId, version}
        void putOp(String opId, String clientId, String serverId, int version);
        /** Latest {serverId, version} for a client record, or null. */
        String[] findRecord(String clientId);
        void upsertRecord(String clientId, String serverId, int version);
        int recordCount();
        int opCount();
    }

    /**
     * Deterministic MOCK server. Not a real service: it runs inside the app, and the
     * outcome of each request is chosen by MockMode so every path can be reproduced.
     */
    public static final class MockServer {
        private final ServerStore store;

        public MockServer(ServerStore store) { this.store = store; }

        public Response submit(Request r, MockMode mode) throws UnavailableException, TimeoutException {
            if (mode == MockMode.UNAVAILABLE) {
                throw new UnavailableException("HTTP 503 (mock): service unavailable, request not processed");
            }
            // Idempotency: the same operation always gets the same answer and is never stored twice.
            String[] done = store.findOp(r.opId);
            if (done != null) {
                return new Response("ACCEPTED", r.opId, done[0], "already processed; stored result replayed", true);
            }
            if (mode == MockMode.CONFLICT) {
                return new Response("CONFLICT", r.opId, null, "rejected (mock): record locked by supervisor review", false);
            }
            String[] existing = store.findRecord(r.clientId);
            if (existing != null && Integer.parseInt(existing[1]) > r.version) {
                return new Response("CONFLICT", r.opId, existing[0],
                        "server has version " + existing[1] + "; this is version " + r.version, false);
            }
            String serverId = existing != null ? existing[0] : "SRV-" + (store.recordCount() + 1001);
            store.upsertRecord(r.clientId, serverId, r.version);   // a correction updates, never adds
            store.putOp(r.opId, r.clientId, serverId, r.version);

            if (mode == MockMode.LOST_RESPONSE) {
                throw new TimeoutException("no response within 10 s (mock): server DID store it, client cannot know");
            }
            if (mode == MockMode.MALFORMED_ACK) {
                return new Response("ACCEPTED", r.opId, null, "malformed: serverId missing", false);
            }
            return new Response("ACCEPTED", r.opId, serverId, "stored", false);
        }

        public int recordCount() { return store.recordCount(); }
        public int opCount() { return store.opCount(); }
    }

    // ------------------------------------------------------------------ client rule

    /** Result of one attempt as the client sees it. */
    public static final class Outcome {
        public final State state;
        public final String serverId;   // only for ACKNOWLEDGED
        public final String note;
        Outcome(State s, String serverId, String note) {
            this.state = s;
            this.serverId = serverId;
            this.note = note;
        }
    }

    /**
     * Calls the server once and classifies the result. Only a well-formed ACCEPTED reply
     * that echoes the expected opId and carries a serverId counts as acknowledged.
     */
    public static Outcome attempt(MockServer server, Request r, MockMode mode) {
        try {
            Response resp = server.submit(r, mode);
            return classify(resp, r.opId);
        } catch (UnavailableException e) {
            return new Outcome(State.FAILED, null, "unavailable: " + e.getMessage() + " (retry later, same op id)");
        } catch (TimeoutException e) {
            return new Outcome(State.FAILED, null,
                    "timeout: outcome unknown, NOT a rejection (retry with same op id " + r.opId + ")");
        }
    }

    public static Outcome classify(Response resp, String expectedOpId) {
        if (resp == null) return new Outcome(State.FAILED, null, "empty response (not success)");
        if ("CONFLICT".equals(resp.status)) {
            return new Outcome(State.CONFLICT, null, "conflict: " + resp.message + " (needs review; not retried)");
        }
        boolean wellFormed = "ACCEPTED".equals(resp.status)
                && expectedOpId.equals(resp.opId)
                && resp.serverId != null && !resp.serverId.trim().isEmpty();
        if (!wellFormed) {
            return new Outcome(State.FAILED, null, "malformed acknowledgement: " + resp.message
                    + " (not shown as success; retry with same op id)");
        }
        return new Outcome(State.ACKNOWLEDGED, resp.serverId,
                resp.replay ? "acknowledged (" + resp.message + ")" : "acknowledged");
    }

    /** States that the Sync button will send. CONFLICT and ACKNOWLEDGED are not resent. */
    public static boolean shouldSend(State s) {
        return s == State.PENDING || s == State.FAILED;
    }

    // ------------------------------------------------------------------ in-memory store (tests)

    public static final class MemoryStore implements ServerStore {
        private final Map<String, String[]> ops = new HashMap<>();
        private final Map<String, String[]> recs = new HashMap<>();
        @Override public String[] findOp(String opId) { return ops.get(opId); }
        @Override public void putOp(String opId, String clientId, String serverId, int version) {
            ops.put(opId, new String[]{serverId, clientId, String.valueOf(version)});
        }
        @Override public String[] findRecord(String clientId) { return recs.get(clientId); }
        @Override public void upsertRecord(String clientId, String serverId, int version) {
            recs.put(clientId, new String[]{serverId, String.valueOf(version)});
        }
        @Override public int recordCount() { return recs.size(); }
        @Override public int opCount() { return ops.size(); }
    }
}
