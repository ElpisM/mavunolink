package ke.ac.jkuat.mavunolink;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Adapter: binds each committed FarmerRecord to an item_record.xml row.
 * After the list changes, notifyDataSetChanged() makes the ListView ask again.
 */
public class RecordAdapter extends ArrayAdapter<FarmerRecord> {

    private final LayoutInflater inflater;

    public RecordAdapter(Context context, List<FarmerRecord> records) {
        super(context, 0, records);
        this.inflater = LayoutInflater.from(context);
    }

    private static final class Holder {
        final TextView title;
        final TextView detail;

        Holder(View row) {
            title = row.findViewById(R.id.tvItemTitle);
            detail = row.findViewById(R.id.tvItemDetail);
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        Holder h;
        if (row == null) {
            row = inflater.inflate(R.layout.item_record, parent, false);
            h = new Holder(row);
            row.setTag(h);
        } else {
            h = (Holder) row.getTag();
        }

        FarmerRecord r = getItem(position);
        if (r != null) {
            h.title.setText((position + 1) + ". " + r.getFarmerRef() + " — " + r.getCrop());
            String detail = (r.getDate() == null ? "" : r.getDate() + " · ")
                    + r.formattedQuantity() + " · " + r.getType().getLabel()
                    + (r.getPointId() == null ? "" : "\n" + r.pointLabel()
                        + (r.isPaperReceipt() ? " · receipt" : ""))
                    + (r.hasNotes() ? "\n" + r.getNotes() : "");
            h.detail.setText(detail);
        }
        return row;
    }
}
