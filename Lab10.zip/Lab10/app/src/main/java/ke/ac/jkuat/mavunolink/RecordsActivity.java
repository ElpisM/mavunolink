package ke.ac.jkuat.mavunolink;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Lab 3 "View records" screen, extended in Lab 8:
 *  - lists records from SQLite (not from an Intent copy), with sync state per row;
 *  - tap a row to reopen and correct it (quantity, notes) -> version + 1, PENDING;
 *  - "Sync now" sends every PENDING or FAILED record to the MOCK server, reusing the
 *    operation id (clientId-vVersion) so a retry can never create a duplicate;
 *  - the MOCK response for the run is chosen in a Spinner (deterministic, labelled).
 *
 * Back or Up still just finishes this screen.
 */
public class RecordsActivity extends AppCompatActivity {

    static final String TAG_SYNC = "MavunoSync";
    private static final String KEY_MODE = "mock_mode";

    private RecordRepository repo;
    private Sync.MockServer server;
    private final List<StoredRecord> rows = new ArrayList<>();
    private StoredAdapter adapter;
    private View header;
    private Spinner spMode;
    private boolean syncing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_records);
        ActionBar bar = getSupportActionBar();
        if (bar != null) bar.setDisplayHomeAsUpEnabled(true);

        repo = RecordRepository.get(this);
        server = new Sync.MockServer(repo.mockStore());

        ListView list = findViewById(R.id.lvAllRecords);
        header = LayoutInflater.from(this).inflate(R.layout.header_records, list, false);
        list.addHeaderView(header, null, false);
        adapter = new StoredAdapter(this, rows);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            int i = position - list.getHeaderViewsCount();
            if (i >= 0 && i < rows.size()) showCorrectDialog(rows.get(i), i + 1);
        });

        spMode = header.findViewById(R.id.spMockMode);
        List<String> labels = new ArrayList<>();
        for (Sync.MockMode m : Sync.MockMode.values()) labels.add(m.label);
        ArrayAdapter<String> modeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        modeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMode.setAdapter(modeAdapter);
        if (savedInstanceState != null) spMode.setSelection(savedInstanceState.getInt(KEY_MODE, 0));

        header.findViewById(R.id.btnSync).setOnClickListener(v -> syncNow());

        MainActivity.appendTrace(TAG_SYNC, "RecordsActivity onCreate -> loading from SQLite");
        reload(null);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_MODE, spMode.getSelectedItemPosition());
    }

    // ---------------------------------------------------------------- load

    private void reload(String resultMessage) {
        repo.run(() -> {
            List<StoredRecord> all = repo.all();
            int[] serverCounts = {server.recordCount(), server.opCount()};
            return new Object[]{all, serverCounts};
        }, new RecordRepository.Callback<Object[]>() {
            @Override
            @SuppressWarnings("unchecked")
            public void onSuccess(Object[] v) {
                rows.clear();
                rows.addAll((List<StoredRecord>) v[0]);
                adapter.notifyDataSetChanged();
                int[] sc = (int[]) v[1];
                renderHeader(sc[0], sc[1]);
                if (resultMessage != null) showResult(resultMessage);
            }

            @Override
            public void onError(Exception e) {
                showResult("Could not load records: " + e.getMessage());
            }
        });
    }

    private void renderHeader(int serverRecords, int serverOps) {
        int pending = 0, ack = 0, failed = 0, conflict = 0;
        for (StoredRecord r : rows) {
            switch (r.state) {
                case PENDING: pending++; break;
                case ACKNOWLEDGED: ack++; break;
                case FAILED: failed++; break;
                case CONFLICT: conflict++; break;
            }
        }
        ((TextView) header.findViewById(R.id.tvRecordsHeader)).setText(getString(R.string.records_header, rows.size()));
        ((TextView) header.findViewById(R.id.tvStateCounts)).setText(
                "Pending " + pending + " · Acknowledged " + ack + " · Failed " + failed + " · Conflict " + conflict);
        ((TextView) header.findViewById(R.id.tvServerInfo)).setText(
                "MOCK server holds " + serverRecords + " record(s) from " + serverOps + " operation(s).");
        header.findViewById(R.id.tvRecordsEmpty).setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void showResult(String msg) {
        TextView tv = header.findViewById(R.id.tvSyncResult);
        tv.setText(msg);
        tv.setBackgroundColor(0xFFF1F3F4);
        tv.setVisibility(View.VISIBLE);
    }

    // ---------------------------------------------------------------- sync

    private void syncNow() {
        if (syncing) return;
        syncing = true;
        header.findViewById(R.id.btnSync).setEnabled(false);
        Sync.MockMode mode = Sync.MockMode.values()[spMode.getSelectedItemPosition()];
        MainActivity.appendTrace(TAG_SYNC, "SYNC start, MOCK mode=" + mode.name());

        repo.run(() -> {
            StringBuilder report = new StringBuilder("MOCK mode: " + mode.label);
            int sent = 0;
            for (StoredRecord r : repo.all()) {
                if (!Sync.shouldSend(r.state)) continue;
                sent++;
                Sync.Request req = new Sync.Request(r.opId(), r.clientId, r.version);
                Sync.Outcome o = Sync.attempt(server, req, mode);
                repo.setSync(r.localId, o);
                String line = "#" + r.localId + " op " + r.shortClient() + "…-v" + r.version
                        + " (attempt " + (r.attempts + 1) + ") -> " + o.state + ": " + o.note;
                report.append('\n').append(line);
                MainActivity.appendTrace(TAG_SYNC, line);
            }
            if (sent == 0) report.append("\nNothing to send: no PENDING or FAILED records.");
            return report.toString();
        }, new RecordRepository.Callback<String>() {
            @Override
            public void onSuccess(String report) {
                syncing = false;
                header.findViewById(R.id.btnSync).setEnabled(true);
                reload(report);
            }

            @Override
            public void onError(Exception e) {
                syncing = false;
                header.findViewById(R.id.btnSync).setEnabled(true);
                reload("Sync stopped by a local error (states saved so far are kept): " + e.getMessage());
            }
        });
    }

    // ---------------------------------------------------------------- reopen and correct

    private void showCorrectDialog(StoredRecord r, int number) {
        View form = LayoutInflater.from(this).inflate(R.layout.dialog_correct, null);
        EditText etQty = form.findViewById(R.id.etCorrectQty);
        EditText etNotes = form.findViewById(R.id.etCorrectNotes);
        double q = r.record.getQuantityKg();
        etQty.setText(q == Math.rint(q) ? String.valueOf((long) q) : String.valueOf(q));
        etNotes.setText(r.record.hasNotes() ? r.record.getNotes() : "");

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle(getString(R.string.correct_title, number))
                .setMessage(r.record.getFarmerRef() + " · " + r.record.getDate() + " · " + r.record.getCrop()
                        + "\nSync: " + r.state + " (version " + r.version + ")")
                .setView(form)
                .setPositiveButton(R.string.correct_save, null)   // set below so invalid input keeps the dialog open
                .setNegativeButton(R.string.cancel, null)
                .create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            double[] kg = new double[1];
            String err = RecordValidator.checkQuantity(etQty.getText().toString().trim(), r.record.getType(), kg);
            String notes = etNotes.getText().toString().trim();
            if (err != null) {
                etQty.setError(err);          // dialog stays open, typed values kept
                return;
            }
            dlg.dismiss();
            repo.run(() -> repo.correct(r.localId, kg[0], notes.isEmpty() ? null : notes),
                    new RecordRepository.Callback<StoredRecord>() {
                        @Override
                        public void onSuccess(StoredRecord updated) {
                            MainActivity.appendTrace(TAG_SYNC, "CORRECTED #" + updated.localId + " -> version "
                                    + updated.version + ", PENDING, new op " + updated.shortClient() + "…-v" + updated.version);
                            Toast.makeText(RecordsActivity.this,
                                    getString(R.string.correct_saved, updated.version), Toast.LENGTH_LONG).show();
                            reload(null);
                        }

                        @Override
                        public void onError(Exception e) {
                            new AlertDialog.Builder(RecordsActivity.this)
                                    .setTitle(R.string.save_failed_title)
                                    .setMessage(getString(R.string.save_failed_message, e.getMessage()))
                                    .setPositiveButton(R.string.ok, null)
                                    .show();
                        }
                    });
        });
    }

    // ---------------------------------------------------------------- menu and navigation

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.records_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_reset_mock) {
            repo.run(() -> {
                repo.resetMockServer();
                return true;
            }, new RecordRepository.Callback<Boolean>() {
                @Override public void onSuccess(Boolean v) {
                    MainActivity.appendTrace(TAG_SYNC, "MOCK server reset (local records unchanged)");
                    reload("MOCK server emptied. Local records and their states are unchanged.");
                }
                @Override public void onError(Exception e) { showResult("Reset failed: " + e.getMessage()); }
            });
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        MainActivity.appendTrace(MainActivity.TAG_NAV, "UP pressed -> finish RecordsActivity");
        finish();
        return true;
    }

    // ---------------------------------------------------------------- adapter

    static final class StoredAdapter extends ArrayAdapter<StoredRecord> {
        private final LayoutInflater inflater;

        StoredAdapter(Context c, List<StoredRecord> items) {
            super(c, 0, items);
            inflater = LayoutInflater.from(c);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View row = convertView != null ? convertView
                    : inflater.inflate(R.layout.item_stored_record, parent, false);
            StoredRecord s = getItem(position);
            if (s != null) {
                FarmerRecord r = s.record;
                ((TextView) row.findViewById(R.id.tvStoredTitle)).setText(
                        "#" + s.localId + "  " + r.getFarmerRef() + " — " + r.getCrop());
                ((TextView) row.findViewById(R.id.tvStoredDetail)).setText(
                        r.getDate() + " · " + r.formattedQuantity() + " · " + r.getType().getLabel()
                                + (r.getPointId() == null ? "" : " · " + r.getPointId())
                                + (r.hasNotes() ? "\n" + r.getNotes() : ""));
                TextView sync = row.findViewById(R.id.tvStoredSync);
                sync.setText(s.state + (s.serverId != null ? "  " + s.serverId : "")
                        + "  ·  v" + s.version + "  ·  attempts " + s.attempts);
                int[] colors = colorsFor(s.state);
                sync.setBackgroundColor(colors[0]);
                sync.setTextColor(colors[1]);
                ((TextView) row.findViewById(R.id.tvStoredNote)).setText(
                        "client " + s.shortClient() + "…" + (s.lastNote == null ? "" : " · " + s.lastNote));
            }
            return row;
        }

        private static int[] colorsFor(Sync.State st) {
            switch (st) {
                case ACKNOWLEDGED: return new int[]{0xFFE3F4EE, 0xFF0F4D3C};   // jungle green
                case FAILED: return new int[]{0xFFFFF4E5, 0xFF8A4B00};
                case CONFLICT: return new int[]{0xFFFDECEA, 0xFFB71C1C};
                case PENDING:
                default: return new int[]{0xFFEEEEEE, 0xFF424242};   // pending: neutral, not yet green
            }
        }
    }
}
