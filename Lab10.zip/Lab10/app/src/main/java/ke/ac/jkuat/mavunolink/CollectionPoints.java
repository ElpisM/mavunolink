package ke.ac.jkuat.mavunolink;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Lab 4 source collection for the collection-point Spinner (synthetic data).
 *
 * In a real MavunoLink build this list would come from the server and could change
 * between sessions. The Variant switch (overflow menu "Collection point list") lets the
 * tests reproduce those changes on the emulator:
 *   STANDARD      5 points, CP-01 ... CP-05
 *   REORDERED     same 5 points, different order (positions change, IDs do not)
 *   CP03_CLOSED   CP-03 removed (a previously selected option disappears)
 *   EMPTY         no points (empty option-list state)
 */
public final class CollectionPoints {

    public enum Variant { STANDARD, REORDERED, CP03_CLOSED, EMPTY }

    private static final CollectionPoint CP01 = new CollectionPoint("CP-01", "Gatundu Market", "Gatundu North · Mon, Thu");
    private static final CollectionPoint CP02 = new CollectionPoint("CP-02", "Juja Farm Gate", "Juja · Tue, Fri");
    private static final CollectionPoint CP03 = new CollectionPoint("CP-03", "Thika Road Depot", "Thika · daily");
    private static final CollectionPoint CP04 = new CollectionPoint("CP-04", "Ruiru Cooperative Store", "Ruiru · Wed, Sat");
    private static final CollectionPoint CP05 = new CollectionPoint("CP-05", "Kiambu Town Centre", "Kiambu · Mon, Fri");

    private CollectionPoints() { }

    /** Real choices only (no prompt). */
    public static List<CollectionPoint> load(Variant v) {
        switch (v) {
            case REORDERED:
                return Collections.unmodifiableList(Arrays.asList(CP05, CP03, CP01, CP04, CP02));
            case CP03_CLOSED:
                return Collections.unmodifiableList(Arrays.asList(CP01, CP02, CP04, CP05));
            case EMPTY:
                return Collections.emptyList();
            case STANDARD:
            default:
                return Collections.unmodifiableList(Arrays.asList(CP01, CP02, CP03, CP04, CP05));
        }
    }

    /** Builds the Spinner rows: the prompt first, then the real choices. */
    public static List<CollectionPoint> withPrompt(List<CollectionPoint> points, String promptLabel) {
        List<CollectionPoint> rows = new ArrayList<>(points.size() + 1);
        rows.add(CollectionPoint.prompt(promptLabel));
        rows.addAll(points);
        return rows;
    }

    /** Position of the row with this stable id, or -1 if it is not in the list. */
    public static int indexOfId(List<CollectionPoint> rows, String id) {
        if (id == null) return -1;
        for (int i = 0; i < rows.size(); i++) {
            if (id.equals(rows.get(i).getId())) return i;
        }
        return -1;
    }

    /** Stable ids of the real choices, for the validator. */
    public static List<String> ids(List<CollectionPoint> points) {
        List<String> out = new ArrayList<>(points.size());
        for (CollectionPoint p : points) {
            if (!p.isPrompt()) out.add(p.getId());
        }
        return out;
    }

    public static CollectionPoint findById(List<CollectionPoint> rows, String id) {
        int i = indexOfId(rows, id);
        return i < 0 ? null : rows.get(i);
    }
}
