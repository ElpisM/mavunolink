package ke.ac.jkuat.mavunolink;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Lab 8: local structured storage (SQLite) for committed records, plus the MOCK
 * server's own tables.
 *
 * Why SQLite and not SharedPreferences or a file: records are many rows with typed
 * fields that must be listed, updated one at a time and queried by sync state.
 * Preferences are a small key-value store for settings; a file would need hand-written
 * parsing, partial-write handling and locking. SQLite gives typed columns, CHECK
 * constraints, a UNIQUE client id and atomic transactions. (Room would add compile-time
 * checked queries on top of the same SQLite; plain SQLiteOpenHelper keeps the SQL visible.)
 *
 * Transaction boundary for Save: beginTransaction -> INSERT -> setTransactionSuccessful
 * -> endTransaction. Only after endTransaction returns without an exception is the
 * record durable, and only then does the UI say "Saved". Any exception rolls the whole
 * INSERT back, and the UI shows the error and keeps the draft.
 *
 * All database work runs on one background thread (EXECUTOR); results are posted
 * back to the main thread.
 */
public final class RecordRepository {

    public interface Callback<T> {
        void onSuccess(T value);
        void onError(Exception e);
    }

    /** Test option (menu): make the next save throw inside the transaction. */
    public static volatile boolean simulateWriteFailure;

    private static RecordRepository instance;
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private final Helper helper;

    public static synchronized RecordRepository get(Context c) {
        if (instance == null) instance = new RecordRepository(c.getApplicationContext());
        return instance;
    }

    private RecordRepository(Context c) {
        helper = new Helper(c);
    }

    /** Runs work on the database thread and reports back on the main thread. */
    public <T> void run(Callable<T> work, Callback<T> cb) {
        EXECUTOR.execute(() -> {
            try {
                T v = work.call();
                MAIN.post(() -> cb.onSuccess(v));
            } catch (Exception e) {
                MAIN.post(() -> cb.onError(e));
            }
        });
    }

    // ------------------------------------------------------------------ schema

    static final String DB_NAME = "mavunolink.db";
    static final int DB_VERSION = 1;

    private static final class Helper extends SQLiteOpenHelper {
        Helper(Context c) { super(c, DB_NAME, null, DB_VERSION); }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE records ("
                    + " id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + " client_id TEXT NOT NULL UNIQUE,"
                    + " version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),"
                    + " farmer_ref TEXT NOT NULL CHECK (length(trim(farmer_ref)) BETWEEN 1 AND 40),"
                    + " txn_date TEXT NOT NULL CHECK (txn_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),"
                    + " crop TEXT NOT NULL CHECK (length(trim(crop)) BETWEEN 1 AND 30),"
                    + " quantity_kg REAL NOT NULL CHECK (quantity_kg >= 0 AND quantity_kg <= 100000),"
                    + " txn_type TEXT NOT NULL CHECK (txn_type IN ('DELIVERY','WEEKLY_HARVEST')),"
                    + " point_id TEXT,"
                    + " point_name TEXT,"
                    + " notes TEXT CHECK (notes IS NULL OR length(notes) <= 120),"
                    + " paper_receipt INTEGER NOT NULL DEFAULT 0 CHECK (paper_receipt IN (0,1)),"
                    + " sync_state TEXT NOT NULL DEFAULT 'PENDING'"
                    + "   CHECK (sync_state IN ('PENDING','ACKNOWLEDGED','FAILED','CONFLICT')),"
                    + " server_id TEXT,"
                    + " attempts INTEGER NOT NULL DEFAULT 0,"
                    + " last_note TEXT,"
                    + " created_at INTEGER NOT NULL,"
                    + " updated_at INTEGER NOT NULL)");
            // MOCK server tables: kept apart (mock_ prefix) so real and mock data never mix.
            db.execSQL("CREATE TABLE mock_server_ops ("
                    + " op_id TEXT PRIMARY KEY, client_id TEXT NOT NULL, server_id TEXT NOT NULL,"
                    + " version INTEGER NOT NULL, received_at INTEGER NOT NULL)");
            db.execSQL("CREATE TABLE mock_server_records ("
                    + " client_id TEXT PRIMARY KEY, server_id TEXT NOT NULL, version INTEGER NOT NULL)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
            // Version 1 only. A later version would migrate with ALTER TABLE, never drop user data.
        }
    }

    // ------------------------------------------------------------------ records (call on EXECUTOR)

    /** Inserts one record in a transaction. Returns the stored row, or throws (nothing saved). */
    public StoredRecord insert(FarmerRecord r) {
        SQLiteDatabase db = helper.getWritableDatabase();
        long now = System.currentTimeMillis();
        String clientId = UUID.randomUUID().toString();
        ContentValues v = new ContentValues();
        v.put("client_id", clientId);
        v.put("version", 1);
        v.put("farmer_ref", r.getFarmerRef());
        v.put("txn_date", r.getDate());
        v.put("crop", r.getCrop());
        v.put("quantity_kg", r.getQuantityKg());
        v.put("txn_type", r.getType().name());
        v.put("point_id", r.getPointId());
        v.put("point_name", r.getPointName());
        v.put("notes", r.getNotes());
        v.put("paper_receipt", r.isPaperReceipt() ? 1 : 0);
        v.put("sync_state", Sync.State.PENDING.name());
        v.put("created_at", now);
        v.put("updated_at", now);

        long id;
        db.beginTransaction();
        try {
            id = db.insertOrThrow("records", null, v);
            if (simulateWriteFailure) {
                throw new SQLiteException("simulated write failure (test option): transaction rolled back");
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();   // commits only if setTransactionSuccessful() was reached
        }
        return byId(db, id);
    }

    /** Correction: new quantity/notes, version + 1, back to PENDING (a new operation). */
    public StoredRecord correct(long id, double quantityKg, String notes) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.execSQL("UPDATE records SET quantity_kg = ?, notes = ?, version = version + 1,"
                            + " sync_state = 'PENDING', attempts = 0, last_note = 'corrected; new operation',"
                            + " updated_at = ? WHERE id = ?",
                    new Object[]{quantityKg, notes, System.currentTimeMillis(), id});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return byId(db, id);
    }

    public void setSync(long id, Sync.Outcome o) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.execSQL("UPDATE records SET sync_state = ?, server_id = COALESCE(?, server_id),"
                            + " attempts = attempts + 1, last_note = ?, updated_at = ? WHERE id = ?",
                    new Object[]{o.state.name(), o.serverId, o.note, System.currentTimeMillis(), id});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public List<StoredRecord> all() {
        SQLiteDatabase db = helper.getReadableDatabase();
        List<StoredRecord> out = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT * FROM records ORDER BY id", null)) {
            while (c.moveToNext()) out.add(read(c));
        }
        return out;
    }

    private StoredRecord byId(SQLiteDatabase db, long id) {
        try (Cursor c = db.rawQuery("SELECT * FROM records WHERE id = ?", new String[]{String.valueOf(id)})) {
            if (!c.moveToNext()) throw new SQLiteException("row " + id + " not found after write");
            return read(c);
        }
    }

    private static StoredRecord read(Cursor c) {
        FarmerRecord r = new FarmerRecord(
                str(c, "farmer_ref"), str(c, "crop"),
                c.getDouble(c.getColumnIndexOrThrow("quantity_kg")),
                TransactionType.valueOf(str(c, "txn_type")),
                str(c, "txn_date"), str(c, "notes"),
                str(c, "point_id"), str(c, "point_name"),
                c.getInt(c.getColumnIndexOrThrow("paper_receipt")) == 1);
        return new StoredRecord(
                c.getLong(c.getColumnIndexOrThrow("id")),
                str(c, "client_id"),
                c.getInt(c.getColumnIndexOrThrow("version")),
                Sync.State.valueOf(str(c, "sync_state")),
                str(c, "server_id"),
                c.getInt(c.getColumnIndexOrThrow("attempts")),
                str(c, "last_note"),
                c.getLong(c.getColumnIndexOrThrow("created_at")),
                c.getLong(c.getColumnIndexOrThrow("updated_at")),
                r);
    }

    private static String str(Cursor c, String col) {
        int i = c.getColumnIndexOrThrow(col);
        return c.isNull(i) ? null : c.getString(i);
    }

    // ------------------------------------------------------------------ MOCK server store

    /** SQLite-backed store for Sync.MockServer, so the mock remembers operations across relaunch. */
    public Sync.ServerStore mockStore() {
        return new Sync.ServerStore() {
            @Override public String[] findOp(String opId) {
                try (Cursor c = helper.getReadableDatabase().rawQuery(
                        "SELECT server_id, client_id, version FROM mock_server_ops WHERE op_id = ?", new String[]{opId})) {
                    return c.moveToNext() ? new String[]{c.getString(0), c.getString(1), c.getString(2)} : null;
                }
            }
            @Override public void putOp(String opId, String clientId, String serverId, int version) {
                ContentValues v = new ContentValues();
                v.put("op_id", opId);
                v.put("client_id", clientId);
                v.put("server_id", serverId);
                v.put("version", version);
                v.put("received_at", System.currentTimeMillis());
                helper.getWritableDatabase().insertOrThrow("mock_server_ops", null, v);
            }
            @Override public String[] findRecord(String clientId) {
                try (Cursor c = helper.getReadableDatabase().rawQuery(
                        "SELECT server_id, version FROM mock_server_records WHERE client_id = ?", new String[]{clientId})) {
                    return c.moveToNext() ? new String[]{c.getString(0), c.getString(1)} : null;
                }
            }
            @Override public void upsertRecord(String clientId, String serverId, int version) {
                helper.getWritableDatabase().execSQL(
                        "INSERT OR REPLACE INTO mock_server_records (client_id, server_id, version) VALUES (?, ?, ?)",
                        new Object[]{clientId, serverId, version});
            }
            @Override public int recordCount() { return count("mock_server_records"); }
            @Override public int opCount() { return count("mock_server_ops"); }
        };
    }

    public void resetMockServer() {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.execSQL("DELETE FROM mock_server_ops");
        db.execSQL("DELETE FROM mock_server_records");
    }

    private int count(String table) {
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + table, null)) {
            return c.moveToNext() ? c.getInt(0) : 0;
        }
    }
}
