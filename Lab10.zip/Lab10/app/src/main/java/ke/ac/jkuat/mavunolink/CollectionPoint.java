package ke.ac.jkuat.mavunolink;

import java.io.Serializable;

/**
 * Lab 4 domain item behind the Spinner: a MavunoLink collection point.
 *
 * id    stable code (e.g. "CP-03"). This is what is validated, saved and stored in a
 *       record. It never changes when the list is reordered or relabelled.
 * name  label shown to the officer. Display only; may be reworded at any time.
 * area  secondary text for the drop-down row.
 *
 * The prompt row is a CollectionPoint whose id is null, so "is this a real choice?"
 * is answered by the id, not by the row position.
 */
public final class CollectionPoint implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String id;
    private final String name;
    private final String area;

    public CollectionPoint(String id, String name, String area) {
        this.id = id;
        this.name = name;
        this.area = area;
    }

    public static CollectionPoint prompt(String label) {
        return new CollectionPoint(null, label, null);
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getArea() { return area; }
    public boolean isPrompt() { return id == null; }

    /** Used by ArrayAdapter's default binding and by the Spinner's accessibility text. */
    @Override
    public String toString() {
        return name;
    }
}
