package ke.ac.jkuat.mavunolink;

import java.util.ArrayDeque;
import java.util.Locale;

/**
 * Lab 6: plain-Java helpers for the live sensor screen (unit-tested without Android).
 *
 * Smoother        exponential moving average:  s(n) = s(n-1) + ALPHA * (x(n) - s(n-1)),
 *                 with s(1) = x(1). ALPHA = 0.2, so each new reading moves the smoothed
 *                 value 20% of the way towards it. Small spikes are damped; a real step
 *                 change is followed within about 10 events (0.8^10 ≈ 0.11 of the gap left).
 *
 * IntervalStats   time between consecutive SensorEvent.timestamp values (nanoseconds since
 *                 boot) over the last WINDOW events, converted to ms and Hz. This is the
 *                 OBSERVED rate, which is compared with the REQUESTED sampling delay.
 *
 * Observation     one row of the timestamped observation table.
 */
public final class LiveStats {

    private LiveStats() { }

    // ------------------------------------------------------------------ smoothing

    public static final class Smoother {
        public static final double ALPHA = 0.2;
        private double value;
        private boolean started;

        public double add(double x) {
            if (!started) {
                value = x;
                started = true;
            } else {
                value = value + ALPHA * (x - value);
            }
            return value;
        }

        public boolean hasValue() { return started; }
        public double value() { return value; }

        public void reset() {
            started = false;
            value = 0;
        }
    }

    // ------------------------------------------------------------------ event timing

    public static final class IntervalStats {
        public static final int WINDOW = 50;
        private final ArrayDeque<Long> intervalsNs = new ArrayDeque<>();
        private long lastTimestampNs = -1;
        private long events;

        /** Feed SensorEvent.timestamp (ns). */
        public void add(long timestampNs) {
            events++;
            if (lastTimestampNs >= 0 && timestampNs > lastTimestampNs) {
                intervalsNs.addLast(timestampNs - lastTimestampNs);
                if (intervalsNs.size() > WINDOW) intervalsNs.removeFirst();
            }
            lastTimestampNs = timestampNs;
        }

        public long events() { return events; }
        public int samples() { return intervalsNs.size(); }

        public double meanMs() {
            if (intervalsNs.isEmpty()) return Double.NaN;
            long sum = 0;
            for (long v : intervalsNs) sum += v;
            return sum / (double) intervalsNs.size() / 1_000_000.0;
        }

        public double minMs() {
            long m = Long.MAX_VALUE;
            for (long v : intervalsNs) m = Math.min(m, v);
            return intervalsNs.isEmpty() ? Double.NaN : m / 1_000_000.0;
        }

        public double maxMs() {
            long m = 0;
            for (long v : intervalsNs) m = Math.max(m, v);
            return intervalsNs.isEmpty() ? Double.NaN : m / 1_000_000.0;
        }

        public double meanHz() {
            double ms = meanMs();
            return Double.isNaN(ms) || ms <= 0 ? Double.NaN : 1000.0 / ms;
        }

        public void reset() {
            intervalsNs.clear();
            lastTimestampNs = -1;
            events = 0;
        }

        /** "observed mean 66.7 ms (15.0 Hz), min 60.1, max 80.2 ms over 50 intervals". */
        public String describe() {
            if (intervalsNs.isEmpty()) {
                return events == 0 ? "no events yet" : "1 event so far (need 2 for an interval)";
            }
            return String.format(Locale.US, "observed mean %.1f ms (%.1f Hz), min %.1f, max %.1f ms over %d intervals",
                    meanMs(), meanHz(), minMs(), maxMs(), intervalsNs.size());
        }
    }

    /** Requested delay in µs as text with its nominal rate. */
    public static String requestedText(int delayUs) {
        return String.format(Locale.US, "requested %d µs (nominal %.1f Hz)", delayUs, 1_000_000.0 / delayUs);
    }

    // ------------------------------------------------------------------ observation table

    public static final class Observation implements java.io.Serializable {
        private static final long serialVersionUID = 1L;
        public final String time;       // HH:mm:ss on the device clock
        public final String condition;  // what the experimenter did, e.g. "covered"
        public final double raw;
        public final double smoothed;
        public final String unit;
        public final long eventCount;

        public Observation(String time, String condition, double raw, double smoothed,
                           String unit, long eventCount) {
            this.time = time;
            this.condition = condition;
            this.raw = raw;
            this.smoothed = smoothed;
            this.unit = unit;
            this.eventCount = eventCount;
        }

        public String row() {
            return String.format(Locale.US, "%-8s  %-16s %10s  %10s  %6d",
                    time, clip(condition, 16), fmt(raw), fmt(smoothed), eventCount);
        }

        public String csv() {
            return time + "," + condition.replace(",", ";") + "," + fmt(raw) + "," + fmt(smoothed)
                    + "," + unit + "," + eventCount;
        }

        public static String header(String unit) {
            return String.format(Locale.US, "%-8s  %-16s %10s  %10s  %6s",
                    "time", "condition", "raw " + unit, "smooth", "events");
        }

        public static String csvHeader() {
            return "time,condition,raw,smoothed,unit,events";
        }
    }

    /** Value with sensible precision: 2 decimals below 100, 1 decimal above. */
    public static String fmt(double v) {
        if (Double.isNaN(v)) return "-";
        return Math.abs(v) >= 100 ? String.format(Locale.US, "%.1f", v) : String.format(Locale.US, "%.2f", v);
    }

    static String clip(String s, int n) {
        return s.length() <= n ? s : s.substring(0, n - 1) + "…";
    }

    /** Accelerometer magnitude, m/s². About 9.81 when the phone is still, in any orientation. */
    public static double magnitude(float x, float y, float z) {
        return Math.sqrt((double) x * x + (double) y * y + (double) z * z);
    }
}
