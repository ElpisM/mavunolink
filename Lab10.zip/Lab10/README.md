# MavunoLink PWA (Lab_10_hm10)

Bounded shared-code version of the MavunoLink **capture → review → save** feature (Android
Labs 1–8, iOS Lab 9) as a Progressive Web App: plain HTML/CSS/JavaScript, no framework,
no third-party code, no build-time dependencies. Synthetic data only.

## Requirements
Node 18+ (unit tests, build), Python 3 + Playwright and Chrome (end-to-end tests), git, zip.

## Build → test → package
```bash
./build.sh                 # unit tests -> dist/ -> secret scan -> release/mavunolink-pwa-<ver>-<commit>.zip + .sha256
python3 e2e/run_e2e.py     # 18 end-to-end checks in headless Chrome; writes e2e/results.json, e2e/shots/
```
Serve `dist/` from any static host over HTTPS (or `python3 -m http.server -d dist 8123` and open
http://127.0.0.1:8123 locally; localhost is a secure context, so the service worker runs).

## Traceability
The app footer shows `version (commit)`. The package name, the service-worker cache name and
`dist/src/version.js` carry the same commit; a `-dirty` suffix means uncommitted changes.

## Release checklist
1. Working tree clean; version bumped in package.json; commit tagged `vX.Y.Z`.
2. `./build.sh` passes (7 unit tests, secret scan) and prints the SHA-256.
3. `python3 e2e/run_e2e.py` 18/18 pass; screenshots reviewed.
4. Manual: install from Chrome on one Android phone; open offline once; save one record.
5. Keep the previous release zip and its .sha256.
6. Deploy the zip contents; open the site; footer shows the new version and commit.

## Rollback / recovery
- Redeploy the previous release zip (verify its .sha256). Its service worker has a different
  cache name, so on activation it deletes the newer cache and serves the old shell.
- Records live in IndexedDB (schema v1) and are never deleted by a release; any future schema
  change must migrate forward without dropping data, so an older build can still read v1.
- A failed save never changes stored data (one transaction, aborted on error).
