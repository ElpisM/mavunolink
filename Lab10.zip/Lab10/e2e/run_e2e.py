"""End-to-end tests for the MavunoLink PWA in headless Chrome (Playwright).

Run after ./build.sh:   python3 e2e/run_e2e.py
Serves dist/ on http://127.0.0.1:8123 (localhost counts as a secure context, so the
service worker and IndexedDB work), uses a 412x915 phone-sized viewport, and writes
e2e/results.json and screenshots to e2e/shots/.

Limits: this is desktop Chrome emulating a phone viewport, not a phone or Safari.
"""
import functools
import http.server
import json
import os
import statistics
import threading
import time

from playwright.sync_api import expect, sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIST = os.path.join(ROOT, "dist")
SHOTS = os.path.join(ROOT, "e2e", "shots")
URL = "http://127.0.0.1:8123/index.html"
CHROME = "/usr/bin/google-chrome"

results = []


def check(test_id, name, ok, detail=""):
    results.append({"id": test_id, "name": name, "pass": bool(ok), "detail": detail})
    print(f"{'PASS' if ok else 'FAIL'}  {test_id:4} {name}  {detail}")


def serve():
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=DIST)
    handler.log_message = lambda *a: None
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 8123), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def wait_count(page, n):
    expect(page.locator("#count")).to_have_text(str(n), timeout=10000)


def wait_sw(page):
    # polled from Python: the page's CSP forbids the string evaluation wait_for_function uses
    for _ in range(100):
        if page.evaluate("navigator.serviceWorker.controller !== null"):
            return
        time.sleep(0.1)
    raise RuntimeError("service worker never took control")


def count(page):
    return int(page.text_content("#count"))


def fill(page, farmer, point, qty, kind="DELIVERY", notes=""):
    page.fill("#farmer", farmer)
    page.select_option("#point", point)
    page.fill("#quantity", qty)
    page.check(f"input[name=kind][value={kind}]")
    page.fill("#notes", notes)


def shot(page, name):
    page.screenshot(path=os.path.join(SHOTS, name + ".png"))


def main():
    os.makedirs(SHOTS, exist_ok=True)
    srv = serve()
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=CHROME, headless=True)
        ctx = browser.new_context(viewport={"width": 412, "height": 915}, device_scale_factor=2,
                                  is_mobile=True, has_touch=True, service_workers="allow")
        page = ctx.new_page()
        page.on("dialog", lambda d: d.accept())
        page.goto(URL)
        page.evaluate("navigator.serviceWorker.ready.then(() => true)")
        page.reload()                     # now controlled by the service worker
        wait_sw(page)

        # E1 normal flow
        fill(page, "FRM-001", "CP-03", "12.5")
        page.click("#review")
        review_visible = page.is_visible("#review-view")
        shot(page, "e1_review")
        page.click("#save")
        wait_count(page, 1)
        status = page.text_content("#status")
        shot(page, "e1_saved")
        check("E1", "Normal flow: review then save", review_visible and count(page) == 1
              and "Saved on this device" in status, f"status='{status}', count={count(page)}")

        # E2 boundary: 0 kg delivery rejected, 0 kg weekly harvest accepted
        fill(page, "FRM-002", "CP-01", "0")
        page.click("#review")
        err = page.text_content("#err-quantity")
        focused = page.evaluate("document.activeElement.id")
        invalid = page.get_attribute("#quantity", "aria-invalid")
        shot(page, "e2_zero_delivery")
        check("E2a", "Boundary: 0 kg delivery rejected", "more than 0 kg" in err and focused == "quantity"
              and invalid == "true", f"error='{err}', focus={focused}, aria-invalid={invalid}")
        page.check("input[name=kind][value=WEEKLY_HARVEST]")
        page.click("#review")
        page.click("#save")
        wait_count(page, 2)
        check("E2b", "Boundary: 0 kg weekly harvest accepted", count(page) == 2, f"count={count(page)}")

        # E3 blank form
        page.fill("#farmer", "")
        page.select_option("#point", "")
        page.fill("#quantity", "")
        page.click("#review")
        n_invalid = page.evaluate("document.querySelectorAll('[aria-invalid=true]').length")
        summary = page.text_content("#summary")
        focused = page.evaluate("document.activeElement.id")
        shot(page, "e3_blank")
        check("E3", "Blank form: errors announced, focus on first", n_invalid == 3 and focused == "farmer"
              and "3 fields need attention" in summary, f"invalid={n_invalid}, focus={focused}, summary='{summary}'")

        # E4 failure and recovery
        fill(page, "FRM-003", "CP-02", "7")
        page.click("#review")
        page.check("#sim-fail")
        page.click("#save")
        page.wait_for_selector("#alert:not([hidden])")
        alert = page.text_content("#alert")
        still_review = page.is_visible("#review-view")
        in_view = page.evaluate("(() => { const r = document.querySelector('#alert').getBoundingClientRect(); return r.top >= 0 && r.bottom <= innerHeight; })()")
        focused = page.evaluate("document.activeElement.id")
        shot(page, "e4_save_failed")
        check("E4a", "Failed save: alert, nothing stored, review kept", "Not saved" in alert and count(page) == 2
              and still_review, f"alert='{alert}', count={count(page)}")
        check("E4c", "Failed-save alert is on screen and focused (v1.0.1 fix)", in_view and focused == "alert",
              f"alert in viewport={in_view}, focus={focused}")
        page.uncheck("#sim-fail")
        page.click("#save")
        wait_count(page, 3)
        dupes = page.evaluate("[...document.querySelectorAll('#records .title')].filter(e => e.textContent.startsWith('FRM-003')).length")
        check("E4b", "Recovery: retry saves once", count(page) == 3 and dupes == 1, f"count={count(page)}, FRM-003 rows={dupes}")

        # E5 identity: repeated Review/Edit and a double tap on Save give one record
        fill(page, "FRM-004", "CP-04", "3")
        for _ in range(3):
            page.click("#review")
            page.click("#edit")
        page.click("#review")
        page.dblclick("#save")
        wait_count(page, 4)
        time.sleep(0.5)
        check("E5", "Repeated navigation and double tap: one record", count(page) == 4, f"count={count(page)}")

        # E6 security R2: notes are displayed as text, never executed
        payload = '<img src=x onerror="window.__xss=1">'
        fill(page, "FRM-005", "CP-05", "4", notes=payload)
        page.click("#review")
        page.click("#save")
        wait_count(page, 5)
        shown = page.evaluate("document.querySelector('#records li .meta').textContent")
        executed = page.evaluate("window.__xss === 1")
        imgs = page.evaluate("document.querySelectorAll('#records img').length")
        check("E6", "Script-like notes shown as text, not run", payload in shown and not executed and imgs == 0,
              f"executed={executed}, img elements={imgs}")

        # E14 security R3: the Content Security Policy is enforced (string eval blocked)
        csp = page.evaluate("""() => new Promise(resolve => {
            let violation = null;
            document.addEventListener('securitypolicyviolation', e => { violation = e.violatedDirective; }, { once: true });
            const s = document.createElement('script');
            s.textContent = 'window.__injected = 1';
            document.head.append(s);
            setTimeout(() => resolve({ ran: window.__injected === 1, violation }), 200);
        })""")
        check("E14", "CSP blocks an injected inline script", not csp["ran"] and csp["violation"] is not None,
              f"script ran={csp['ran']}, violated directive={csp['violation']}")

        # E7 privacy R1: a name or phone number is rejected as the farmer reference
        fill(page, "Jane Wanjiku", "CP-01", "2")
        page.click("#review")
        err = page.text_content("#err-farmer")
        check("E7", "Name instead of farmer code rejected", "not a name" in err, f"error='{err}'")
        page.click("#cancel")

        # E8 keyboard only (Tab / typing / arrow keys / Enter; no mouse)
        page.reload()
        wait_sw(page)
        page.evaluate("document.activeElement && document.activeElement.blur()")
        order = []
        for _ in range(9):
            page.keyboard.press("Tab")
            el = page.evaluate("document.activeElement.id || document.activeElement.name")
            if not order or order[-1] != el:      # the date input has day/month/year stops
                order.append(el)

        def tab_to(target):
            for _ in range(8):
                if page.evaluate("document.activeElement.id") == target:
                    return
                page.keyboard.press("Tab")

        page.evaluate("document.activeElement && document.activeElement.blur()")
        tab_to("farmer")
        page.keyboard.type("FRM-006")
        tab_to("point")
        page.keyboard.press("ArrowDown")
        tab_to("quantity")
        page.keyboard.type("5")
        page.keyboard.press("Enter")                    # submits the form -> Review
        page.wait_for_selector("#review-view:not([hidden])")
        focus_after = page.evaluate("document.activeElement.id")
        page.keyboard.press("Tab")
        page.keyboard.press("Tab")                      # Edit -> Save
        on_save = page.evaluate("document.activeElement.id")
        page.keyboard.press("Enter")
        wait_count(page, 6)
        check("E8", "Keyboard only: tab order, Enter to review and save",
              order[:4] == ["farmer", "date", "point", "quantity"] and focus_after == "review-title" and on_save == "save",
              f"tab order={order[:6]}, focus after review={focus_after}, then {on_save}")

        # E9 large text (root font 200%)
        page.evaluate("document.documentElement.style.fontSize = '200%'")   # CSSOM is allowed; injected <style> is not (CSP)
        page.wait_for_timeout(200)
        overflow = page.evaluate("document.documentElement.scrollWidth - window.innerWidth")
        small = page.evaluate("[...document.querySelectorAll('button, input, select, textarea')].filter(e => e.offsetParent && e.type !== 'radio' && e.type !== 'checkbox' && e.getBoundingClientRect().height < 48).length")
        shot(page, "e9_large_text")
        check("E9", "200% text: no sideways scroll, targets >= 48px", overflow <= 0 and small == 0,
              f"horizontal overflow={overflow}px, controls under 48px={small}")
        page.reload()

        # E10 every control has a visible label
        unlabeled = page.evaluate("[...document.querySelectorAll('input, select, textarea')].filter(e => !(e.labels && e.labels.length) && !e.getAttribute('aria-label')).map(e => e.id || e.name)")
        check("E10", "Every input has a label", not unlabeled, f"unlabelled={unlabeled}")

        # E11 offline: reload from cache, records still there, saving works
        wait_sw(page)
        before = count(page)
        ctx.set_offline(True)
        page.reload()
        net = page.text_content("#net")
        offline_count = count(page)
        fill(page, "FRM-007", "CP-03", "9")
        page.click("#review")
        page.click("#save")
        wait_count(page, before + 1)
        shot(page, "e11_offline")
        check("E11", "Offline: app opens from cache, records kept, save works",
              offline_count == before and "Offline" in net and count(page) == before + 1,
              f"records before={before}, after offline reload={offline_count}, after save={count(page)}, net='{net}'")

        # P1 performance: offline cold reload (domContentLoaded), median of 5
        dcl = []
        for _ in range(5):
            page.reload()
            dcl.append(page.evaluate("performance.getEntriesByType('navigation')[0].domContentLoadedEventEnd"))
        ctx.set_offline(False)

        # P2 performance: Save tap -> list updated, median of 20 (includes automation overhead)
        times = []
        for i in range(20):
            n = count(page)
            fill(page, f"FRM-{100 + i}", "CP-01", "1")
            page.click("#review")
            t0 = time.perf_counter()
            page.click("#save")
            wait_count(page, n + 1)
            times.append((time.perf_counter() - t0) * 1000)
        check("P1", "Offline reload, DOMContentLoaded (ms)", True,
              f"median={statistics.median(dcl):.1f}, max={max(dcl):.1f} over 5")
        check("P2", "Save to list updated (ms)", True,
              f"median={statistics.median(times):.1f}, p90={sorted(times)[17]:.1f}, max={max(times):.1f} over 20")

        # E12 traceable version shown in the app
        version = page.text_content("#version")
        check("E12", "Version and commit shown in app", "dev" not in version, f"version='{version}'")

        # E13 limitation: data belongs to one browser profile (a new profile starts empty)
        ctx2 = browser.new_context(viewport={"width": 412, "height": 915})
        p2 = ctx2.new_page()
        p2.goto(URL)
        p2.wait_for_selector("#count")
        time.sleep(0.5)
        check("E13", "New browser profile sees 0 records (no sync)", count(p2) == 0, f"count={count(p2)}")
        ctx2.close()

        browser.close()
    srv.shutdown()
    with open(os.path.join(ROOT, "e2e", "results.json"), "w") as f:
        json.dump(results, f, indent=2)
    failed = [r for r in results if not r["pass"]]
    print(f"\n{len(results) - len(failed)}/{len(results)} passed")
    raise SystemExit(1 if failed else 0)


if __name__ == "__main__":
    main()
