// Run: node --test tests/   (Node 18+, no dependencies)
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validate } from '../src/validate.js';

const today = new Date('2026-11-18T10:00:00');
const base = { id: 'abc', farmer: 'FRM-001', date: '2026-11-18', pointId: 'CP-03', quantity: '12.5', kind: 'DELIVERY', notes: '' };
const fields = d => { const r = validate({ ...base, ...d }, { today }); return r.ok ? [] : r.errors.map(e => e.field); };

test('U1 valid draft becomes a PENDING record with the same id', () => {
  const r = validate(base, { today });
  assert.equal(r.ok, true);
  assert.equal(r.record.id, 'abc');
  assert.equal(r.record.quantityKg, 12.5);
  assert.equal(r.record.syncState, 'PENDING');
});

test('U2 blank form reports every required field in screen order', () => {
  assert.deepEqual(fields({ farmer: '', date: '', pointId: '', quantity: '' }), ['farmer', 'date', 'point', 'quantity']);
});

test('U3 zero is rejected for a delivery but allowed for a weekly harvest', () => {
  assert.deepEqual(fields({ quantity: '0' }), ['quantity']);
  assert.deepEqual(fields({ quantity: '0', kind: 'WEEKLY_HARVEST' }), []);
  assert.deepEqual(fields({ quantity: '-0', kind: 'WEEKLY_HARVEST' }), []);
  assert.deepEqual(fields({ quantity: '-5' }), ['quantity']);
});

test('U4 malformed and non-finite quantities are rejected', () => {
  for (const q of ['12kg', '1,200', 'abc', '1e3', 'NaN', 'Infinity', '.', '12.5.3', '5 0', '9'.repeat(400), '100000.01']) {
    assert.deepEqual(fields({ quantity: q }), ['quantity'], q);
  }
});

test('U5 impossible, future and too-old dates are rejected', () => {
  for (const d of ['2026-02-30', '2026-13-01', '18/11/2026', '2026-11-19', '2025-11-17']) {
    assert.deepEqual(fields({ date: d }), ['date'], d);
  }
});

test('U6 farmer must be a code, not a name or phone number (privacy control R1)', () => {
  assert.deepEqual(fields({ farmer: 'Jane Wanjiku' }), ['farmer']);
  assert.deepEqual(fields({ farmer: '0712345678' }), ['farmer']);
  assert.deepEqual(fields({ farmer: 'frm-002' }), []);                 // accepted and upper-cased
  assert.equal(validate({ ...base, farmer: 'frm-002' }, { today }).record.farmer, 'FRM-002');
});

test('U7 prompt and removed collection point are rejected', () => {
  assert.deepEqual(fields({ pointId: '' }), ['point']);
  assert.deepEqual(fields({ pointId: 'CP-99' }), ['point']);
  assert.equal(validate(base, { today, points: [] }).ok, false);
});
