#!/usr/bin/env bash
# Build -> test -> package. Reproducible: same commit gives the same files (only builtAt differs).
# Usage: ./build.sh          Output: release/mavunolink-pwa-<version>-<commit>.zip (+ .sha256)
set -euo pipefail
cd "$(dirname "$0")"

VERSION=$(node -p "require('./package.json').version")
COMMIT=$(git rev-parse --short HEAD 2>/dev/null || echo nogit)
if [ -n "$(git status --porcelain 2>/dev/null)" ]; then COMMIT="${COMMIT}-dirty"; fi
BUILT=$(date -u +%Y-%m-%dT%H:%M:%SZ)
echo "== MavunoLink PWA ${VERSION} (${COMMIT})"

echo "== 1. unit tests"
node --test tests/*.test.mjs

echo "== 2. assemble dist/"
rm -rf dist && mkdir -p dist/src release
cp index.html styles.css manifest.webmanifest sw.js icon-192.png icon-512.png dist/
cp src/app.js src/validate.js src/store.js dist/src/
printf 'self.MAVUNOLINK_VERSION = { version: "%s", commit: "%s", builtAt: "%s" };\n' "$VERSION" "$COMMIT" "$BUILT" > dist/src/version.js

echo "== 3. check: no secrets or credentials in the package"
if grep -RInE "(api[_-]?key|secret|password|token)\s*[:=]" dist/; then echo "possible secret found"; exit 1; fi

echo "== 4. package"
PKG="release/mavunolink-pwa-${VERSION}-${COMMIT}.zip"
rm -f "$PKG"
(cd dist && zip -qrX "../$PKG" .)
sha256sum "$PKG" | tee "$PKG.sha256"
echo "== done: $PKG"
