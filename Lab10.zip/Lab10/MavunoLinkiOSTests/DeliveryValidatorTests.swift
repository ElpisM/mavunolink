// UNEXECUTED: written without a Mac/Xcode. Not compiled or run. See README.md.
// Expected results are predictions from the rule table, which was executed in Java
// (Android RecordValidatorTest / FormValidatorTest) with the same rules.

import XCTest
@testable import MavunoLinkiOS

final class DeliveryValidatorTests: XCTestCase {

    private var calendar: Calendar = {
        var c = Calendar(identifier: .gregorian)
        c.timeZone = TimeZone(identifier: "Africa/Nairobi")!
        return c
    }()
    private lazy var today: Date = calendar.date(from: DateComponents(year: 2026, month: 11, day: 18, hour: 10))!

    private func draft(qty: String = "12.5", kind: TransactionKind = .delivery) -> DeliveryDraft {
        var d = DeliveryDraft()
        d.farmerRef = "FRM-001"
        d.date = today
        d.pointID = "CP-03"
        d.variety = .oyster
        d.quantityText = qty
        d.kind = kind
        return d
    }

    private func fields(_ d: DeliveryDraft) -> [Field] {
        switch DeliveryValidator.validate(d, points: CollectionPoint.all, today: today, calendar: calendar) {
        case .success: return []
        case .failure(let f): return f.errors.map(\.field)
        }
    }

    // T1 valid
    func testValidDraftBecomesRecordWithSameId() throws {
        let d = draft()
        let r = try DeliveryValidator.validate(d, points: CollectionPoint.all, today: today, calendar: calendar).get()
        XCTAssertEqual(r.id, d.id)                 // identity carried from draft to record
        XCTAssertEqual(r.quantityKg, 12.5)
        XCTAssertEqual(r.pointName, "Thika Road Depot")
        XCTAssertEqual(r.syncState, .pending)
    }

    // T2 blank
    func testBlankFieldsAllReportedInScreenOrder() {
        var d = DeliveryDraft()                    // everything empty
        d.date = today                             // fixed date so the test does not depend on the clock
        XCTAssertEqual(fields(d).first, .farmer)
        XCTAssertEqual(Set(fields(d)), [.farmer, .point, .variety, .quantity])
    }

    // T3 zero and negative
    func testZeroRejectedForDeliveryAcceptedForWeeklyHarvest() {
        XCTAssertEqual(fields(draft(qty: "0")), [.quantity])
        XCTAssertEqual(fields(draft(qty: "0", kind: .weeklyHarvest)), [])
        XCTAssertEqual(fields(draft(qty: "-0", kind: .weeklyHarvest)), [])
        XCTAssertEqual(fields(draft(qty: "-5")), [.quantity])
    }

    // T4 malformed
    func testMalformedQuantityRejected() {
        for q in ["12kg", "1,200", "abc", "1e3", "nan", "inf", ".", "12.5.3", "5 0"] {
            XCTAssertEqual(fields(draft(qty: q)), [.quantity], "quantity \(q)")
        }
        XCTAssertEqual(fields(draft(qty: String(repeating: "9", count: 400))), [.quantity])
        XCTAssertEqual(fields(draft(qty: "100000.01")), [.quantity])
    }

    // T5 prompt and missing point
    func testPromptAndRemovedPointRejected() {
        var d = draft(); d.pointID = nil
        XCTAssertEqual(fields(d), [.point])
        d.pointID = "CP-99"
        XCTAssertEqual(fields(d), [.point])
        let r = DeliveryValidator.validate(draft(), points: [], today: today, calendar: calendar)
        XCTAssertThrowsError(try r.get())
    }

    // T6 date range
    func testFutureAndTooOldDatesRejected() {
        var d = draft()
        d.date = calendar.date(byAdding: .day, value: 1, to: today)!
        XCTAssertEqual(fields(d), [.date])
        d.date = calendar.date(byAdding: .day, value: -366, to: today)!
        XCTAssertEqual(fields(d), [.date])
    }
}
