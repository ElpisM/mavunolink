// UNEXECUTED: written without a Mac/Xcode. Not compiled or run. See README.md.

import XCTest
@testable import MavunoLinkiOS

@MainActor
final class RecordStoreTests: XCTestCase {

    private var url: URL!

    override func setUp() async throws {
        url = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathComponent("records.json")
    }

    private func record(id: UUID = UUID()) -> DeliveryRecord {
        DeliveryRecord(id: id, farmerRef: "FRM-001", date: Date(), pointID: "CP-01", pointName: "Gatundu Market",
                       variety: .button, quantityKg: 8, kind: .delivery, notes: nil, paperReceipt: false,
                       version: 1, syncState: .pending, savedAt: Date())
    }

    // T7 repeated commit of the same identity does not duplicate
    func testCommittingSameIdTwiceKeepsOneRecord() throws {
        let store = RecordStore(fileURL: url)
        let r = record()
        XCTAssertEqual(try store.commit(r), .saved)
        XCTAssertEqual(try store.commit(r), .alreadySaved)
        XCTAssertEqual(store.records.count, 1)
    }

    // T8 failed save changes nothing
    func testFailedWriteLeavesRecordsUnchanged() throws {
        let store = RecordStore(fileURL: url)
        _ = try store.commit(record())
        store.simulateWriteFailure = true
        XCTAssertThrowsError(try store.commit(record()))
        XCTAssertEqual(store.records.count, 1)
    }

    // T9 committed records survive a new store (= app relaunch)
    func testRecordsSurviveRelaunch() throws {
        let first = RecordStore(fileURL: url)
        _ = try first.commit(record())
        _ = try first.commit(record())
        let relaunched = RecordStore(fileURL: url)
        relaunched.load()
        XCTAssertEqual(relaunched.records.count, 2)
        XCTAssertNil(relaunched.loadError)
    }

    // T10 first launch has no file and no error
    func testFirstLaunchIsEmptyNotAnError() {
        let store = RecordStore(fileURL: url)
        store.load()
        XCTAssertTrue(store.records.isEmpty)
        XCTAssertNil(store.loadError)
    }
}
